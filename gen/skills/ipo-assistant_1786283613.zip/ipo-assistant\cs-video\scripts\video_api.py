"""
cs-video/scripts/video_api.py
happyhorse 视频生成脚本，支持文生视频 / 图生视频（首帧）。

用法:
  python video_api.py --mode text  --prompt "描述"  [--resolution 720P] [--ratio 16:9] [--duration 5]
  python video_api.py --mode image --prompt "描述"  --img_url "https://..."  [--duration 5]

输出 (stdout):
  VIDEO_URL=https://...
  TASK_ID=xxx

API 规格：
  文生视频模型: happyhorse-1.0-t2v
  图生视频模型: happyhorse-1.0-i2v（不支持 ratio，宽高比跟随输入图像）
  状态：1=submitted  2=processing  3=success  4=failed
  结果查询：GET /v1/async/results/{id}
"""
import sys, json, time, argparse, urllib.request

_APX_BASE   = "http://apx-api.tal.com"
_SUBMIT_URL = f"{_APX_BASE}/v1/async/chat"
_API_KEY    = "300000485:61b228c575d42cbd37a266636c5b7364"

_MODEL_T2V  = "happyhorse-1.0-t2v"
_MODEL_I2V  = "happyhorse-1.0-i2v"

_POLL_SECS  = 15


def _headers(model: str) -> dict:
    return {
        "api-key":      _API_KEY,
        "X-APX-Model":  model,
        "Content-Type": "application/json",
        "Accept":       "application/json",
    }


def _post(url: str, payload: dict, model: str) -> dict:
    import urllib.error as _ue
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req  = urllib.request.Request(url, data=data, headers=_headers(model), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8"))
    except _ue.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} {e.reason}: {body[:200]}")


def _get_result(task_id: str, model: str) -> dict:
    url = f"{_APX_BASE}/v1/async/results/{task_id}"
    req = urllib.request.Request(url, headers=_headers(model), method="GET")
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def submit_video(mode: str, prompt: str, resolution: str = "720P", ratio: str = "16:9",
                 duration: int = 5, img_url: str = "") -> tuple[str, str]:
    """提交视频生成任务，返回 (task_id, model)。"""
    if mode == "text":
        model = _MODEL_T2V
        payload = {
            "model":  model,
            "prompt": prompt,
            "extra_body": {
                "parameters": {
                    "resolution": resolution,
                    "ratio":      ratio,
                    "duration":   duration,
                }
            }
        }

    elif mode == "image":
        if not img_url:
            raise ValueError("图生视频需要提供 img_url")
        model = _MODEL_I2V
        payload = {
            "model":  model,
            "prompt": prompt,
            "extra_body": {
                "input": {
                    "media": [
                        {
                            "url":  img_url,
                            "type": "first_frame"
                        }
                    ]
                }
            }
        }

    else:
        raise ValueError(f"未知模式: {mode}，可选 text / image")

    resp = _post(_SUBMIT_URL, payload, model)
    task_id = str(resp.get("id") or resp.get("task_id") or "")
    if not task_id:
        raise RuntimeError(f"提交失败，响应: {json.dumps(resp, ensure_ascii=False)[:300]}")
    return task_id, model


def poll_result(task_id: str, model: str) -> str:
    """轮询结果直到成功或失败，无时间限制。
    status: 1=submitted  2=processing  3=success  4=failed
    响应结构：顶层平铺 {id, status, response, ...}
    """
    elapsed = 0
    while True:
        resp = _get_result(task_id, model)

        # 顶层平铺，兜底兼容 data 嵌套
        item = resp
        if "data" in resp and isinstance(resp["data"], dict):
            item = resp["data"].get(task_id, resp["data"]) or resp

        status = item.get("status")

        if status == 3:
            response_obj = item.get("response") or {}
            # response 可能是 dict 或字符串
            if isinstance(response_obj, str):
                url = response_obj
            else:
                url = (response_obj.get("video_url")
                       or response_obj.get("url")
                       or response_obj.get("video")
                       or "")
            if url:
                return str(url)
            raise RuntimeError(f"任务成功但未找到 video_url，完整响应: {json.dumps(item, ensure_ascii=False)[:400]}")

        if status == 4:
            response_obj = item.get("response") or {}
            if isinstance(response_obj, dict):
                msg = response_obj.get("message") or response_obj.get("code") or "unknown error"
            else:
                msg = str(response_obj) or "unknown error"
            raise RuntimeError(f"视频生成失败: {msg}")

        elapsed += _POLL_SECS
        print(f"[video] 等待中 {elapsed}s task_id={task_id} status={status}", file=sys.stderr)
        time.sleep(_POLL_SECS)


def main():
    parser = argparse.ArgumentParser(description="happyhorse 视频生成")
    parser.add_argument("--mode",       default="text",  help="text / image")
    parser.add_argument("--prompt",     required=True,   help="视频内容描述")
    parser.add_argument("--resolution", default="720P",  help="分辨率，仅文生视频有效（如 720P / 1080P）")
    parser.add_argument("--ratio",      default="16:9",  help="宽高比，仅文生视频有效（如 16:9 / 9:16）")
    parser.add_argument("--duration",   type=int, default=5, help="时长（秒），文生视频参数")
    parser.add_argument("--img_url",    default="",      help="图生视频：首帧图片URL")
    args = parser.parse_args()

    try:
        task_id, model = submit_video(
            mode=args.mode, prompt=args.prompt,
            resolution=args.resolution, ratio=args.ratio,
            duration=args.duration, img_url=args.img_url,
        )
        print(f"[video] 任务已提交 task_id={task_id}，等待生成中…", file=sys.stderr)
        video_url = poll_result(task_id, model)
        print(f"VIDEO_URL={video_url}")
        print(f"TASK_ID={task_id}")
    except Exception as e:
        print(f"ERROR={e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
