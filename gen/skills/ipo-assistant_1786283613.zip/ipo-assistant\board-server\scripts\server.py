"""
内购看板 Skill HTTP 服务  —  localhost:8765（内网 10.8.67.31:8765）
接收 Dify 下单信号，异步执行各类任务，完成后推送知音楼通知。

接口：
  POST /api/task/submit         下单（见任务类型表）
  GET  /api/task/status/<id>    查询任务状态
  GET  /api/tasks               列出全部任务
  GET  /health                  健康检查

任务类型（task 字段）：
  board_generate   看板全流程（抓取→清洗→可视化→发布→通知）
  cs_product       商品查询（九凤后台），需要 query 字段
  cs_order         订单查询（九凤后台），需要 query 字段
  cs_logistics     物流查询（快递100），需要 query 字段
  cs_aftersale     售后工单记录（Teable），需要 query 字段
  cs_suggestion    补货建议记录（Teable），需要 query 字段
"""
import sys, os, uuid, threading, subprocess, json, re, time
from datetime import datetime
try:
    import requests as _http
except ImportError:
    _http = None

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# Windows：防止子进程弹出黑色控制台窗口
_POPEN_FLAGS = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0

try:
    from flask import Flask, request, jsonify
except ImportError:
    print("缺少 flask，请先运行: pip install flask")
    sys.exit(1)

app = Flask(__name__)

# 视频临时存储目录（通过 /video/<filename> 路由对外提供下载）
_VIDEO_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "videos")
os.makedirs(_VIDEO_DIR, exist_ok=True)

# ngrok 公网域名（运行时从 ngrok API 动态获取，无 ngrok 时 fallback 到空）
def _get_ngrok_url() -> str:
    try:
        import urllib.request as _ur
        resp = json.loads(_ur.urlopen("http://localhost:4040/api/tunnels", timeout=3).read())
        for t in resp.get("tunnels", []):
            if t.get("proto") == "https":
                return t["public_url"].rstrip("/")
    except Exception:
        pass
    return ""

# 当前文件在 board-server/scripts/，退两级到 ipo-assistant/
SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 各 Skill 脚本路径
S = {
    # 看板流水线
    "fetch":      os.path.join(SKILL_ROOT, "board-ls-fetch",   "scripts", "fetch_ls_waterfall.py"),
    "write":      os.path.join(SKILL_ROOT, "board-ls-fetch",   "scripts", "write_to_teable.py"),
    "clean":      os.path.join(SKILL_ROOT, "board-data-clean", "scripts", "clean_data.py"),
    "visualize":  os.path.join(SKILL_ROOT, "board-visualize",  "scripts", "generate_chart.py"),
    # 客服查询
    "cs_product":    os.path.join(SKILL_ROOT, "cs-product",   "scripts", "query_product.py"),
    "cs_order":      os.path.join(SKILL_ROOT, "cs-order",     "scripts", "query_order.py"),
    "cs_logistics":  os.path.join(SKILL_ROOT, "cs-logistics", "scripts", "query_logistics.py"),
    "cs_aftersale":  os.path.join(SKILL_ROOT, "cs-aftersale", "scripts", "record_aftersale.py"),
    "cs_suggestion": os.path.join(SKILL_ROOT, "cs-suggestion","scripts", "record_suggestion.py"),
    "jiufeng_login":    os.path.join(SKILL_ROOT, "cs-order", "scripts", "jiufeng_login_pw.py"),
    "sales_refresh":    os.path.join(SKILL_ROOT, "cs-order", "scripts", "update_sales_teable.py"),
    "notify_admin":  os.path.join(SKILL_ROOT, "cs-aftersale", "scripts", "notify_admin.py"),
    "cs_video":      os.path.join(SKILL_ROOT, "cs-video",     "scripts", "video_api.py"),
}

_tasks: dict = {}
_lock = threading.Lock()


def _log(task_id: str, msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    with _lock:
        _tasks[task_id]["logs"].append(line)
    print(f"[{task_id[:6]}] {line}")


def _run(cmd: list, task_id: str, step: str, timeout: int = 600) -> tuple:
    _log(task_id, f"▶ {step}")
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True,
            encoding='utf-8', errors='replace', timeout=timeout,
            creationflags=_POPEN_FLAGS,
        )
        if r.returncode != 0:
            _log(task_id, f"✗ {step} 失败 (code={r.returncode})\n{r.stderr[:400]}")
            return False, r.stdout, r.stderr
        _log(task_id, f"✓ {step} 完成")
        return True, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        _log(task_id, f"✗ {step} 超时（{timeout}s）")
        return False, "", "timeout"
    except Exception as e:
        _log(task_id, f"✗ {step} 异常: {e}")
        return False, "", str(e)


def _set_status(task_id: str, status: str, **extra):
    with _lock:
        _tasks[task_id]["status"] = status
        _tasks[task_id].update(extra)


# ─── 看板全流程 ────────────────────────────────────────────────────

def run_board_pipeline(task_id: str, days: int = 90):
    _set_status(task_id, "running", started_at=datetime.now().isoformat())
    py = sys.executable

    ok, _, _ = _run([py, S["fetch"]], task_id, "抓取LS水单")
    if not ok:
        return _set_status(task_id, "failed:fetch", finished_at=datetime.now().isoformat())

    ok, _, _ = _run([py, S["write"]], task_id, "写入Teable原始数据")
    if not ok:
        return _set_status(task_id, "failed:write", finished_at=datetime.now().isoformat())

    ok, _, _ = _run([py, S["clean"]], task_id, "清洗统计")
    if not ok:
        return _set_status(task_id, "failed:clean", finished_at=datetime.now().isoformat())

    ok, stdout, _ = _run([py, S["visualize"]], task_id, "生成可视化")
    if not ok:
        return _set_status(task_id, "failed:visualize", finished_at=datetime.now().isoformat())

    html_path = next(
        (line.split("=", 1)[1].strip() for line in stdout.splitlines() if line.startswith("OUTPUT_PATH=")),
        ""
    )
    if not html_path or not os.path.exists(html_path):
        _log(task_id, f"✗ 未找到生成的HTML文件: {html_path!r}")
        return _set_status(task_id, "failed:no_html", finished_at=datetime.now().isoformat())

    _log(task_id, "✅ 可视化完成，推送知音楼通知")
    _yach_send_p2p("215734", "📊 内购看板数据已更新完成！\n\n抓取→清洗→可视化全流程已成功执行，最新数据已写入 Teable，请登录查看。")

    _set_status(task_id, "done", finished_at=datetime.now().isoformat())
    _log(task_id, "🎉 全流程完成")


# ─── 客服查询流程 ──────────────────────────────────────────────────

def _build_cs_cmd(task_name: str, query: str, py: str) -> list:
    """把自然语言 query 映射成各 CS 脚本的命令行参数"""
    import re
    script = S[task_name]
    q = query.strip()

    if task_name == "cs_product":
        kw = re.sub(r'^(查询?|搜索|找|看看|有没有)\s*', '', q).strip() or q
        return [py, script, "--keyword", kw, "--json_output"]

    if task_name == "cs_order":
        # 尝试提取工号或订单号
        uid = re.search(r'\b((?=[A-Za-z0-9]*\d)[A-Za-z0-9]{4,12})\b', q)
        oid = re.search(r'(?:订单|单号|order)[^\d]*(\d{8,})', q, re.I)
        return [py, script,
                "--user_id",  uid.group(1) if uid else "",
                "--order_id", oid.group(1) if oid else "",
                "--json_output"]

    if task_name == "cs_logistics":
        # 快递单号：SF/YT/JT/ZT/STO/YUNDA 开头，或纯数字12+位
        exp = re.search(r'\b([A-Z]{2,4}\d{8,}|\d{12,})\b', q, re.I)
        oid = re.search(r'(?:订单|单号)[^\d]*(\d{8,})', q, re.I)
        return [py, script,
                "--express_no", exp.group(1) if exp else "",
                "--order_id",   oid.group(1) if oid else "",
                "--json_output"]

    if task_name == "cs_aftersale":
        uid = re.search(r'\b((?=[A-Za-z0-9]*\d)[A-Za-z0-9]{4,12})\b', q)
        return [py, script,
                "--user_id",    uid.group(1) if uid else "unknown",
                "--issue_type", q[:50],
                "--product",    ""]

    if task_name == "cs_suggestion":
        uid = re.search(r'\b((?=[A-Za-z0-9]*\d)[A-Za-z0-9]{4,12})\b', q)
        return [py, script,
                "--user_id",  uid.group(1) if uid else "unknown",
                "--product",  q[:50],
                "--need_type", "新品征集"]

    return [py, S[task_name]]


def run_cs_task(task_id: str, task_name: str, query: str, receiver_id: str = ""):
    """客服查询：调用对应 Skill 脚本，完成后日志记录，结果通过 Skill 内部推送"""
    _set_status(task_id, "running", started_at=datetime.now().isoformat())
    py = sys.executable

    if task_name not in S or not os.path.exists(S[task_name]):
        _log(task_id, f"✗ 脚本不存在: {S.get(task_name)}")
        return _set_status(task_id, "failed:no_script", finished_at=datetime.now().isoformat())

    cmd = _build_cs_cmd(task_name, query, py)
    ok, stdout, _ = _run(cmd, task_id, f"执行 {task_name}", timeout=120)
    if not ok:
        return _set_status(task_id, "failed:script", finished_at=datetime.now().isoformat())

    _set_status(task_id, "done", finished_at=datetime.now().isoformat(), result=stdout[:500])
    _log(task_id, f"✓ {task_name} 完成")



# ─── GLM-4.7 对话处理 ──────────────────────────────────────

# ─── Teable 配置 ────────────────────────────────────────────────
_TEABLE_BASE     = "https://yach-teable.zhiyinlou.com"
_TEABLE_TOKEN    = "teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw="
_TEABLE_TABLE_ID      = "tblWZQc8bcI5sAmHM9u"   # 内购客服任务触发
_TEABLE_BASE_ID       = "bseFFoyVD6WgFbKmzDN"   # 内购数据库

_TEABLE_DOC_KB_TABLE_ID = "tblBwsedV4x4Zs6tHw5"  # 产品文档知识库

# ── 产品文档知识库内存缓存 ────────────────────────────────────────────────────
_doc_kb_cache: list = []   # [{name, content, category}, ...]
_doc_kb_lock  = threading.Lock()
_doc_kb_loaded = False

def _load_doc_kb():
    """从 Teable 拉取产品文档知识库全量记录，加载到内存。首次调用后缓存，后续秒级命中。"""
    global _doc_kb_cache, _doc_kb_loaded
    with _doc_kb_lock:
        if _doc_kb_loaded:
            return
        try:
            records, offset = [], 0
            while True:
                r = _http.get(
                    f"{_TEABLE_BASE}/api/table/{_TEABLE_DOC_KB_TABLE_ID}/record"
                    f"?take=100&skip={offset}&fieldKeyType=name",
                    headers={"Authorization": f"Bearer {_TEABLE_TOKEN}"},
                    timeout=20, verify=False
                )
                batch = r.json().get("records", [])
                for rec in batch:
                    f = rec.get("fields", {})
                    name    = str(f.get("产品名称", "") or "").strip()
                    content = str(f.get("内容", "") or "").strip()
                    cat     = str(f.get("分类", "") or "").strip()
                    if name and content:
                        _doc_kb_cache.append({"name": name, "content": content, "category": cat})
                if len(batch) < 100:
                    break
                offset += 100
            _doc_kb_loaded = True
            print(f"[doc-kb] 已加载 {len(_doc_kb_cache)} 条产品文档到内存", flush=True)
        except Exception as e:
            print(f"[doc-kb] 加载失败: {e}", flush=True)

def _search_doc_kb(query: str) -> str:
    """在产品文档知识库里按产品名检索，返回最匹配条目的内容（截取 3000 字）。"""
    if not _doc_kb_loaded:
        _load_doc_kb()
    if not _doc_kb_cache:
        return ""
    q = query.lower()
    # 第一轮：产品名在 query 中完整出现（精确匹配）
    best = None
    best_len = 0
    for item in _doc_kb_cache:
        name_lower = item["name"].lower()
        # 双向包含：query 含产品名 或 产品名含 query 中某个词
        if name_lower in q or any(part in q for part in name_lower.split() if len(part) > 1):
            if len(item["name"]) > best_len:
                best = item
                best_len = len(item["name"])
    # 第二轮：query 中的词出现在产品名（模糊回退）
    if not best:
        q_words = [w for w in re.split(r'[\s，。？！、：；「」【】《》]+', q) if len(w) >= 2]
        for item in _doc_kb_cache:
            name_lower = item["name"].lower()
            if any(w in name_lower for w in q_words):
                if len(item["name"]) > best_len:
                    best = item
                    best_len = len(item["name"])
    if best:
        header = f"【产品文档：{best['name']}】\n"
        return header + best["content"][:3000]
    return ""
_LOG_TABLE_ID: str = ""                     # 内购客服记录（启动时创建）


def _teable_headers():
    return {"Authorization": f"Bearer {_TEABLE_TOKEN}", "Content-Type": "application/json"}


def _teable_update(rec_id: str, fields: dict):
    if _http is None:
        return
    _http.patch(
        f"{_TEABLE_BASE}/api/table/{_TEABLE_TABLE_ID}/record/{rec_id}?fieldKeyType=name",
        headers=_teable_headers(), json={"record": {"fields": fields}}, timeout=8,
    )


def _teable_delete(rec_ids: list):
    if _http is None or not rec_ids:
        return
    params = "&".join(f"recordIds[]={rid}" for rid in rec_ids)
    _http.delete(
        f"{_TEABLE_BASE}/api/table/{_TEABLE_TABLE_ID}/record?{params}",
        headers=_teable_headers(), timeout=8,
    )


# ─── 客服记录表 ───────────────────────────────────────────────────

def _ensure_log_table():
    """启动时确保「内购客服记录」表存在，写入 _LOG_TABLE_ID。"""
    global _LOG_TABLE_ID
    if _http is None:
        return
    try:
        r = _http.get(
            f"{_TEABLE_BASE}/api/base/{_TEABLE_BASE_ID}/table?take=100",
            headers=_teable_headers(), timeout=10,
        )
        raw = r.json()
        tables = raw if isinstance(raw, list) else raw.get("tables", [])
        for t in tables:
            if t.get("name") == "内购客服记录":
                _LOG_TABLE_ID = t["id"]
                print(f"[log_table] 已找到记录表: {_LOG_TABLE_ID}")
                return
        resp = _http.post(
            f"{_TEABLE_BASE}/api/base/{_TEABLE_BASE_ID}/table",
            headers=_teable_headers(), timeout=10,
            json={"name": "内购客服记录", "fields": [
                {"name": "提交时间",   "type": "date"},
                {"name": "用户查询",   "type": "singleLineText"},
                {"name": "识别意图",   "type": "singleLineText"},
                {"name": "提取实体",   "type": "longText"},
                {"name": "处理状态",   "type": "singleLineText"},
                {"name": "查询结果",   "type": "longText"},
                {"name": "处理耗时秒", "type": "number"},
            ]},
        )
        _LOG_TABLE_ID = resp.json()["id"]
        print(f"[log_table] 已创建记录表: {_LOG_TABLE_ID}")
    except Exception as e:
        print(f"[log_table] 初始化失败: {e}")


def _build_workcode_unknown_block(user_id: str, is_group: bool) -> str:
    """工号未识别时注入系统提示块；工号已知则返回空字符串。"""
    if user_id:
        return ""
    order_hint = (
        "  · 群聊中工号未识别时不要追问 → 提示用户在和我的私聊窗口查询订单，保护隐私更方便\n"
        if is_group else
        "  · 若用户要查**本人订单/物流**且没提供单号 → 只需一句话问工号：\n"
        "    「好的，能告诉我您的工号吗？工号就是您的员工编号，在知音楼个人主页可以查到，"
        "填一次以后就记住了～」（口语，简短，不要多问）\n"
    )
    return (
        "⚠️【工号未识别】该用户首次使用或尚未绑定工号。规则：\n"
        "  · 若用户问商品/使用说明/售后流程等不需要工号的问题 → 正常回答，不提工号\n"
        + order_hint +
        "  · 若用户提供了工号（纯数字或字母+数字）→ 系统已自动记录，直接帮他查，不要再确认\n"
    )


def _parse_self_reported_workcode(text: str) -> str:
    """从用户自报文本中提取工号。支持直接发工号、「工号是215734」「我的工号215734」等格式。"""
    if not text:
        return ""
    t = text.strip()
    # 整条消息就是工号（纯数字5-8位，或字母前缀+数字，如 V0053510）
    if re.match(r'^[A-Za-z]?\d{5,8}$', t):
        return t.upper()
    # "工号是/工号：XXX" 或 "我的工号是XXX"
    m = re.search(r'(?:工号|员工号|员工编号)[：:是为\s]*([A-Za-z]?\d{5,8})', t)
    if m:
        return m.group(1).upper()
    return ""


def _log_interaction(query: str, intent: str, entities: dict) -> tuple:
    """写一条记录到客服记录表，返回 (rec_id, start_time)。"""
    import time
    t0 = time.time()
    if _http is None or not _LOG_TABLE_ID:
        return "", t0
    try:
        now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000Z")
        r = _http.post(
            f"{_TEABLE_BASE}/api/table/{_LOG_TABLE_ID}/record?fieldKeyType=name",
            headers=_teable_headers(), timeout=8,
            json={"records": [{"fields": {
                "提交时间":  now,
                "用户查询":  query[:500],
                "识别意图":  intent,
                "提取实体":  json.dumps(entities, ensure_ascii=False),
                "处理状态":  "processing",
            }}]},
        )
        rec_id = r.json()["records"][0]["id"]
        return rec_id, t0
    except Exception as e:
        print(f"[log_interaction] {e}")
        return "", t0


def _update_log(rec_id: str, result: str, status: str, t0: float = 0):
    """更新记录表中的处理结果。"""
    import time
    if _http is None or not _LOG_TABLE_ID or not rec_id:
        return
    try:
        elapsed = round(time.time() - t0, 2) if t0 else 0
        _http.patch(
            f"{_TEABLE_BASE}/api/table/{_LOG_TABLE_ID}/record/{rec_id}?fieldKeyType=name",
            headers=_teable_headers(), timeout=8,
            json={"record": {"fields": {
                "处理状态":   status,
                "查询结果":   (result or "")[:2000],
                "处理耗时秒": elapsed,
            }}},
        )
    except Exception as e:
        print(f"[update_log] {e}")


def _teable_poll_once():
    if _http is None:
        return
    r = _http.get(
        f"{_TEABLE_BASE}/api/table/{_TEABLE_TABLE_ID}/record?fieldKeyType=name&take=50",
        headers=_teable_headers(), timeout=10,
    )
    to_delete = []
    for rec in r.json().get("records", []):
        rec_id = rec["id"]
        status = rec.get("fields", {}).get("status")
        if status != "pending":
            to_delete.append(rec_id)
            continue
        query = rec.get("fields", {}).get("query", "").strip()
        if not query:
            to_delete.append(rec_id)
            continue
        intent = _keyword_intent(query)
        _teable_update(rec_id, {"status": "processing", "intent": intent})
        if intent in _TASK_MAP:
            tid = uuid.uuid4().hex[:8]
            with _lock:
                _tasks[tid] = {"task": _TASK_MAP[intent], "status": "pending",
                               "created_at": datetime.now().isoformat(), "logs": [], "query": query}
            threading.Thread(target=run_cs_task,
                             args=(tid, _TASK_MAP[intent], query, ""), daemon=True).start()
        elif intent == "board_generate":
            tid = uuid.uuid4().hex[:8]
            with _lock:
                _tasks[tid] = {"task": "board_generate", "status": "pending",
                               "created_at": datetime.now().isoformat(), "logs": []}
            threading.Thread(target=run_board_pipeline, args=(tid,), daemon=True).start()
        to_delete.append(rec_id)
    if to_delete:
        _teable_delete(to_delete)


_sales_refresh_running = False  # 防止重复触发


def _teable_poll_loop():
    import time
    while True:
        try:
            _teable_poll_once()
        except Exception as e:
            print(f"[teable_poll] {e}")
        time.sleep(10)


# ─── GLM 多模型后端（各自独立 RPM 20，合计 RPM 60）──────────────
_GLM_URL  = "http://ai-service.tal.com/openai-compatible/v1/chat/completions"
_GLM_AUTH = "Bearer 300000485:61b228c575d42cbd37a266636c5b7364"

_BACKENDS = [
    {"model": "claude-sonnet-4.6",  "last_call": 0.0, "lock": threading.Lock(),
     "thinking_budget": 3000, "max_tokens": 8000},   # extended thinking
    {"model": "kimi-k2.6",          "last_call": 0.0, "lock": threading.Lock()},
    {"model": "glm-5.1",            "last_call": 0.0, "lock": threading.Lock()},
    {"model": "deepseek-v4-pro",    "last_call": 0.0, "lock": threading.Lock(),
     "reasoning_effort": "high"},                      # chain-of-thought
    {"model": "claude-opus-4.7",    "last_call": 0.0, "lock": threading.Lock(),
     "thinking_budget": 5000, "max_tokens": 10000},   # extended thinking
    {"model": "qwen3.5-omni-flash", "last_call": 0.0, "lock": threading.Lock()},
]

# ─── gpt-image-2（备用纯文生图）────────────────────────────────
_IMAGE_GEN_URL  = "http://ai-service.tal.com/openai-compatible/v1/images/generations"
_IMAGE_EDIT_URL = "http://ai-service.tal.com/openai-compatible/v1/images/edits"
_IMAGE_API_KEY  = "300000485:61b228c575d42cbd37a266636c5b7364"
# RPM:5 限额 + 生成耗时 60~180s — 并发打满会触发网关 RST，串行排队执行
_image_gen_sem  = threading.Semaphore(1)   # 同一时刻只允许 1 个生图请求
_video_gen_sem  = threading.Semaphore(1)   # 同一时刻只允许 1 个视频请求
# 图片识别排队：一次一个，先来先服务，保护整条模型链（sonnet→opus→qwen）
_image_desc_sem = threading.Semaphore(1)

# ─── GitHub 图床（替换已失效的文图图床）────────────────────────
_GITHUB_TOKEN  = "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"
_GITHUB_REPO   = "dingbudong/dingyang"
_GITHUB_BRANCH = "main"
_GITHUB_PATH   = "gen"   # 存放 AI 生成图片的目录

# ─── 委派任务确认状态 ────────────────────────────────────────────────
_pending_delegations: dict = {}   # token → {bot, note, ts, requester}
_DELEGATE_EXPIRE = 1800           # 确认有效期 30 分钟
_DELEGATES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pending_delegates.json')

def _save_delegates():
    try:
        with open(_DELEGATES_FILE, 'w', encoding='utf-8') as _f:
            json.dump(_pending_delegations, _f, ensure_ascii=False)
    except Exception:
        pass

def _load_delegates():
    try:
        if os.path.exists(_DELEGATES_FILE):
            _now = time.time()
            with open(_DELEGATES_FILE, 'r', encoding='utf-8') as _f:
                _data = json.load(_f)
            return {t: v for t, v in _data.items() if _now - v.get('ts', 0) < _DELEGATE_EXPIRE}
    except Exception:
        pass
    return {}

_pending_delegations.update(_load_delegates())

# ─── 异步生图/生视频持久化任务队列 ─────────────────────────────────
# 防止 server.py 重启时 daemon 线程被杀导致生成任务丢失
_ASYNC_JOBS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pending_async_jobs.json')
_async_jobs_lock = threading.Lock()

def _async_job_save(job_id: str, job: dict):
    with _async_jobs_lock:
        try:
            if os.path.exists(_ASYNC_JOBS_FILE):
                with open(_ASYNC_JOBS_FILE, 'r', encoding='utf-8') as _f:
                    data = json.load(_f)
            else:
                data = {}
            data[job_id] = job
            with open(_ASYNC_JOBS_FILE, 'w', encoding='utf-8') as _f:
                json.dump(data, _f, ensure_ascii=False)
        except Exception:
            pass

def _async_job_done(job_id: str):
    with _async_jobs_lock:
        try:
            if not os.path.exists(_ASYNC_JOBS_FILE):
                return
            with open(_ASYNC_JOBS_FILE, 'r', encoding='utf-8') as _f:
                data = json.load(_f)
            data.pop(job_id, None)
            with open(_ASYNC_JOBS_FILE, 'w', encoding='utf-8') as _f:
                json.dump(data, _f, ensure_ascii=False)
        except Exception:
            pass

def _recover_async_jobs():
    """启动时恢复上次未完成的异步生图/生视频任务"""
    try:
        if not os.path.exists(_ASYNC_JOBS_FILE):
            return
        with open(_ASYNC_JOBS_FILE, 'r', encoding='utf-8') as _f:
            data = json.load(_f)
        if not data:
            return
        _log_ops(f"[恢复] 发现 {len(data)} 个未完成的异步任务，重新启动...")
        for job_id, job in list(data.items()):
            jtype = job.get("type")
            uid   = job.get("uid", "")
            if jtype == "image":
                ig = job.get("is_group", False)
                bgid = job.get("group_id", "")
                prompt = job.get("prompt", "")
                if not prompt:
                    _async_job_done(job_id)
                    continue
                def _img_recovery(jid=job_id, p=prompt, u=uid, bg_is_group=ig, bg_gid=bgid):
                    try:
                        url = _generate_image(p)
                        if url and url.startswith("http"):
                            _log_ops(f"  <- [恢复] 生图完成: {url[:80]}")
                            if bg_is_group and bg_gid:
                                _yach_send_group_image(bg_gid, url, user_id=u)
                            elif u:
                                _yach_send_p2p_markdown(u, "🎨 图片生成好了！", "🎨 图片生成好了！\n\n![图片](" + url + ")")
                        else:
                            _log_ops(f"  ✗ [恢复] 生图失败: {url}")
                            if u:
                                _yach_send_p2p(u, "抱歉，图片生成暂时失败了，可能是网络波动，稍后重新发送「生成」指令重试即可 🙏")
                    except Exception as e:
                        _log_ops(f"  ✗ [恢复] 生图异常: {e}")
                        if u:
                            _yach_send_p2p(u, "抱歉，图片生成暂时失败了，稍后重新发送「生成」指令重试即可 🙏")
                    finally:
                        _async_job_done(jid)
                threading.Thread(target=_img_recovery, daemon=True).start()
            elif jtype == "video":
                video_script = job.get("video_script", "")
                ig_v = job.get("is_group", False)
                bgid_v = job.get("group_id", "")
                prompt       = job.get("prompt", "")
                if not prompt or not video_script or not os.path.exists(video_script):
                    _async_job_done(job_id)
                    continue
                _cmd = [sys.executable, video_script,
                        "--mode",       job.get("mode", "text"),
                        "--prompt",     prompt,
                        "--resolution", job.get("resolution", "720P"),
                        "--ratio",      job.get("ratio", "16:9"),
                        "--duration",   str(job.get("duration", 5))]
                if job.get("img_url"):
                    _cmd += ["--img_url", job["img_url"]]
                def _vid_recovery(jid=job_id, cmd=_cmd, u=uid, bg_is_group=ig_v, bg_gid=bgid_v):
                    try:
                        r = subprocess.run(cmd, capture_output=True, text=True,
                                           encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS)
                        stdout = r.stdout.strip()
                        if r.returncode != 0:
                            err = r.stderr.strip()[:300]
                            _log_ops(f"  ✗ [恢复] 视频生成失败: {err}")
                            if u:
                                if "SubAppId" in err or "401" in err or "403" in err:
                                    _yach_send_p2p(u, "抱歉，图生视频功能暂未开通权限，请改用文字描述生成视频 🙏")
                                else:
                                    _yach_send_p2p(u, "抱歉，视频生成失败了，稍后重新发送「生成视频」重试即可 🙏")
                            return
                        video_url = ""
                        for line in stdout.splitlines():
                            if line.startswith("VIDEO_URL="):
                                video_url = line.split("=", 1)[1].strip()
                        if video_url:
                            _log_ops(f"  <- [恢复] 视频生成完成: {video_url[:80]}")
                            if bg_is_group and bg_gid:
                                _yach_send_group_markdown(bg_gid, "🎬 视频生成好了！", "🎬 视频生成好了！" + chr(10) + chr(10) + "[点击查看视频](" + video_url + ")", u)
                            elif u:
                                _yach_send_p2p_markdown(u, "视频生成好了", "🎬 视频生成好了！" + chr(10) + chr(10) + "[点击查看视频](" + video_url + ")")
                        else:
                            if u:
                                _yach_send_p2p(u, "抱歉，视频生成完成但未获取到链接，请重试。")
                    except Exception as e:
                        _log_ops(f"  ✗ [恢复] 视频生成异常: {e}")
                        if u:
                            _yach_send_p2p(u, "抱歉，视频生成出错了，稍后重新发送「生成视频」重试即可 🙏")
                    finally:
                        _video_gen_sem.release()
                        _async_job_done(jid)
                threading.Thread(target=_vid_recovery, daemon=True).start()
            else:
                _async_job_done(job_id)
    except Exception as e:
        _log_ops(f"[恢复] 读取异步任务失败: {e}")

# ─── 多用户会话历史（上下文记忆）───────────────────────────────
_conversations: dict = {}   # user_id → {"messages": [...], "ts": float}
_CONV_TTL    = 1800         # 30 分钟无消息自动开新话题
_CONV_MAX    = 100          # 最多保留消息数（50轮对话）

# ─── GLM 速率限制（防 429）────────────────────────────────────────
_GLM_MIN_INTERVAL = 3.5    # 每个 backend 最小调用间隔（秒，≈17 RPM，各自独立计算）
_GLM_RETRY_WAIT   = 8.0    # 429 后等待再重试（秒）

# ── GLM 请求队列（有界 FIFO，单 worker 串行处理）─────────────────────────────
# 每个请求封装成 _GlmReq，Flask 线程 put 后在 Event 上等结果；
# worker 线程一次处理一个，保证严格排队、彻底消灭并发 429。
import queue as _queue_mod

class _LLMFallback(Exception):
    """LLM 不可用时抛出，携带关键词兜底结果；竞速模式下不作为胜出结果。"""
    def __init__(self, result: str):
        self.result = result

class _LLMRateLimit(Exception):
    """429 速率限制；由 worker 捕获后立即切换到下一个 backend，不在当前 backend 内等待。"""
    pass

class _RaceCtx:
    """多个竞速 Worker 共享的上下文：先完成者获胜，其余结果丢弃。"""
    __slots__ = ('event', 'result', 'lock', 'done_flag', 'n_total', 'fail_count', '_first_fallback')
    def __init__(self, n_total: int):
        self.event          = threading.Event()
        self.result         = None
        self.lock           = threading.Lock()
        self.done_flag      = False
        self.n_total        = n_total
        self.fail_count     = 0
        self._first_fallback = None

    def try_complete(self, result: str) -> bool:
        """LLM 正常返回时调用。第一个成功者胜出，其余丢弃。"""
        with self.lock:
            if self.done_flag:
                return False
            self.done_flag = True
            self.result    = result
        self.event.set()
        return True

    def report_fallback(self, fallback: str):
        """LLM 失败降级时调用。全员失败后才用兜底结果触发 event。"""
        with self.lock:
            if self.done_flag:
                return
            if self._first_fallback is None:
                self._first_fallback = fallback
            self.fail_count += 1
            if self.fail_count >= self.n_total:
                self.done_flag = True
                self.result    = self._first_fallback
                self.event.set()


class _GlmReq:
    __slots__ = ('query', 'user_id', 'user_name', 'image_content', 'hist_uid', 'is_group', 'group_id', 'context', 'event', 'result', 'race_ctx', 'real_group_id', 'is_webhook', 'group_name', 'dialog_count', 'app_id', 'workflow_run_id')
    def __init__(self, query, user_id, image_content, hist_uid, is_group, group_id="", context="", race_ctx=None, user_name="", is_webhook=False, group_name="", dialog_count=0, app_id="", workflow_run_id=""):
        self.query         = query
        self.user_id       = user_id
        self.user_name     = user_name
        self.image_content = image_content
        self.hist_uid      = hist_uid
        self.is_group      = is_group
        self.group_id      = group_id
        self.context       = context
        self.race_ctx      = race_ctx
        self.event         = race_ctx.event if race_ctx else threading.Event()
        self.result        = None
        self.real_group_id = ""  # 由 _glm_agent_chat 解析后回写，续发群消息用
        self.is_webhook    = is_webhook
        self.group_name    = group_name
        self.dialog_count  = dialog_count
        self.app_id        = app_id
        self.workflow_run_id = workflow_run_id

_glm_queue     = _queue_mod.Queue()
_CHAT_BACKENDS = _BACKENDS
_GLM_WORKERS   = len(_CHAT_BACKENDS)  # 6个对话 worker
_worker_states   = {}                   # worker_id → started_at（None=空闲）
_worker_lock     = threading.Lock()
_WORKER_STUCK_SEC = 300                 # 单请求超过此秒数视为卡死，触发 watchdog

# 排队计数（仅用于日志可观察性）
_glm_active   = 0
_glm_act_lock = threading.Lock()

_IMG_INTENT_KW = (
    # 只保留「用户手里有图/指代具体图片」的短语，通用词「图片」「照片」已移除
    # 移除原因：「提供下XX图片」「XX的照片」含这两词但用户是在要图，不是发图识别
    '图中', '图里', '图上', '这张', '这个图', '这是什么',
    '这个是什么', '看图', '识别', '里面有什么', '有什么东西', '是什么商品',
    '看下这', '帮我看', '照片里', '照片上', '这张图', '这图',
)

# 含以下商品查询词时，即使命中 _IMG_INTENT_KW 也不触发识图（避免「想看下这个商品的销量」被误判）
_IMG_EXCLUDE_KW = (
    '销量', '价格', '库存', '订单', '物流', '多少钱', '有货', '补货',
    '有没有', '多少件', '卖了', '卖出', '排行', '销售额',
)

_IMG_GEN_KW = ('生成', '帮我画', '画一张', '画个', '做个', '做一个', '生图', '文生', '创作')

def _is_image_intent(query: str) -> bool:
    if any(kw in query for kw in _IMG_GEN_KW):
        return False
    if any(kw in query for kw in _IMG_EXCLUDE_KW):
        return False   # 商品查询意图，不是识图请求
    return any(kw in query for kw in _IMG_INTENT_KW)

_PRIORITY_MODEL = "claude-sonnet-4.6"

def _pick_backend() -> dict:
    """claude-sonnet 优先；若速率限制期内则选最久未用的其他 backend。"""
    import time as _t
    now = _t.time()
    sonnet = next((b for b in _CHAT_BACKENDS if b["model"] == _PRIORITY_MODEL), None)
    if sonnet:
        with sonnet["lock"]:
            if now - sonnet["last_call"] >= _GLM_MIN_INTERVAL:
                return sonnet
    others = [b for b in _CHAT_BACKENDS if b["model"] != _PRIORITY_MODEL]
    return min(others, key=lambda b: b["last_call"]) if others else (sonnet or _CHAT_BACKENDS[0])


def _glm_worker(worker_id: int):
    """worker 线程：claude-sonnet 优先，失败自动接力其他后端，完成通过 Event 通知等待方。"""
    import time as _wt

    while True:
        req = None
        try:
            req = _glm_queue.get()
            with _worker_lock:
                _worker_states[worker_id] = _wt.time()

            # 后端尝试链：首选 sonnet，其余按 LRU 排序
            sonnet = next((b for b in _CHAT_BACKENDS if b["model"] == _PRIORITY_MODEL), None)
            others = sorted(
                [b for b in _CHAT_BACKENDS if b["model"] != _PRIORITY_MODEL],
                key=lambda b: b["last_call"]
            )
            backend_chain = ([sonnet] if sonnet else []) + others

            req.result = None
            for backend in backend_chain:
                try:
                    req.result = _glm_agent_chat(
                        req.query, user_id=req.user_id, user_name=req.user_name,
                        image_content=req.image_content,
                        hist_uid=req.hist_uid, is_group=req.is_group,
                        group_id=req.group_id, context=req.context,
                        backend=backend, notify_event=req.event,
                        is_webhook=req.is_webhook,
                        group_name=req.group_name, dialog_count=req.dialog_count,
                        app_id=req.app_id, workflow_run_id=req.workflow_run_id,
                    )
                    _log_ops(f"  ✓ [{backend['model']}] 完成")
                    break
                except _LLMFallback as fb:
                    req.result = fb.result
                    break
                except _LLMRateLimit:
                    _log_ops(f"  ⚠ [{backend['model']}] 速率限制，切换下一个模型")
                    if backend is backend_chain[-1]:
                        req.result = "抱歉，所有模型当前均触发速率限制，请稍后重试。"
                except Exception as e:
                    _log_ops(f"  ⚠ [{backend['model']}] 失败: {e}，换下一个后端")
                    if backend is backend_chain[-1]:
                        req.result = f"抱歉，处理时出现错误，请稍后重试。（{e}）"

            if req.result is None:
                req.result = "抱歉，服务暂时不可用，请稍后重试。"

        except Exception as _outer_e:
            print(f"[worker{worker_id}] 外层异常（已忽略，继续运行）: {_outer_e}")
            if req is not None:
                req.result = "抱歉，服务内部发生异常，请稍后重试。"
            _wt.sleep(1)
        finally:
            with _worker_lock:
                _worker_states[worker_id] = None
            if req is not None:
                if not req.event.is_set():
                    req.event.set()
                try:
                    _glm_queue.task_done()
                except Exception:
                    pass


def _glm_wait(backend: dict):
    """确保该 backend 距上次调用已过 _GLM_MIN_INTERVAL 秒，不足则 sleep 补足。"""
    import time as _t
    with backend["lock"]:
        gap  = _t.time() - backend["last_call"]
        wait = _GLM_MIN_INTERVAL - gap
        backend["last_call"] = _t.time() + max(wait, 0)
    if wait > 0:
        _log_ops(f"  ⏳ [{backend['model']}] 速率控制：等待 {wait:.1f}s")
        _t.sleep(wait)


def _strip_thinking_text(content) -> str:
    """从 Claude API 响应中去除 extended thinking（英文推理过程）。
    content 可能是 str（thinking混入文本）或 list（thinking blocks）。
    """
    if not content:
        return ""
    # list 格式：extended thinking 返回 [{"type":"thinking",...},{"type":"text","text":"..."}]
    if isinstance(content, list):
        return "\n\n".join(
            b.get("text", "") for b in content if b.get("type") == "text"
        ).strip()
    if not isinstance(content, str):
        return str(content).strip()
    # string 格式：按段落分割，去掉英文主导段落（Claude 推理特征）
    _THINKING_STARTERS = (
        "wait,", "let me", "looking back,", "actually,", "hmm,", "i need to",
        "i should", "re-examine", "reconsider", "let me re-", "i realize",
        "thinking about", "based on the", "the user said",
    )
    paras = content.split("\n\n")
    filtered = []
    for para in paras:
        stripped = para.strip()
        if not stripped:
            continue
        low = stripped.lower()
        # 段落以已知英文推理开头 → 丢弃整段
        if any(low.startswith(s) for s in _THINKING_STARTERS):
            continue
        # 统计中文字符数 vs ASCII字母数
        chinese = sum(1 for c in stripped if '一' <= c <= '鿿')
        ascii_alpha = sum(1 for c in stripped if c.isascii() and c.isalpha())
        # 纯英文段落（无中文）且超过30字 → 丢弃（可能是推理）
        if chinese == 0 and ascii_alpha > 30:
            continue
        filtered.append(stripped)
    return "\n\n".join(filtered).strip() or content.strip()


_REPLY_MAX_LEN = 6000  # 试验值：原3500实测截断，扩至6000测试知音楼Dify通道实际上限（~25款商品含图片）


def _fix_md_links(text: str) -> str:
    """修复 LLM 在 Markdown 链接/图片 URL 括号内换行导致链接失效的问题。
    将 ](url\ncontinued) 中的换行和多余空格合并成单行。"""
    def _collapse(m: re.Match) -> str:
        url = re.sub(r'\s*\n\s*', '', m.group(1))   # 去掉 URL 内所有换行+周边空白
        url = url.strip()
        return '](' + url + ')'
    # 匹配 ]( ... ) 且括号内含换行
    return re.sub(r'\]\(([^)]*\n[^)]*(?:\n[^)]*)*)\)', _collapse, text)


def _split_reply(text: str, max_len: int = _REPLY_MAX_LEN) -> list:
    """把超长回复按自然分隔点切成多段，每段 ≤ max_len 字符。
    安全性：不在 Markdown 图片/链接 URL 中间截断。"""
    if len(text) <= max_len:
        return [text]

    def _in_url(s: str, pos: int) -> bool:
        """判断 pos 是否位于 Markdown 图片/链接的 URL 括号内：![alt](URL) 或 [text](URL)"""
        # 找到最近一个未闭合的 '('，且其前有 ']'
        depth = 0
        for i in range(pos - 1, max(0, pos - 300), -1):
            if s[i] == ')':
                depth += 1
            elif s[i] == '(':
                if depth == 0:
                    # 检查 '(' 前面有没有 ']'
                    j = i - 1
                    while j >= 0 and s[j] == ' ':
                        j -= 1
                    if j >= 0 and s[j] == ']':
                        return True
                    return False
                depth -= 1
        return False

    parts = []
    remaining = text
    while len(remaining) > max_len:
        # 候选切割点：从 500 字开始，找最靠近 max_len 的自然断点
        # 优先级：编号列表项 > Markdown标题 > 双换行 > 单换行
        split_pos = None
        window = remaining[:max_len]
        # 1. 在 [500, max_len) 找 \n\n 后紧跟数字编号 or ** or ## 的位置
        for m in re.finditer(r'\n\n(?=\d+[\.、]|\*\*\S|#{1,3} |---)', window[500:]):
            split_pos = 500 + m.start()
        # 2. 退而求其次：最后一个双换行
        if split_pos is None:
            idx = window.rfind('\n\n', 400)
            if idx > 0:
                split_pos = idx
        # 3. 再退：最后一个单换行
        if split_pos is None:
            idx = window.rfind('\n', 400)
            if idx > 0:
                split_pos = idx
        # 4. 兜底：硬切
        if split_pos is None:
            split_pos = max_len
        # 安全检查：若切割点在 Markdown URL 括号内，向前移到最近一个换行
        if _in_url(remaining, split_pos):
            safe = remaining.rfind('\n', 0, split_pos)
            if safe > 200:
                split_pos = safe
        parts.append(remaining[:split_pos].rstrip())
        remaining = remaining[split_pos:].lstrip()
    if remaining.strip():
        parts.append(remaining.strip())
    return parts


_PRODUCT_IMG_TAG   = '![商品图片]'
_PRODUCT_BATCH_SIZE = 8


def _split_products_by_count(text: str, batch_size: int = _PRODUCT_BATCH_SIZE) -> list:
    """按商品条目数量拆分商品列表，每批最多 batch_size 款。
    仅对全局连续编号（1,2,...,N 无重置）的列表生效。
    检测到编号重置（分节格式，如每节从 1 开始）时返回 [text]，由调用方降级为字符分割。"""
    items = list(re.finditer(r'(?m)^(\d+)[\.、] ', text))
    if len(items) <= batch_size:
        return [text]
    nums = [int(m.group(1)) for m in items]
    if max(nums) != len(nums):          # 有编号重置或跳号 → 分节/兼容性格式，不适合数量分批
        return [text]
    header = text[:items[0].start()].rstrip()
    batches = []
    for i in range(0, len(items), batch_size):
        start_pos = items[i].start()
        end_pos = items[i + batch_size].start() if i + batch_size < len(items) else len(text)
        chunk = text[start_pos:end_pos].rstrip()
        batch_text = (header + '\n\n' + chunk) if (i == 0 and header) else chunk
        batches.append(batch_text)
    return batches


def _glm_post_with_retry(messages: list, tools: list, backend: dict):
    """带速率控制的 GLM POST。429 时立即抛出 _LLMRateLimit，由 worker 切换下一 backend。
    其他错误最多重试 2 次。返回 requests.Response；调用方负责 raise_for_status()。"""
    model = backend["model"]
    payload = {
        "model": model, "messages": messages,
        "tools": tools, "tool_choice": "auto",
        "max_tokens": backend.get("max_tokens", 4096),
    }
    if backend.get("thinking_budget"):
        # Claude extended thinking：thinking + output 共用 max_tokens，temperature 必须为 1
        payload["thinking"] = {"type": "enabled", "budget_tokens": backend["thinking_budget"]}
        payload["temperature"] = 1
    elif not backend.get("no_temperature"):
        payload["temperature"] = 0.6
    if backend.get("reasoning_effort"):
        payload["reasoning_effort"] = backend["reasoning_effort"]
    hdrs = {"Authorization": _GLM_AUTH, "Content-Type": "application/json"}
    for attempt in range(3):
        _glm_wait(backend)
        resp = _http.post(_GLM_URL, headers=hdrs, json=payload, timeout=None)
        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After", "?")
            _log_ops(f"  ⚠ [{model}] 速率限制（Retry-After={retry_after}s），立即切换下一个模型")
            raise _LLMRateLimit(model)
        if resp.status_code == 403:
            _log_ops(f"  ✗ [{model}] HTTP 403 无权限，跳过此模型")
            raise _LLMRateLimit(model)
        if resp.status_code in (502, 503, 504):
            _log_ops(f"  ✗ [{model}] HTTP {resp.status_code} 服务不可用，切换下一个模型")
            raise _LLMRateLimit(model)
        return resp
    return resp

_STATIC_REPLY = {
    "product_query": (
        "🏪 内购商城入口：https://t.tal.com/e3KJoD\n"
        "👆 用手机知音楼扫码进入内购商城 📱\n"
        "![内购商城二维码](https://yach-static.zhiyinlou.com/online/person/1779503218959/79343BF9AFA2A679883BA3482474BE93/86852FE6-309F-429E-B758-3C7FCC0D2CC3.PNG)\n\n"
        "后台已启动查询，如有具体商品名称请告知，结果将通过知音楼推送。"
    ),
    "order_query": (
        "已收到您的订单查询请求，正在查询中，结果将通过知音楼推送。"
    ),
    "logistics_query": (
        "请提供**快递单号**（如：JT0023119290362）或**订单号**，即可查询物流状态。\n\n"
        "• 已发货：返回实时轨迹及签收信息\n"
        "• 未发货：显示备货中状态，请耐心等待"
    ),
    "aftersale": (
        "您好，针对您反映的情况，请按以下路径提交售后申请：\n\n"
        "**流程中心 → 搜索【内购商城售后申请】**\n"
        "👉 点击直达：https://oa.zhiyinlou.com/v20/formRender?wfId=1475\n\n"
        "填写申请后，内购管理员会尽快跟进处理，请注意知音楼消息通知。\n\n"
        "如填写遇到问题，可联系内购管理员（知音楼工号：215734）。"
    ),
    "suggestion": (
        "感谢您的反馈！如果您希望补货或有商品建议，请填写下方表格，内购管理员会统一跟进：\n\n"
        "📋 **补货/期望商品收集表**\n"
        "https://yach-doc-shimo.zhiyinlou.com/sheets/8Nk6MWvrBdTVo4qL/MODOC/\n\n"
        "填写后丁洋老师（215734）会尽快跟进，感谢您的支持！"
    ),
    "courier_query": (
        "商城的快递公司由系统随机分配，**无法指定或保证使用某家快递**（如顺丰、圆通、中通等）。\n\n"
        "如有快递相关问题，请联系内购管理员丁洋老师（知音楼工号：**215734**）。"
    ),
    "board_generate": (
        "内购看板生成任务已启动！\n\n"
        "正在抓取数据并生成可视化图表，预计5-10分钟内完成，"
        "完成后会通过知音楼推送看板链接，请注意查收。"
    ),
    "unknown": (
        "抱歉，这个问题我暂时无法解答。\n\n"
        "请联系内购管理员丁洋老师（知音楼工号：215734）获取帮助。"
    ),
}

_TASK_MAP = {
    "product_query":   "cs_product",
    "order_query":     "cs_order",
    "logistics_query": "cs_logistics",
    "aftersale":       "cs_aftersale",
    "suggestion":      "cs_suggestion",
}


_KW_RULES = [
    ("self_intro",      ["你有什么功能", "你能做什么", "你会什么", "你是谁", "你是什么机器人",
                          "介绍一下自己", "你能帮我什么", "有什么用", "你能帮什么", "你有哪些功能"]),
    ("board_generate",  ["看板", "数据看板", "数据分析", "生成看板"]),
    ("sales_query",     ["销售额", "销售量", "营业额", "今日销售", "本周销售", "本月销售", "卖了多少", "销量统计",
                          "销量", "今日销量", "本周销量", "本月销量", "卖出多少", "售出多少"]),
    ("aftersale",       ["售后", "退货", "退款", "损坏", "坏了", "换货", "投诉",
                          "丢了", "丢失", "破损", "烂了", "发霉", "撕了", "破了",
                          "异物", "贴纸", "污渍", "脏了", "质量问题", "质量不好",
                          "有问题", "坏掉", "漏了", "缺件", "少件"]),
    ("courier_query",   ["顺丰", "圆通", "中通", "韵达", "申通", "京东快递", "邮政快递",
                          "快递方式", "发货方式", "哪家快递", "什么快递", "哪个快递",
                          "固定快递", "指定快递", "快递公司", "能否指定"]),
    ("logistics_query", ["物流", "快递", "快到了", "到了吗", "运单", "快递单"]),
    ("order_query",     ["订单", "购买记录", "我买的", "下单", "买了"]),
    ("suggestion",      ["建议", "补货", "缺货", "没有货", "何时有",
                          "断货", "没货了", "什么时候有货", "什么时候上架",
                          "期望商品", "想要", "希望有", "上架"]),
    ("product_query",   ["商品", "查商品", "搜索", "有没有", "有吗", "有货", "在卖", "上架", "查", "价格", "哪款", "哪些", "几款"]),
]

def _keyword_intent(query: str) -> str:
    q = query.lower()
    # 兼容性/配套产品问法：让 GLM Agent + 知识库处理，不走商品搜索
    _COMPAT_PATTERNS = ["可以使用", "配套", "兼容", "适合哪些", "支持哪些", "能用哪些",
                        "适用哪些", "配合使用", "搭配使用", "一起使用", "能配合",
                        "能搭配", "配合哪些", "搭配哪些"]
    if any(p in q for p in _COMPAT_PATTERNS):
        return "unknown"
    for intent, kws in _KW_RULES:
        if any(w in q for w in kws):
            return intent
    return "unknown"


def _extract_entities_regex(query: str) -> dict:
    """从查询文本中用正则提取常见实体（降级备用）。"""
    import re
    from datetime import date as _date
    q = query.strip()

    # 快递单号：字母开头（SF/JT/YT 等）
    exp_m = re.search(r'\b([A-Za-z]{2,4}\d{8,})\b', q)
    # 工号（4~12位字母数字）
    uid_m = re.search(r'\b((?=[A-Za-z0-9]*\d)[A-Za-z0-9]{4,12})\b', q)
    # 长数字（>12位，通常是订单号）
    oid_m = re.search(r'\b(\d{12,})\b', q)
    # 是否是"我的"自助查询（用于自动带入发送者工号）
    self_query = bool(re.search(r'我的|帮我查|查一下我|看看我', q))

    # 商品关键词：去掉疑问/价格后缀
    kw = re.sub(r'^(查一下|查询?|帮我查|帮我看下?|看看|看下|搜索|找|有没有)\s*', '', q).strip()
    kw = re.sub(r'(的价格|价格是多少|多少钱|怎么样|好不好|几款|是多少|有货吗|有没有货|有没有|有吗|价格|啥价|多少|有哪款|有哪些|都有哪些|都有哪款|哪款|哪些|有哪几|什么款|什么类型|啥款|啥类型)[？?。，,。]*$', '', kw).strip()
    # 去掉"品牌的品类"中的品类词，只保留品牌/产品名核心
    # 例："摩比的书籍" → "摩比"，"学而思的玩具" → "学而思"
    _CATEGORY_WORDS = (r'书籍?|绘本|课本|教材|练习册|试卷|文具|玩具|益智玩具|桌游|拼图|积木|磁力|套装|'
                       r'商品|产品|东西|学具|教具|周边|礼品|礼盒|配件|耗材|设备|硬件|软件|'
                       r'课程|视频|音频|读物|图书|书本')
    kw = re.sub(rf'的({_CATEGORY_WORDS})[？?。，,。 ]*$', '', kw).strip()
    # 去掉末尾独立品类词（前面没有"的"也要去）
    kw = re.sub(rf'^({_CATEGORY_WORDS})$', '', kw).strip()
    # 阿拉伯数字年级/册转中文（"5年级"→"五年级"，"3册"→"三册"）
    _CN_NUM = {'1':'一','2':'二','3':'三','4':'四','5':'五','6':'六','7':'七','8':'八','9':'九'}
    kw = re.sub(r'([1-9])([年级册])', lambda m: _CN_NUM[m.group(1)] + m.group(2), kw)

    wants_tracking = bool(re.search(r'快递单号|运单号|单号是多少|怎么查快递', q))

    # 具体日期：支持 "4月29日"、"4/29"、"04-29" 等格式
    specific_date = ""
    date_m = re.search(r'(\d{1,2})[月/\-](\d{1,2})[日号]?', q)
    if date_m:
        month, day = int(date_m.group(1)), int(date_m.group(2))
        if 1 <= month <= 12 and 1 <= day <= 31:
            year = _date.today().year
            specific_date = f"{year}-{month:02d}-{day:02d}"

    if re.search(r'本月|这个月|月销|月度', q):
        period = "month"
    elif re.search(r'本周|这周|这星期|周销|周度', q):
        period = "week"
    elif re.search(r'昨天|昨日', q):
        period = "yesterday"
        if not specific_date:
            from datetime import date as _d2, timedelta as _td2
            specific_date = str(_d2.today() - _td2(days=1))
    else:
        period = "today"

    return {
        "keyword":        kw if kw != q else "",
        "user_id":        uid_m.group(1) if uid_m else "",
        "order_id":       oid_m.group(1) if (oid_m and not exp_m) else "",
        "express_no":     exp_m.group(1) if exp_m else "",
        "wants_tracking": wants_tracking,
        "self_query":     self_query,
        "period":         period,
        "specific_date":  specific_date,
    }




# ─── 对话本地日志 ────────────────────────────────────────────────
_CS_CHAT_LOG = r"D:\windows powershells\ips_cache\cs_chat.log"

def _log_chat(query: str, intent: str, result: str):
    try:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        short = (result or "（无数据）").replace('\n', ' ').strip()[:150]
        line = f"{ts}  [{intent}]  Q: {query}  →  A: {short}\n"
        with open(_CS_CHAT_LOG, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass

def _log_ops(msg: str):
    """写入运行过程日志，与 Q/A 日志同文件，供 log viewer 实时展示"""
    try:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"{ts}  [ops]  {msg}\n"
        with open(_CS_CHAT_LOG, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass


# ─── 会话历史管理 ────────────────────────────────────────────────

def _get_history(user_id: str) -> list:
    import time as _t
    if not user_id:
        return []
    entry = _conversations.get(user_id)
    if not entry:
        return []
    if _t.time() - entry["ts"] > _CONV_TTL:
        _conversations.pop(user_id, None)
        return []
    return list(entry["messages"])


def _save_history(user_id: str, messages: list):
    import time as _t
    if not user_id:
        return
    kept = messages[-_CONV_MAX:] if len(messages) > _CONV_MAX else messages
    _conversations[user_id] = {"messages": kept, "ts": _t.time()}


# ─── GitHub 图床上传 ────────────────────────────────────────────────

def _wentian_upload_b64(b64: str, filename: str = "gen.png") -> str:
    """上传 base64 图片到 GitHub dingbudong/dingyang/gen/，返回 raw 公网 URL。"""
    import base64 as _b64, time as _t, urllib.request as _ur
    if not filename or filename == "gen.png":
        filename = f"ipo_gen_{int(_t.time())}.png"
    path = f"{_GITHUB_PATH}/{filename}"
    api_url = f"https://api.github.com/repos/{_GITHUB_REPO}/contents/{path}"
    payload = json.dumps({
        "message": f"upload {filename}",
        "content": b64,
        "branch":  _GITHUB_BRANCH,
    }).encode("utf-8")
    req = _ur.Request(api_url, data=payload, method="PUT", headers={
        "Authorization": f"token {_GITHUB_TOKEN}",
        "Accept":        "application/vnd.github.v3+json",
        "Content-Type":  "application/json",
        "User-Agent":    "ipo-board-server",
    })
    resp = json.loads(_ur.urlopen(req, timeout=30).read().decode("utf-8"))
    raw_url = resp.get("content", {}).get("download_url", "")
    _log_ops(f"  🌐 GitHub 图床上传成功: {raw_url}")
    return raw_url


def _save_video_locally(src_url: str, filename: str = "") -> str:
    """下载视频到本地 _VIDEO_DIR，通过 ngrok 路由返回公网可访问 URL。"""
    import urllib.request as _ur
    if not filename:
        filename = f"ipo_video_{int(time.time())}.mp4"
    dest = os.path.join(_VIDEO_DIR, filename)
    file_bytes = _ur.urlopen(src_url, timeout=120).read()
    with open(dest, "wb") as f:
        f.write(file_bytes)
    _log_ops(f"  💾 视频已保存到本地: {dest} ({len(file_bytes)//1024}KB)")
    ngrok = _get_ngrok_url()
    if ngrok:
        pub_url = f"{ngrok}/video/{filename}"
        _log_ops(f"  🌐 视频公网链接: {pub_url}")
        return pub_url
    # fallback：返回本地路径（知音楼无法访问，但至少不丢链接）
    return src_url


# ─── 知音楼 P2P 推送（内购智能客服身份）────────────────────────────

_YACH_HOST      = "https://yach-oapi.zhiyinlou.com"
_YACH_APPKEY    = "120443374ae46e39"
_YACH_APPSECRET = "9d5660aa73c2fa9e7ffd3c129d54e6c3"
_YACH_APP_ID    = "838386470347636736"


def _yach_get_token() -> str:
    import urllib.request as _ur
    url = f"{_YACH_HOST}/gettoken?appkey={_YACH_APPKEY}&appsecret={_YACH_APPSECRET}"
    with _ur.urlopen(url, timeout=10) as r:
        data = json.loads(r.read().decode("utf-8"))
    return data.get("obj", {}).get("access_token", "") or data.get("access_token", "")


def _yach_send_p2p(work_code: str, text: str) -> bool:
    """用内购智能客服机器人身份向指定工号发送 P2P 消息（text 类型）。
    yach 的 markdown 类型只接受 title/text/image 结构化字段（实测 code:10003），无法承载通用 markdown，
    所以续发只能用 text。发送前剥离 ![alt](url) 图片标签——P2P text 不渲染图片，留着只会显示空白占位破坏体验。"""
    import urllib.request as _ur, urllib.parse as _up
    try:
        # 移除图片标签（保留链接和文本，链接 URL 用户能复制点击）
        clean = re.sub(r'!\[[^\]]*\]\([^)]+\)', '', text)
        clean = re.sub(r'\n{3,}', '\n\n', clean).strip()
        token = _yach_get_token()
        msg = json.dumps({"msgtype": "text", "text": {"content": clean}}, ensure_ascii=False)
        form = _up.urlencode({
            "access_token": token,
            "to_work_code": work_code,
            "app_id":       _YACH_APP_ID,
            "message":      msg,
        }).encode("utf-8")
        req = _ur.Request(
            f"{_YACH_HOST}/v1/single/message/send",
            data=form,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with _ur.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read().decode("utf-8"))
        ok = resp.get("errcode", -1) == 0 or resp.get("code", -1) in (0, 200)
        _log_ops(f"  📨 P2P → {work_code}: {'成功' if ok else resp}")
        return ok
    except Exception as e:
        _log_ops(f"  ✗ P2P 推送失败: {e}")
        return False


def _yach_send_p2p_markdown(work_code: str, title: str, md_body: str) -> bool:
    """用 markdown 类型向指定工号发 P2P 消息，支持图片渲染（![alt](url)）。"""
    import urllib.request as _ur, urllib.parse as _up
    try:
        token = _yach_get_token()
        msg = json.dumps({
            "msgtype":  "markdown",
            "markdown": {"title": title, "text": md_body},
        }, ensure_ascii=False)
        form = _up.urlencode({
            "access_token": token,
            "to_work_code": work_code,
            "app_id":       _YACH_APP_ID,
            "message":      msg,
        }).encode("utf-8")
        req = _ur.Request(
            f"{_YACH_HOST}/v1/single/message/send",
            data=form,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with _ur.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read().decode("utf-8"))
        ok = resp.get("errcode", -1) == 0 or resp.get("code", -1) in (0, 200)
        _log_ops(f"  📨 P2P md → {work_code}: {'✓' if ok else resp}")
        return ok
    except Exception as e:
        _log_ops(f"  ✗ P2P markdown 推送失败: {e}")
        return False


_ADMIN_YACH_UUID     = "100653271022272885"  # 丁洋老师的真实 yach UUID
_GROUP_BOT_APPKEY    = "120443374ae46e39"   # 内购商城智能客服
_GROUP_BOT_APPSECRET = "9d5660aa73c2fa9e7ffd3c129d54e6c3"

# ─── 群 ID 自动解析：实时检测（不使用持久化缓存）────────────────────────
_bot_groups_cache: list = []
_bot_group_type_map: dict = {}       # group_tid → group_type
_bot_groups_cache_ts: float = 0.0
_uuid_workcode_cache: dict = {"100653271022272885": "215734"}  # Yach UUID → 工号
_yach_user_name_cache: dict = {}         # 工号 → 知音楼真实姓名，永久内存缓存
_webhook_name_events: dict = {}          # 知音楼姓名 → threading.Event，用于 webhook→agent_chat 同步
_webhook_name_events_lock = threading.Lock()
_BOT_GROUPS_TTL = 0

# ─── 知音楼 API 令牌桶：最多 30 burst，持续 10 req/s，等待上限 30s ────────────
class _KnowallAPILimiter:
    """Thread-safe token bucket to rate-limit all outbound knowall API calls."""
    def __init__(self, rate: float = 10.0, burst: float = 30.0):
        self._rate   = rate
        self._burst  = burst
        self._tokens = burst
        self._ts     = time.time()
        self._lock   = threading.Lock()

    def acquire(self, max_wait: float = 30.0) -> bool:
        deadline = time.time() + max_wait
        interval = 1.0 / self._rate
        while True:
            with self._lock:
                now = time.time()
                self._tokens = min(self._burst, self._tokens + (now - self._ts) * self._rate)
                self._ts = now
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return True
            if time.time() + interval > deadline:
                _log_ops("  ⚠ 知音楼API令牌桶等待超时，跳过本次调用")
                return False
            time.sleep(interval)

_knowall_limiter = _KnowallAPILimiter(rate=10.0, burst=30.0)

# ─── /im/messages 3s 缓存（同一群同一时间窗口只请求一次）──────────────────────
_im_messages_cache: dict = {}        # group_tid → {"ts": float, "msgs": list}
_im_messages_cache_lock = threading.Lock()
_IM_MSG_CACHE_TTL = 3.0


# ── (用户, 群) → 上次匹配到的消息 time_ms ───────────────────────────────
# 用于状态对比：消息时间是否比上次更晚 → 判断是否"新事件"，避免误把历史消息算作来源
_USER_GROUP_LAST_MATCH_FILE = r"D:\windows powershells\ips_cache\user_group_last_match.json"
_user_group_last_match: dict = {}   # "<emp>__<group>" → ms timestamp
_user_group_last_match_lock = threading.Lock()

def _load_user_group_last_match():
    global _user_group_last_match
    try:
        if os.path.exists(_USER_GROUP_LAST_MATCH_FILE):
            with open(_USER_GROUP_LAST_MATCH_FILE, 'r', encoding='utf-8') as f:
                raw = json.load(f)
                # JSON 不能直接做 tuple key，序列化时用 "emp__group" 字符串
                _user_group_last_match = {tuple(k.split("__", 1)): int(v) for k, v in raw.items()}
    except Exception:
        _user_group_last_match = {}

def _save_user_group_last_match():
    try:
        with _user_group_last_match_lock:
            serializable = {f"{k[0]}__{k[1]}": v for k, v in _user_group_last_match.items()}
            with open(_USER_GROUP_LAST_MATCH_FILE, 'w', encoding='utf-8') as f:
                json.dump(serializable, f, ensure_ascii=False)
    except Exception:
        pass

_load_user_group_last_match()

def _bot_group_tids() -> list:
    """获取 bot 所在所有群的 group_tid（含 type=201 大群）。缓存 10 分钟。"""
    global _bot_groups_cache, _bot_groups_cache_ts, _bot_group_type_map
    import urllib.request as _ur2, time as _t
    if _t.time() - _bot_groups_cache_ts < _BOT_GROUPS_TTL and _bot_groups_cache:
        return _bot_groups_cache
    try:
        _knowall_limiter.acquire()
        _r = _ur2.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        _tk = json.loads(_r.read())["obj"]["access_token"]
        _knowall_limiter.acquire()
        _r2 = _ur2.urlopen(
            f"{_YACH_HOST}/openapi/v2/dify/robot/groups?access_token={_tk}", timeout=10
        )
        _d = json.loads(_r2.read())
        if _d.get("code") == 200:
            tids = []
            for g in _d.get("obj", []):
                tid = str(g["group_tid"])
                tids.append(tid)
                _bot_group_type_map[tid] = g.get("group_type", 0)
            _bot_groups_cache = tids
            _bot_groups_cache_ts = _t.time()
            return tids
    except Exception as _e:
        _log_ops(f"  ⚠️ bot群列表获取失败: {_e}")
    return _bot_groups_cache


def _yach_workcode_for_uuid(uuid: str) -> str:
    """通过 /user/get 查 Yach UUID 对应的工号。永久内存缓存。"""
    if uuid in _uuid_workcode_cache:
        return _uuid_workcode_cache[uuid]
    import urllib.request as _ur2
    try:
        _r = _ur2.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        _tk = json.loads(_r.read())["obj"]["access_token"]
        _r2 = _ur2.urlopen(
            f"{_YACH_HOST}/user/get?access_token={_tk}&userid={uuid}", timeout=5
        )
        _d = json.loads(_r2.read())
        if _d.get("code") == 200:
            obj = _d.get("obj") or {}
            wc = obj.get("work_code", "")
            name = obj.get("name", "")
            if wc:
                _uuid_workcode_cache[uuid] = wc
                if name:
                    _yach_user_name_cache[wc] = name
                    threading.Thread(target=_save_yach_name_cache, daemon=True).start()
                return wc
    except Exception:
        pass
    return ""


def _yach_lookup_user_name(work_code: str) -> str:
    """通过工号查知音楼真实姓名。先查缓存，未命中则调 /user/get_by_workcode。"""
    if not work_code:
        return ""
    if work_code in _yach_user_name_cache:
        return _yach_user_name_cache[work_code]
    import urllib.request as _ur3
    try:
        _r = _ur3.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        _tk = json.loads(_r.read())["obj"]["access_token"]
        _r2 = _ur3.urlopen(
            f"{_YACH_HOST}/user/get_by_workcode?access_token={_tk}&work_code={work_code}",
            timeout=5
        )
        _d = json.loads(_r2.read())
        if _d.get("code") == 200:
            name = (_d.get("obj") or {}).get("name", "")
            if name:
                _yach_user_name_cache[work_code] = name
                threading.Thread(target=_save_yach_name_cache, daemon=True).start()
                return name
    except Exception:
        pass
    return ""


def _fetch_im_messages_cached(token: str, group_tid: str, now_sec: int) -> list:
    """Fetch /im/messages for group_tid with 3s in-process cache to avoid redundant API hits
    when multiple concurrent requests arrive for the same group."""
    import urllib.request as _ur2
    with _im_messages_cache_lock:
        cached = _im_messages_cache.get(group_tid)
        if cached and (time.time() - cached["ts"]) < _IM_MSG_CACHE_TTL:
            return cached["msgs"]
    _knowall_limiter.acquire()
    url = (f"{_YACH_HOST}/openapi/v2/im/messages"
           f"?access_token={token}"
           f"&group_id={group_tid}"
           f"&start_time={now_sec - 3600}"
           f"&end_time={now_sec}"
           f"&page_size=30")
    with _ur2.urlopen(url, timeout=10) as r:
        resp = json.loads(r.read().decode())
    msgs = (resp.get("obj") or {}).get("messages") or [] if resp.get("code") == 200 else []
    with _im_messages_cache_lock:
        _im_messages_cache[group_tid] = {"ts": time.time(), "msgs": msgs}
    return msgs


def _detect_source_group(employee_id: str, query_text: str, candidate_tids: list, user_uuid: str = "") -> str:
    """内容驱动 + API fallback：在候选群中找到发送了此查询的用户消息 → 返回来源群 ID。
    返回值：
      - <群ID>: 找到内容匹配的群 / API 全部群无消息时退回 candidates[0]
      - "":   API 有消息但用户最新消息不匹配 query → 真私聊
    """
    import urllib.request as _ur
    try:
        _knowall_limiter.acquire()
        _r = _ur.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        token = json.loads(_r.read().decode())["obj"]["access_token"]
    except Exception as e:
        _log_ops(f"  ⚠️ detect_source token失败: {e}")
        return ""
    if not user_uuid:
        user_uuid = next((uid for uid, wc in _uuid_workcode_cache.items() if wc == employee_id), "")
    match_key = (query_text[:10] if len(query_text) >= 10 else query_text).strip()
    import time as _t_ds
    now_sec = int(_t_ds.time())
    _log_ops(f"  🔍 detect_source 开始: emp={employee_id} user_uuid={user_uuid[:10] if user_uuid else 'N/A'} match_key=\"{match_key}\" candidates={candidate_tids}")

    new_events = []   # [(group_tid, match_time_ms), ...]
    state_updates = []  # 待更新的 (key, time) 记录
    for group_tid in candidate_tids:
        try:
            msgs = _fetch_im_messages_cached(token, group_tid, now_sec)
            user_msgs = [
                m for m in msgs
                if m.get("userType") == 1
                and ((user_uuid and m.get("uuid") == user_uuid) or m.get("workCode") == employee_id)
            ]
            if not user_msgs:
                continue
            matched = [m for m in user_msgs if match_key and match_key in str(m.get("content", ""))]
            if not matched:
                continue
            latest_match = sorted(matched, key=lambda m: m.get("time", 0), reverse=True)[0]
            t_ms = latest_match.get("time", 0)
            t_str = _t_ds.strftime('%H:%M:%S', _t_ds.localtime(t_ms/1000)) if t_ms else "?"

            key = (employee_id, group_tid)
            prev_t_ms = _user_group_last_match.get(key, 0)
            is_new = t_ms > prev_t_ms
            reason = "新事件" if is_new else "已见过"
            _log_ops(f"  🔍 detect群{group_tid}: 最新匹配 [{t_str}] t={t_ms} prev={prev_t_ms} → {reason}")
            state_updates.append((key, t_ms))
            if is_new:
                new_events.append((group_tid, t_ms))
        except Exception as e:
            _log_ops(f"  ⚠️ detect群{group_tid}失败: {e}")

    # 不论是否定位到来源群，都把"已见过"的状态推进到最新（避免下次重复触发）
    for key, t_ms in state_updates:
        if t_ms > _user_group_last_match.get(key, 0):
            _user_group_last_match[key] = t_ms
    if state_updates:
        _save_user_group_last_match()

    if not new_events:
        _log_ops(f"  🔍 detect_source 结束: 各群匹配都是已见过的旧消息 → 判定私聊")
        return ""
    new_events.sort(key=lambda x: x[1], reverse=True)
    winner = new_events[0][0]
    _log_ops(f"  🎯 来源群定位（新事件）: {employee_id} → {winner}")
    return winner


def _fetch_group_sender(group_id: str, query_text: str) -> tuple:
    """通过内容匹配在群里找到发送此查询的用户，返回 (sender_name, work_code)。
    查最近30条消息，找到内容匹配 query_text 的消息 → 提取发件人信息。
    """
    import urllib.request as _ur
    try:
        _knowall_limiter.acquire()
        _r = _ur.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        token = json.loads(_r.read().decode())["obj"]["access_token"]
    except Exception as e:
        _log_ops(f"  ⚠️ fetch_group_sender token失败: {e}")
        return ("", "")
    try:
        import time as _t_fgs
        now_sec = int(_t_fgs.time())
        msgs = _fetch_im_messages_cached(token, group_id, now_sec)
        if not msgs:
            return ("", "")
        match_key = (query_text[:10] if len(query_text) >= 10 else query_text).strip()
        # 字段：senderName, workCode, uuid, content, time(ms), userType (1=用户, 2=机器人)
        # 找内容匹配的用户消息
        best_msg = None
        if match_key:
            for msg in msgs:
                if msg.get("userType") != 1:
                    continue
                if match_key in str(msg.get("content", "")):
                    best_msg = msg
                    break
        # 兜底：最近的用户消息
        if best_msg is None:
            for msg in msgs:
                if msg.get("userType") == 1:
                    best_msg = msg
                    break
        if best_msg is None:
            return ("", "")
        sender_name = best_msg.get("senderName", "") or ""
        work_code   = best_msg.get("workCode", "") or ""
        _log_ops(f"  🔍 fetch_group_sender: name={sender_name!r} workCode={work_code!r}")
        return (sender_name, work_code)
    except Exception as e:
        _log_ops(f"  ⚠️ fetch_group_sender 查询失败: {e}")
        return ("", "")


def _detect_source_group_by_content(query_text: str, candidate_tids: list) -> str:
    """纯内容匹配群解析：不依赖用户身份，直接在候选群中扫最近消息找 query_text。
    用于未绑定工号且 UUID 不可匹配（Dify UUID）的用户从群聊发起的请求。
    与 _detect_source_group 一致：只有比上次记录更新的消息才算新事件，防止同内容
    私聊/群聊混发时重复路由到群。
    """
    import urllib.request as _ur2
    try:
        _knowall_limiter.acquire()
        _r2 = _ur2.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        token = json.loads(_r2.read().decode())["obj"]["access_token"]
    except Exception as e:
        _log_ops(f"  ⚠️ detect_content token失败: {e}")
        return ""
    import time as _t_dc
    match_key = (query_text[:10] if len(query_text) >= 10 else query_text).strip()
    if not match_key:
        return ""
    now_sec = int(_t_dc.time())
    new_events = []
    state_updates = []
    for group_tid in candidate_tids:
        try:
            msgs = _fetch_im_messages_cached(token, group_tid, now_sec)
            for m in msgs:
                if m.get("userType") == 1 and match_key in str(m.get("content", "")):
                    t_ms = m.get("time", 0)
                    key = (f"c__{match_key}", group_tid)
                    prev_t_ms = _user_group_last_match.get(key, 0)
                    is_new = t_ms > prev_t_ms
                    _log_ops(f"  🔍 detect_content群{group_tid}: t={t_ms} prev={prev_t_ms} → {'新事件' if is_new else '已见过'}")
                    state_updates.append((key, t_ms))
                    if is_new:
                        new_events.append((group_tid, t_ms))
                    break
        except Exception as e:
            _log_ops(f"  ⚠️ detect_content群{group_tid}失败: {e}")
    for key, t_ms in state_updates:
        if t_ms > _user_group_last_match.get(key, 0):
            _user_group_last_match[key] = t_ms
    if state_updates:
        _save_user_group_last_match()
    if not new_events:
        _log_ops(f"  🔍 detect_content 结束: 各群匹配都是已见过的旧消息 → 判定私聊")
        return ""
    new_events.sort(key=lambda x: x[1], reverse=True)
    winner = new_events[0][0]
    _log_ops(f"  🎯 纯内容匹配群（新事件）: {winner}")
    return winner


def _sniff_sender_workcode(query_text: str) -> tuple:
    """扫描群消息，找到发送 query_text 的员工工号，用于超长回复续发。
    不更新 _user_group_last_match 状态（避免干扰去重逻辑）。
    返回 (group_tid, work_code)；找不到返回 ("", "")。
    """
    import urllib.request as _ur_ss
    try:
        _knowall_limiter.acquire()
        _r_ss = _ur_ss.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        token = json.loads(_r_ss.read().decode())["obj"]["access_token"]
    except Exception as _e_ss:
        _log_ops(f"  ⚠️ sniff_sender token失败: {_e_ss}")
        return ("", "")
    import time as _t_ss
    now_sec = int(_t_ss.time())
    match_key = (query_text[:10] if len(query_text) >= 10 else query_text).strip()
    if not match_key:
        return ("", "")
    all_tids = _bot_group_tids()
    small_tids = [t for t in all_tids if _bot_group_type_map.get(t, 0) != 201]
    for group_tid in small_tids:
        try:
            msgs = _fetch_im_messages_cached(token, group_tid, now_sec)
            for m in msgs:
                if m.get("userType") == 1 and match_key in str(m.get("content", "")):
                    wc = m.get("workCode", "") or ""
                    if wc:
                        _log_ops(f"  🔍 sniff_sender: 群{group_tid} → workCode={wc!r}")
                        return (group_tid, wc)
        except Exception as _e_gs:
            _log_ops(f"  ⚠️ sniff_sender群{group_tid}失败: {_e_gs}")
    return ("", "")


def _resolve_yach_group(dify_conv_id: str, employee_id: str, query_text: str = "", user_uuid: str = "") -> str:
    """群来源解析：通过扫描知音楼群消息 API 判断消息来自哪个群。
    Dify 始终发 is_group=False、group_id 始终是会话 UUID，无法直接区分群/私聊，只能靠这里判断。
    - 有工号：身份匹配（workCode 过滤），找不到直接判私聊，不做内容兜底
    - 无工号：纯内容匹配，找到群后由调用方通过 _fetch_group_sender 取 workCode
    两条路均使用 _user_group_last_match 状态跟踪，防止同一群消息重复触发。
    """
    if not query_text:
        return ""

    all_tids = _bot_group_tids()
    small_tids = [t for t in all_tids if _bot_group_type_map.get(t, 0) != 201]

    _log_ops(f"  🔍 群解析: 扫描 {len(small_tids)} 个小群: {small_tids}")

    if not small_tids:
        _log_ops(f"  🗺️ 群解析: 无小群 → 私聊（P2P）")
        return ""

    # 有工号或有效知音楼UUID（18位数字）→ 身份匹配，找不到直接判私聊（不做内容兜底，防误匹配）
    yach_uuid = user_uuid if (user_uuid and "-" not in user_uuid) else ""
    if employee_id or yach_uuid:
        gid = _detect_source_group(employee_id, query_text, small_tids, user_uuid=yach_uuid)
        if gid:
            return gid
        _log_ops(f"  🗺️ 群解析: 已绑定用户身份未匹配任何群 → 私聊（P2P）")
        return ""

    # 兜底：未绑定用户（无工号且无知音楼UUID）→ 纯内容匹配
    gid = _detect_source_group_by_content(query_text, small_tids)
    if gid:
        return gid

    _log_ops(f"  🗺️ 群解析: 内容未匹配任何候选群 → 私聊（P2P）")
    return ""


def _yach_group_send_with_retry(form: bytes, max_retries: int = 3) -> dict:
    """POST to /group/robot/message/send with exponential back-off (1s/2s/4s) on failure."""
    import urllib.request as _ur_retry, time as _t_retry
    last_resp: dict = {}
    for attempt in range(max_retries + 1):
        try:
            _knowall_limiter.acquire()
            req = _ur_retry.Request(
                f"{_YACH_HOST}/group/robot/message/send",
                data=form,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                method="POST",
            )
            with _ur_retry.urlopen(req, timeout=15) as r:
                last_resp = json.loads(r.read().decode("utf-8"))
            if last_resp.get("code", -1) in (0, 200):
                return last_resp
            _log_ops(f"  ⚠ 群发送失败({attempt+1}/{max_retries+1}): {last_resp}")
        except Exception as e:
            _log_ops(f"  ⚠ 群发送异常({attempt+1}/{max_retries+1}): {e}")
            last_resp = {"error": str(e)}
        if attempt < max_retries:
            _t_retry.sleep(2 ** attempt)  # 1s, 2s, 4s
    return last_resp


def _yach_send_group_at(reason: str, group_id: str = "", user_id: str = "", full_text: str = None) -> bool:
    """在用户所在群发送消息并 @丁洋老师（/group/robot/message/send）。
    full_text: 若传入，直接用作消息内容（含 @丁洋）；否则用默认格式。
    group_id: Dify conversation UUID 或直接是 Yach 数字群 ID，均自动处理。
    user_id: 消息发送者工号，用于首次自动解析 Dify UUID → Yach 群 ID。
    """
    import urllib.request as _ur, urllib.parse as _up
    real_group_id = group_id
    # 需要解析：group_id 为空 或 包含"-"（Dify UUID）
    if not group_id or "-" in group_id:
        real_group_id = _resolve_yach_group(group_id, user_id)
    if not real_group_id:
        _log_ops(f"  ⚠️ 群@跳过：用户 {user_id} 不在任何 bot 群，或群ID无法解析")
        return False
    try:
        _knowall_limiter.acquire()
        _resp = _ur.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        token = json.loads(_resp.read().decode("utf-8"))["obj"]["access_token"]
        content = full_text if full_text else f"老师，有用户咨询，请跟进：{reason[:80]}"
        msg = json.dumps({
            "msgtype": "text",
            "text":    {"content": content},
            "at_work_codes": ["215734"],
            "at": {"atWorkCodes": ["215734"], "isAtAll": False},
        }, ensure_ascii=False)
        form = _up.urlencode({
            "access_token": token,
            "group_id":     real_group_id,
            "message":      msg,
        }).encode("utf-8")
        resp = _yach_group_send_with_retry(form)
        ok = resp.get("code", -1) in (0, 200)
        _log_ops(f"  📢 群@丁洋老师(group={real_group_id}): {'成功' if ok else resp}")
        return ok
    except Exception as e:
        _log_ops(f"  ✗ 群@发送失败: {e}")
        return False



def _yach_send_group_msg(group_id: str, text: str, user_id: str = "") -> bool:
    """在群内发送普通文本消息（不 @任何人）。group_id 为真实 group_tid。"""
    import urllib.request as _ur, urllib.parse as _up
    real_group_id = group_id
    if not group_id or "-" in group_id:
        real_group_id = _resolve_yach_group(group_id, user_id)
    if not real_group_id:
        _log_ops(f"  ⚠️ 群消息跳过：群ID无法解析 group_id={group_id}")
        return False
    try:
        _knowall_limiter.acquire()
        _resp = _ur.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        token = json.loads(_resp.read().decode("utf-8"))["obj"]["access_token"]
        msg = json.dumps({"msgtype": "text", "text": {"content": text}}, ensure_ascii=False)
        form = _up.urlencode({
            "access_token": token,
            "group_id":     real_group_id,
            "message":      msg,
        }).encode("utf-8")
        req = _ur.Request(
            f"{_YACH_HOST}/group/robot/message/send",
            data=form,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with _ur.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read().decode("utf-8"))
        ok = resp.get("code", -1) in (0, 200)
        _log_ops(f"  📢 群消息(group={real_group_id}): {'成功' if ok else resp}")
        return ok
    except Exception as e:
        _log_ops(f"  ✗ 群消息发送失败: {e}")
        return False

def _yach_send_group_image(group_id: str, image_url: str, caption: str = "🎨 图片生成好了！", user_id: str = "") -> bool:
    """在群内发送图片消息（markdown 类型，渲染 ![](url)）。"""
    import urllib.request as _ur, urllib.parse as _up
    real_group_id = group_id
    if not group_id or "-" in group_id:
        real_group_id = _resolve_yach_group(group_id, user_id)
    if not real_group_id:
        _log_ops(f"  ⚠️ 群图片跳过：群ID无法解析 group_id={group_id}")
        return False
    try:
        _knowall_limiter.acquire()
        _resp = _ur.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        token = json.loads(_resp.read().decode("utf-8"))["obj"]["access_token"]
        md_body = caption + chr(10) + chr(10) + "![图片](" + image_url + ")"
        msg = json.dumps({"msgtype": "markdown", "markdown": {"title": caption, "text": md_body}}, ensure_ascii=False)
        form = _up.urlencode({
            "access_token": token,
            "group_id":     real_group_id,
            "message":      msg,
        }).encode("utf-8")
        req = _ur.Request(
            f"{_YACH_HOST}/group/robot/message/send",
            data=form,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with _ur.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read().decode("utf-8"))
        ok = resp.get("code", -1) in (0, 200)
        _log_ops(f"  🖼️ 群图片(group={real_group_id}): {'成功' if ok else resp}")
        return ok
    except Exception as e:
        _log_ops(f"  ✗ 群图片发送失败: {e}")
        return False


def _yach_send_group_markdown(group_id: str, title: str, md_body: str, user_id: str = "") -> bool:
    """在群内发送 markdown 消息（渲染链接/文字，不渲染视频播放器）。"""
    import urllib.request as _ur, urllib.parse as _up
    real_group_id = group_id
    if not group_id or "-" in group_id:
        real_group_id = _resolve_yach_group(group_id, user_id)
    if not real_group_id:
        _log_ops(f"  ⚠️ 群markdown跳过：群ID无法解析 group_id={group_id}")
        return False
    try:
        _knowall_limiter.acquire()
        _resp = _ur.urlopen(
            f"{_YACH_HOST}/gettoken?appkey={_GROUP_BOT_APPKEY}&appsecret={_GROUP_BOT_APPSECRET}",
            timeout=10
        )
        token = json.loads(_resp.read().decode("utf-8"))["obj"]["access_token"]
        msg = json.dumps({"msgtype": "markdown", "markdown": {"title": title, "text": md_body}}, ensure_ascii=False)
        form = _up.urlencode({
            "access_token": token,
            "group_id":     real_group_id,
            "message":      msg,
        }).encode("utf-8")
        req = _ur.Request(
            f"{_YACH_HOST}/group/robot/message/send",
            data=form,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with _ur.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read().decode("utf-8"))
        ok = resp.get("code", -1) in (0, 200)
        _log_ops(f"  📢 群markdown(group={real_group_id}): {chr(39) + chr(39).join([chr(39).join([str(ok)])]) + chr(39)}")
        return ok
    except Exception as e:
        _log_ops(f"  ✗ 群markdown发送失败: {e}")
        return False



# ─── 委派任务：通过 agent/chat 向数字伙伴 chatflow 发消息 ───────────
# 所有 bot 均通过 /openapi/v2/agent/chat 向对应数字伙伴发消息，
# 数字伙伴的 Dify chatflow 接收后自行执行任务（写 Teable 或调用外部接口）。
# 智能客服只负责发消息，不参与任务执行。

_DELEGATE_REGISTRY = {
    "selection": {
        "appkey":          "04cd9316ea799b5e",
        "appsecret":       "33465270c4e2088a8e1626650600ce8a",
        "p2p_msg":         "内购选品",
        "teable_table":    "tblr9vOXaPBs180xBr9",
        "teable_token":    "teable_acc0p3f5Wzz0NRf7OqM_3F9pu44PSpF8IEd7tk++koloKeWq6NC2S0ItJYUOvM8=",
        "teable_field":    "内购选品",
        "teable_value":    "内购选品",
        "bot_name":        "内购选品助手",
        "confirm_keyword": "确认选品",
        "eta":             "10~20 分钟",
    },
    "selection_upload": {
        "appkey":          "04cd9316ea799b5e",
        "appsecret":       "33465270c4e2088a8e1626650600ce8a",
        # p2p_msg 和 teable_value 动态构建：image_upload:::{sheet_url}
        "teable_table":    "tblr9vOXaPBs180xBr9",
        "teable_token":    "teable_acc0p3f5Wzz0NRf7OqM_3F9pu44PSpF8IEd7tk++koloKeWq6NC2S0ItJYUOvM8=",
        "teable_field":    "内购选品",
        "bot_name":        "内购选品助手（导入明细）",
        "confirm_keyword": "确认选品",
        "eta":             "3~5 分钟",
    },
    "replenishment": {
        "appkey":          "a964fec003f72b0e",
        "appsecret":       "3967215521d4ad3eecfb9384e28f1b6f",
        "p2p_msg":         "内购补货",
        "teable_table":    "tbl7IncMAl7url7wKKh",
        "teable_token":    "teable_accJDDZk23KWl5v2bKJ_02VskdGD1vMu/RzPjieeRgIEF6D7xttSLIVmAmr3Npk=",
        "teable_field":    "内购补货",
        "teable_value":    "智能客服触发",
        "bot_name":        "内购补货小助理",
        "confirm_keyword": "确认补货",
        "eta":             "5~15 分钟",
    },
    "new_product": {
        "appkey":          "ef57ae908900f9fd",
        "appsecret":       "83dd122d77575ab7be2ff80a447400a0",
        "p2p_msg":         "内购上新",
        "teable_table":    "tbl11sCqQanpy6V0c7z",
        "teable_token":    "teable_accyMsfXF7HDTO7F50T_he00Z50Epx8W051QlYPAqhGZ44YCY9ldmLm+mGa+YF0=",
        "teable_field":    "商品上架",
        "teable_value":    "内购上新",
        "bot_name":        "内购上新助手",
        "confirm_keyword": "确认上新",
        "eta":             "2~5 分钟",
    },
    "upload": {
        "appkey":          "ef57ae908900f9fd",
        "appsecret":       "83dd122d77575ab7be2ff80a447400a0",
        "p2p_msg":         "商品上架",
        "teable_table":    "tbl11sCqQanpy6V0c7z",
        "teable_token":    "teable_accyMsfXF7HDTO7F50T_he00Z50Epx8W051QlYPAqhGZ44YCY9ldmLm+mGa+YF0=",
        "teable_field":    "商品上架",
        "teable_value":    "商品上架",
        "bot_name":        "九凤上架助手",
        "confirm_keyword": "确认上架",
        "eta":             "5~10 分钟",
    },
    "wms_audit": {
        "appkey":          "958b3e6c4efb148b",
        "appsecret":       "ed9ef8a3408105d1848d2bb160dad4e6",
        "bot_name":        "WMS出入库审核助手",
        "confirm_keyword": "确认审核",
        "eta":             "5~15 分钟",
    },
}

_WMS_WAREHOUSE_MAP = {
    "黄陂": "武汉黄陂仓", "武汉": "武汉黄陂仓",
    "内购": "内购仓",
    "武清": "武清仓",
}


def _delegate_teable_write(bot: str, params: dict = None) -> str:
    """触发目标数字伙伴执行任务。
    步骤：
      1. 用数字伙伴自己的 appkey/appsecret 向丁洋（215734）发 P2P（关键词可见于聊天框）
      2. P2P 成功后写入数字伙伴对应的 Teable 触发表
      3. 数字伙伴守护进程检测到新记录后自行执行任务
    wms_audit 例外：直接通过 agent/chat 触发（无 Teable 机制）。
    params: wms_audit 需 {qc_no, qr_no, warehouse}；selection_upload 需 {sheet_url}
    """
    import urllib.request as _ur
    import urllib.parse as _up
    import time as _t
    conf = _DELEGATE_REGISTRY.get(bot)
    if not conf:
        return f"未知 bot 标识: {bot}"

    def _get_tok(ak, ase):
        return json.loads(_ur.urlopen(
            f'https://yach-oapi.zhiyinlou.com/gettoken?appkey={ak}&appsecret={ase}',
            timeout=15
        ).read().decode('utf-8'))['obj']['access_token']

    def _p2p(tok, msg):
        """用数字伙伴身份向 215734 发 P2P，消息在聊天框可见。"""
        body = _up.urlencode({
            'access_token': tok,
            'to_work_code': '215734',
            'message': json.dumps({'msgtype': 'text', 'text': {'content': msg}}, ensure_ascii=False),
        }).encode('utf-8')
        raw = _ur.urlopen(_ur.Request(
            'https://yach-oapi.zhiyinlou.com/v1/single/message/send',
            data=body,
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            method='POST',
        ), timeout=15).read()
        resp = json.loads(raw.decode('utf-8'))
        code = resp.get('errcode', resp.get('code', -1))
        ok = code in (0, 200)
        _log_ops(f"  {'✅' if ok else '✗'} P2P({conf['bot_name']}→215734) msg={msg[:40]} code={code}")
        return ok

    def _teable_trigger(table_id, teable_token, field, value):
        """写入 Teable 触发记录，守护进程检测后执行任务。"""
        payload = json.dumps({
            'fieldKeyType': 'name',
            'records': [{'fields': {field: value}}],
        }, ensure_ascii=False).encode('utf-8')
        raw = _ur.urlopen(_ur.Request(
            f'https://yach-teable.zhiyinlou.com/api/table/{table_id}/record',
            data=payload,
            headers={
                'Authorization': f'Bearer {teable_token}',
                'Content-Type': 'application/json',
            },
            method='POST',
        ), timeout=15).read()
        resp = json.loads(raw.decode('utf-8'))
        ok = bool(resp.get('records') or resp.get('id'))
        _log_ops(f"  {'✅' if ok else '✗'} Teable 写入: table={table_id} {field}={value}")
        return ok

    tok = _get_tok(conf["appkey"], conf["appsecret"])

    # ── wms_audit：agent/chat（无 Teable 机制）──────────────────────────
    if bot == "wms_audit":
        p = params or {}
        qc_no   = p.get("qc_no", "").strip()
        qr_no   = p.get("qr_no", "").strip()
        wh_hint = p.get("warehouse", "").strip()
        wh_name = "武清仓"
        for k, v in _WMS_WAREHOUSE_MAP.items():
            if k in wh_hint:
                wh_name = v
                break
        if not qc_no or not qr_no:
            return "WMS审核委派失败：缺少出库单号（QC）或入库单号（QR）。"
        query = f"审核wms {qc_no} {wh_name} {qr_no} {wh_name}"
        _log_ops(f"  📨 agent/chat → {conf['bot_name']}  query={query}")
        pl = json.dumps({
            'access_token': tok, 'query': query,
            'biz_id': f"ipo-{int(_t.time())}", 'msg_type': 'text',
        }, ensure_ascii=False).encode('utf-8')
        _ur.urlopen(_ur.Request(
            'https://yach-oapi.zhiyinlou.com/openapi/v2/agent/chat',
            data=pl, headers={'Content-Type': 'application/json; charset=utf-8'}, method='POST',
        ), timeout=15).read()
        _log_ops(f"  ✅ 消息已送达 {conf['bot_name']}")
        return (
            f"已通知WMS出入库审核助手！\n"
            f"出库单：{qc_no}（{wh_name}）\n"
            f"入库单：{qr_no}（{wh_name}）\n"
            f"结果会通过知音楼推送给丁洋老师。"
        )

    # ── selection_upload：动态关键词 ────────────────────────────────────
    if bot == "selection_upload":
        sheet_url = (params or {}).get("sheet_url", "").strip()
        if not sheet_url:
            return "选品导入失败：缺少表格 URL，请重新发送表格链接。"
        keyword = f"image_upload:::{sheet_url}"
        eta = conf.get('eta', '几分钟')
        full_msg = f"选品明细导入\n收到！选品明细导入任务已启动，正在处理中，预计 {eta}，完成后会通知丁洋老师。"
        if not _p2p(tok, full_msg):
            return "选品导入通知失败：P2P 发送错误，请稍后重试。"
        _teable_trigger(conf['teable_table'], conf['teable_token'], conf['teable_field'], keyword)
        return f"已通知{conf['bot_name']}！\n表格：{sheet_url}\n结果会通过知音楼推送给丁洋老师。"

    # ── 其他 bot：P2P 发关键词（可见）→ Teable 写入触发 ─────────────────
    eta = conf.get('eta', '几分钟')
    full_msg = f"{conf['p2p_msg']}\n收到！任务已启动，正在执行中，预计 {eta}，完成后会通知丁洋老师。"
    if not _p2p(tok, full_msg):
        return f"通知{conf['bot_name']}失败：P2P 发送错误，请稍后重试。"
    _teable_trigger(conf['teable_table'], conf['teable_token'], conf['teable_field'], conf['teable_value'])
    return f"已通知{conf['bot_name']}！\n结果会通过知音楼推送给丁洋老师。"


# ─── gpt-image-2 文生图 ──────────────────────────────────────────

def _generate_image(prompt: str) -> str:
    """调用 gpt-image-2 生成图片，上传文图图床后返回永久 URL。
    串行排队执行（Semaphore），同一时刻只有 1 个请求在跑，自然满足 RPM:5。"""
    if _http is None:
        return "图片生成服务暂不可用"
    import time as _t, base64 as _b64
    _image_gen_sem.acquire()
    try:
        hdrs = {"api-key": _IMAGE_API_KEY, "Content-Type": "application/json; charset=utf-8"}
        payload = {"model": "gpt-image-2", "prompt": prompt, "size": "1024x1024"}
        payload_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        last_err = None
        for attempt in range(3):
            try:
                if attempt > 0:
                    _log_ops(f"  ↻ 图片生成重试（{attempt}/2）…")
                resp = _http.post(_IMAGE_GEN_URL, headers=hdrs, data=payload_bytes, timeout=300,
                                  proxies={"http": None, "https": None})
                _log_ops(f"  → 图片接口响应 status={resp.status_code}")
                if resp.status_code in (429, 403):
                    _log_ops(f"  ⚠ 图片接口 {resp.status_code} 限流，等待 65s 后重试（{attempt + 1}/3）…")
                    _t.sleep(65)
                    continue
                if resp.status_code != 200:
                    _log_ops(f"  ✗ 图片接口返回 {resp.status_code}: {resp.text[:300]}")
                resp.raise_for_status()
                data = resp.json().get("data", [])
                if not data:
                    return "图片生成失败，请换个描述再试"
                item = data[0]
                b64 = item.get("b64_json", "")
                if b64:
                    fname = f"ipo_gen_{int(_t.time())}.png"
                    img_url = _wentian_upload_b64(b64, fname)
                else:
                    img_url = item.get("url", "")
                if not img_url:
                    return "图片生成失败，请换个描述再试"
                return img_url
            except Exception as e:
                last_err = e
                err_str = str(e)
                if any(kw in err_str for kw in ('10054', 'timed out', 'ConnectionError',
                                                 'RemoteDisconnected', 'Connection reset',
                                                 'Connection aborted', 'ChunkedEncodingError')):
                    _log_ops(f"  ⚠ 图片生成网络错误（{attempt + 1}/3）: {err_str[:80]}")
                    continue
                _log_ops(f"  ✗ 图片生成失败（非网络错误，不重试）: {err_str[:120]}")
                break
        _log_ops(f"  ✗ 图片生成最终失败: {last_err}")
        return "图片生成暂时失败"
    finally:
        _image_gen_sem.release()


# ─── 图片下载 → base64（解决 Dify 内部 URL 无法被大模型直接访问的问题）────

def _fetch_image_b64(url: str) -> str:
    """把图片 URL 下载到本地，返回 'data:image/jpeg;base64,<b64>' 格式字符串。
    失败时返回空字符串。适用于 Dify 内部 URL、公网 URL 等各种来源。
    """
    import base64 as _b64
    try:
        resp = _http.get(url, timeout=20)
        if resp.status_code != 200:
            _log_ops(f"  ⚠ 图片下载失败 {resp.status_code}: {url[:80]}")
            return ""
        raw = resp.content
        ct = resp.headers.get("Content-Type", "image/jpeg").split(";")[0].strip()
        if ct not in ("image/jpeg", "image/png", "image/gif", "image/webp", "image/svg+xml"):
            ct = "image/jpeg"
        b64str = _b64.b64encode(raw).decode("ascii")
        return f"data:{ct};base64,{b64str}"
    except Exception as e:
        _log_ops(f"  ⚠ 图片下载异常: {e}")
        return ""


# ─── 图片识别（claude-sonnet 优先，失败自动接力 claude-opus → qwen）────

def _describe_image(image_content: list, query: str) -> str:
    """识图：claude-sonnet-4.6 优先，任何错误立即换下一个 vision 模型。
    image_content: [{"type":"text","text":...}, {"type":"image_url","image_url":{"url":...}}]
    image_url 须为 base64 data URI。
    """
    if _http is None:
        return ""

    _vision_chain = [
        next((b for b in _BACKENDS if b["model"] == "claude-sonnet-4.6"), None),  # 首选
        next((b for b in _BACKENDS if b["model"] == "claude-opus-4.7"), None),    # 接力1
        next((b for b in _BACKENDS if b["model"] == "qwen3.5-omni-flash"), None), # 接力2
    ]
    _vision_chain = [b for b in _vision_chain if b]

    prompt_text = (
        "请对这张图片进行全图综合识别，覆盖以下所有维度：\n"
        "1. 【图片中的所有文字】：原文照录图中出现的每一处文字（标题、副标题、品牌名、系列名、型号、说明文字等），"
        "重点关注最显眼/最大的文字，这通常就是商品名称。\n"
        "2. 【商品视觉特征】：商品类型（书籍/玩具/食品/电子产品等）、外观颜色、材质、包装形式、数量规格等。\n"
        "3. 【整体判断】：综合以上信息，这最可能是什么商品？给出最有可能的商品名称或搜索关键词。\n"
        "注意：分析时覆盖整张图片，不要只关注局部；图中的装饰性卡通角色、吉祥物不是商品名。\n"
        f"用户的问题：{query or '请识别这是什么商品'}"
    )
    patched = []
    for item in image_content:
        if item.get("type") == "text":
            patched.append({"type": "text", "text": prompt_text})
        else:
            patched.append(item)

    hdrs = {"Authorization": _GLM_AUTH, "Content-Type": "application/json"}
    _image_desc_sem.acquire()   # 排队，先来先服务，无超时
    try:
        for backend in _vision_chain:
            try:
                payload = {
                    "model": backend["model"],
                    "messages": [{"role": "user", "content": patched}],
                    "max_tokens": 800,
                }
                resp = _http.post(_GLM_URL, headers=hdrs, json=payload, timeout=None)
                if resp.status_code in (429, 403, 502, 503, 504):
                    _log_ops(f"  ⚠ [{backend['model']}] 图片识别 HTTP {resp.status_code}，换下一个模型")
                    continue
                resp.raise_for_status()
                desc = (resp.json()["choices"][0]["message"].get("content") or "").strip()
                _log_ops(f"  📷 [{backend['model']}] 图片描述: {desc[:100]}")
                return desc
            except Exception as e:
                _log_ops(f"  ⚠ [{backend['model']}] 图片识别失败: {e}，换下一个模型")
                continue
    finally:
        _image_desc_sem.release()

    _log_ops("  ✗ 所有 vision 模型均失败，放弃识图")
    return ""


# ─── 销售数据：从 Teable 读取 ────────────────────────────────────

_TEABLE_ORDER_TABLE   = "tblWh60leD6kYVW7Crl"  # 内购订单明细
_TEABLE_OFFLINE_TABLE = "tbly5g9ni6Lofaig0T4"  # 内购商城线下收款
_TEABLE_OFFLINE_TOKEN = "teable_acc9NhBWQLkPAz1oe5M_s+8C5iWm2Ten+rLsP2T3jG4yuP/Xpa9ma9o1y5zd4DQ="
_TEABLE_PRODUCT_DETAIL_TABLE = "tbl7g0OGoZKaYlRylTj"  # 九凤商品明细（含成本价+可售库存）


def _query_offline_sales(date_from: str, date_to: str):
    """从「内购商城线下收款」多维表拉取指定日期区间内的记录，返回 (total_amount, items)。
    items: list of (日期, 活动事件, 金额)"""
    import urllib.request as _ur
    headers = {"Authorization": f"Bearer {_TEABLE_OFFLINE_TOKEN}"}
    all_rows, skip, take = [], 0, 1000
    while True:
        url = (f"{_TEABLE_BASE}/api/table/{_TEABLE_OFFLINE_TABLE}/record"
               f"?fieldKeyType=name&take={take}&skip={skip}")
        req = _ur.Request(url, headers=headers)
        with _ur.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read().decode())
        rows = resp.get("records", [])
        if not rows:
            break
        all_rows.extend(rows)
        if len(rows) < take:
            break
        skip += take

    total, items = 0.0, []
    for rec in all_rows:
        f = rec.get("fields", {})
        d = (f.get("日期") or "")[:10]
        if not d or not (date_from <= d <= date_to):
            continue
        try:
            amt = float(str(f.get("金额") or "0").replace(",", "").replace("，", "").replace("元", "").strip())
        except ValueError:
            amt = 0.0
        event = (f.get("活动事件") or "").strip()
        total += amt
        items.append((d, event, amt))
    return total, items

def _query_sales_from_teable(period: str, date_from: str = "", date_to: str = "") -> str:
    import urllib.request as _urllib_req
    from datetime import date, timedelta
    today = date.today()
    if date_from and date_to:
        period_name = date_from if date_from == date_to else f"{date_from}~{date_to}"
    elif period == "today":
        date_from = date_to = str(today)
        period_name = "今日"
    elif period == "yesterday":
        yesterday = today - timedelta(days=1)
        date_from = date_to = str(yesterday)
        period_name = "昨日"
    elif period == "week":
        date_from = str(today - timedelta(days=today.weekday()))
        date_to   = str(today)
        period_name = "本周"
    else:  # month
        date_from = str(today.replace(day=1))
        date_to   = str(today)
        period_name = "本月"

    try:
        # 从 Teable 拉取指定日期范围的订单行
        all_rows = []
        online_fetch_ok = False
        skip, take = 0, 1000
        try:
            while True:
                url = (f"{_TEABLE_BASE}/api/table/{_TEABLE_ORDER_TABLE}/record"
                       f"?fieldKeyType=name&take={take}&skip={skip}")
                req = _urllib_req.Request(url, headers=_teable_headers())
                with _urllib_req.urlopen(req, timeout=15) as r:
                    resp = json.loads(r.read().decode())
                rows = resp.get("records", [])
                all_rows.extend(rows)
                if len(rows) < take:
                    break
                skip += take
            online_fetch_ok = True
        except Exception:
            online_fetch_ok = False

        # 在 Python 里按日期过滤统计
        total_amount = 0.0
        total_qty    = 0
        order_nos    = set()
        for rec in all_rows:
            f = rec.get("fields", {})
            d = (f.get("下单日期") or "")[:10]
            if not (date_from <= d <= date_to):
                continue
            status = f.get("订单状态", "")
            refund = f.get("退款状态", "") or ""
            if status not in {"配送中", "已确认", "已完成"}:
                continue
            if refund and refund != "未退款":
                continue
            total_amount += float(f.get("兑换价格元") or 0)
            total_qty    += int(f.get("数量") or 0)
            order_no = f.get("三方订单号", "")
            if order_no:
                order_nos.add(order_no)

        # 线下收款数据
        try:
            offline_total, offline_items = _query_offline_sales(date_from, date_to)
        except Exception:
            offline_total, offline_items = 0.0, []

        if not order_nos and not total_amount and not offline_items and online_fetch_ok:
            return f"{period_name}暂无销售数据，可能数据尚未生成，稍后再查看就好～"

        date_str = date_from if date_from == date_to else f"{date_from} 至 {date_to}"
        if online_fetch_ok:
            online_line = [
                f"🛒 线上商城",
                f"  销售额：¥{total_amount:.2f}",
                f"  订单量：{len(order_nos)} 单 / {total_qty} 件（仅统计配送中/已确认/已完成且未退款订单）",
            ]
        else:
            online_line = [f"🛒 线上商城：数据获取失败，请稍后重试"]
        lines = [f"📊 {period_name}销售（{date_str}）", f""] + online_line
        if offline_items:
            lines += [
                f"",
                f"💰 线下收款",
            ]
            for d, event, amt in offline_items:
                event_str = f"【{event}】 " if event else ""
                lines.append(f"  {d} {event_str}¥{amt:.2f}")
            lines.append(f"  小计：¥{offline_total:.2f}")
        elif offline_total == 0.0:
            lines += [f"", f"💰 线下收款：本期无记录"]

        combined = total_amount + offline_total
        lines += [f"", f"合计：¥{combined:.2f}"]
        return "\n".join(lines)
    except Exception as e:
        return f"查询销售数据失败：{e}"


def _query_product_ranking(date_from: str, date_to: str, top_n: int = 0, sort_by: str = "qty") -> str:
    """按商品名称汇总，返回排行（sort_by: qty=按数量, amount=按销售额；top_n=0 表示全量）"""
    import urllib.request as _ur
    from collections import defaultdict
    try:
        product_qty    = defaultdict(int)
        product_amount = defaultdict(float)
        product_orders = defaultdict(set)
        skip, take = 0, 1000
        while True:
            url = (f"{_TEABLE_BASE}/api/table/{_TEABLE_ORDER_TABLE}/record"
                   f"?fieldKeyType=name&take={take}&skip={skip}")
            req = _ur.Request(url, headers=_teable_headers())
            with _ur.urlopen(req, timeout=15) as r:
                resp = json.loads(r.read().decode())
            rows = resp.get("records", [])
            if not rows:
                break
            for rec in rows:
                f = rec.get("fields", {})
                d = (f.get("下单日期") or "")[:10]
                if not (date_from <= d <= date_to):
                    continue
                status = f.get("订单状态", "")
                refund = f.get("退款状态", "") or ""
                if status not in {"配送中", "已确认", "已完成"}:
                    continue
                if refund and refund != "未退款":
                    continue
                name     = (f.get("商品名称") or "").strip()
                qty      = int(f.get("数量") or 0)
                amount   = float(f.get("兑换价格元") or 0)
                order_no = (f.get("三方订单号") or "").strip()
                if name:
                    product_qty[name]    += qty
                    product_amount[name] += amount
                    if order_no:
                        product_orders[name].add(order_no)
            if len(rows) < take:
                break
            skip += take

        if not product_qty:
            return f"{date_from} ~ {date_to} 暂无销售数据"

        medals = ["🥇", "🥈", "🥉"]
        date_str = date_from if date_from == date_to else f"{date_from} 至 {date_to}"
        # top_n=0 → 全量；否则取前 N
        _slice = None if top_n <= 0 else top_n
        if sort_by == "amount":
            ranked = sorted(product_amount.keys(), key=lambda x: product_amount[x], reverse=True)
            if _slice: ranked = ranked[:_slice]
            label = f"销售额排行（{date_str}）共 {len(ranked)} 款"
            lines  = [f"【排行榜结果】{label}", label, ""]
            for i, name in enumerate(ranked, 1):
                icon = medals[i-1] if i <= 3 else f"{i}."
                lines.append(f"{icon} {name}  ¥{product_amount[name]:.2f}  {len(product_orders[name])} 单")
        else:
            ranked = sorted(product_qty.keys(), key=lambda x: product_qty[x], reverse=True)
            if _slice: ranked = ranked[:_slice]
            label = f"销量排行（{date_str}）共 {len(ranked)} 款"
            lines  = [f"【排行榜结果】{label}", label, ""]
            for i, name in enumerate(ranked, 1):
                icon = medals[i-1] if i <= 3 else f"{i}."
                order_cnt = len(product_orders[name])
                lines.append(f"{icon} {name}  {order_cnt} 单 / {product_qty[name]} 件")
        return "\n".join(lines)
    except Exception as e:
        return f"查询排行失败：{e}"


def _load_product_detail_map() -> dict:
    """九凤商品明细表 -> {商品名称: {cost, inventory, status, source, code}}"""
    import urllib.request as _ur
    result = {}
    skip, take = 0, 1000
    while True:
        url = (f"{_TEABLE_BASE}/api/table/{_TEABLE_PRODUCT_DETAIL_TABLE}/record"
               f"?fieldKeyType=name&take={take}&skip={skip}")
        req = _ur.Request(url, headers=_teable_headers())
        with _ur.urlopen(req, timeout=20) as r:
            resp = json.loads(r.read().decode())
        rows = resp.get("records", [])
        if not rows:
            break
        for rec in rows:
            f = rec.get("fields", {})
            name = (f.get("商品名称") or "").strip()
            if not name:
                continue
            try:
                cost = float(f.get("成本价") or 0)
            except (ValueError, TypeError):
                cost = 0.0
            try:
                inv = int(f.get("可售库存") or 0)
            except (ValueError, TypeError):
                inv = 0
            result[name] = {
                "cost":   cost,
                "inventory": inv,
                "status": (f.get("状态") or "").strip(),
                "source": (f.get("商品来源") or "").strip(),
                "code":   (f.get("三方商城编号") or "").strip(),
            }
        if len(rows) < take:
            break
        skip += take
    return result


def _query_product_analysis(date_from: str, date_to: str,
                             analysis_type: str = "comprehensive",
                             keyword: str = "", top_n: int = 20) -> str:
    """
    综合商品经营分析：整合内购订单明细（销售）+ 九凤商品明细（成本+库存）。
    analysis_type: turnover | slow_moving | cost | inventory | sales | comprehensive
    """
    import urllib.request as _ur
    from collections import defaultdict
    from datetime import date as _date

    try:
        d0 = _date.fromisoformat(date_from)
        d1 = _date.fromisoformat(date_to)
        period_days = max((d1 - d0).days + 1, 1)
        date_str = date_from if date_from == date_to else f"{date_from} 至 {date_to}"

        # 加载销售明细
        sales_qty    = defaultdict(int)
        sales_amount = defaultdict(float)
        sales_orders = defaultdict(set)
        skip, take = 0, 1000
        while True:
            url = (f"{_TEABLE_BASE}/api/table/{_TEABLE_ORDER_TABLE}/record"
                   f"?fieldKeyType=name&take={take}&skip={skip}")
            req = _ur.Request(url, headers=_teable_headers())
            with _ur.urlopen(req, timeout=15) as r:
                resp = json.loads(r.read().decode())
            recs = resp.get("records", [])
            if not recs:
                break
            for rec in recs:
                f = rec.get("fields", {})
                d = (f.get("下单日期") or "")[:10]
                if not (date_from <= d <= date_to):
                    continue
                st = f.get("订单状态", "")
                rf = f.get("退款状态", "") or ""
                if st not in {"配送中", "已确认", "已完成"}:
                    continue
                if rf and rf != "未退款":
                    continue
                name = (f.get("商品名称") or "").strip()
                qty  = int(f.get("数量") or 0)
                amt  = float(f.get("兑换价格元") or 0)
                ono  = (f.get("三方订单号") or "").strip()
                if name:
                    sales_qty[name]    += qty
                    sales_amount[name] += amt
                    if ono:
                        sales_orders[name].add(ono)
            if len(recs) < take:
                break
            skip += take

        # 加载商品明细（成本+库存）
        try:
            product_map = _load_product_detail_map()
        except Exception:
            product_map = {}

        # 合并全量商品集合
        all_names = set(sales_qty.keys()) | set(product_map.keys())
        kw = keyword.strip().lower()
        if kw:
            all_names = {n for n in all_names if kw in n.lower()}
        if not all_names:
            return f"未找到匹配「{keyword}」的商品数据"

        # 计算每款商品指标
        rows_data = []
        for name in all_names:
            pd    = product_map.get(name, {})
            cost  = pd.get("cost", 0.0)
            inv   = pd.get("inventory", 0)
            sq    = sales_qty.get(name, 0)
            sa    = sales_amount.get(name, 0.0)
            oc    = len(sales_orders.get(name, set()))

            daily  = sq / period_days
            dinv   = (inv / daily) if daily > 0 else float("inf")
            turnov = 365 / dinv if (0 < dinv < float("inf")) else 0.0
            cogs   = sq * cost
            inv_v  = inv * cost
            gp     = sa - cogs
            gm     = gp / sa if sa > 0 else 0.0

            rows_data.append({
                "name": name,
                "status":  pd.get("status", "未知"),
                "source":  pd.get("source", ""),
                "cost": cost, "inv": inv, "inv_v": inv_v,
                "sq": sq, "sa": sa, "oc": oc,
                "daily": daily, "dinv": dinv, "turnov": turnov,
                "cogs": cogs, "gp": gp, "gm": gm,
            })

        # top_n=0 表示全量；正数表示每节最多取 top_n 条
        N = top_n if top_n > 0 else 999999
        lines = []

        def _sta_icon(sta: str) -> str:
            return "🔴" if "下架" in sta else ("⬜" if "未上架" in sta or "待上架" in sta else "✅")

        if analysis_type == "turnover":
            fil_with = sorted(
                [r for r in rows_data if r["inv"] > 0 and r["sq"] > 0],
                key=lambda x: x["dinv"]
            )
            fil_no   = sorted(
                [r for r in rows_data if r["inv"] > 0 and r["sq"] == 0],
                key=lambda x: x["inv_v"], reverse=True
            )
            if not fil_with and not fil_no:
                return f"当前无在库商品数据（{date_str}）"
            total_iv = sum(r["inv_v"] for r in rows_data)
            total_inv_cnt = sum(r["inv"] for r in rows_data if r["inv"] > 0)
            # 智能提示：快速周转但库存紧张的商品（需补货）
            urgent = [r for r in fil_with if r["inv"] <= 5 and r["dinv"] < 14]
            avg_di = sum(r["dinv"] for r in fil_with) / len(fil_with) if fil_with else 0
            lines += [
                f"📦 {date_str} 周转分析",
                f"在库 {len(fil_with)+len(fil_no)} 款 · {total_inv_cnt} 件 · 库存价值 ¥{total_iv:,.0f}",
                f"有销售 {len(fil_with)} 款（平均周转 {avg_di:.0f} 天），{len(fil_no)} 款期间零成交",
                "",
            ]
            if fil_with:
                lines.append(f"🚀 有销售·按周转天升序（共 {len(fil_with)} 款）")
                for i, r in enumerate(fil_with[:N], 1):
                    di = f"{r['dinv']:.0f}天" if r["dinv"] < 999 else ">999天"
                    lines.append(
                        f"{i}. {r['name'][:26]}"
                        f"  库存{r['inv']}件 · 周转{di} · 日销{r['daily']:.1f}件"
                    )
            if fil_no:
                lines.append(f"\n⚠️ 零销售有库存（{period_days} 天内无成交，共 {len(fil_no)} 款）")
                for i, r in enumerate(fil_no[:N], 1):
                    iv = f"¥{r['inv_v']:,.0f}" if r["inv_v"] > 0 else "无成本数"
                    lines.append(f"{i}. {r['name'][:26]}  库存{r['inv']}件 · {iv}")
            if urgent:
                lines.append(f"\n🔔 需关注补货（周转<14天且库存≤5件，共 {len(urgent)} 款）：")
                for r in urgent[:8]:
                    lines.append(f"  · {r['name'][:24]}  剩{r['inv']}件 · 周转{r['dinv']:.0f}天 · 日销{r['daily']:.1f}件")

        elif analysis_type == "slow_moving":
            slow = sorted(
                [r for r in rows_data if r["inv"] > 0 and (r["sq"] == 0 or r["dinv"] > 90)],
                key=lambda x: x["inv_v"], reverse=True
            )
            zero_s  = [r for r in slow if r["sq"] == 0]
            low_t   = [r for r in slow if r["sq"] > 0]
            stuck_v = sum(r["inv_v"] for r in slow)
            total_iv_all = sum(r["inv_v"] for r in rows_data if r["inv"] > 0)
            stuck_pct = stuck_v / total_iv_all if total_iv_all > 0 else 0
            # 已下架但仍有库存的商品数
            listed_zero = sum(1 for r in zero_s if "下架" not in r.get("status",""))
            lines += [
                f"⚠️ {date_str} 滞销分析",
                f"共 {len(slow)} 款需关注（零销售 {len(zero_s)} 款 + 低周转 {len(low_t)} 款）",
                f"滞销库存压了 ¥{stuck_v:,.0f}，占总库存价值的 {stuck_pct:.0%}",
                "",
            ]
            if zero_s:
                lines.append(f"【{period_days} 天内零销售（有库存）共 {len(zero_s)} 款  按库存值降序】")
                for i, r in enumerate(zero_s[:N], 1):
                    iv = f"¥{r['inv_v']:,.0f}" if r["inv_v"] > 0 else "无成本数"
                    icon = _sta_icon(r.get("status",""))
                    lines.append(f"{i}. {r['name'][:26]}  {r['inv']}件 {iv} {icon}")
            if low_t:
                lines.append(f"\n【周转>90天（低周转）共 {len(low_t)} 款  按库存值降序】")
                for i, r in enumerate(low_t[:N], 1):
                    di = f"{r['dinv']:.0f}" if r["dinv"] < 9999 else ">999"
                    iv = f"¥{r['inv_v']:,.0f}" if r["inv_v"] > 0 else "无成本数"
                    lines.append(
                        f"{i}. {r['name'][:26]}"
                        f"  {r['inv']}件 · 周转{di}天 · {iv}"
                    )
            # 智能建议
            already_off = sum(1 for r in zero_s if "下架" in r.get("status",""))
            tip_parts = []
            if already_off > 0:
                tip_parts.append(f"其中 {already_off} 款零销售品已下架，建议加速清仓")
            if listed_zero > 0:
                tip_parts.append(f"{listed_zero} 款在架但零销售，可评估是否下架促销")
            if low_t:
                worst = low_t[0]
                worst_iv = f"¥{worst['inv_v']:,.0f}" if worst['inv_v'] > 0 else "无成本数"
                tip_parts.append(f"库存压得最重的是「{worst['name'][:16]}」（{worst['inv']}件 {worst_iv}）")
            if tip_parts:
                lines.append("\n💡 " + "；".join(tip_parts))

        elif analysis_type == "cost":
            ws = sorted(
                [r for r in rows_data if r["sq"] > 0],
                key=lambda x: x["gp"], reverse=True
            )
            if not ws:
                return f"{date_str} 无销售记录，无法进行成本分析"
            total_sa   = sum(r["sa"]   for r in ws)
            total_cogs = sum(r["cogs"] for r in ws)
            total_gp   = total_sa - total_cogs
            total_gm   = total_gp / total_sa if total_sa > 0 else 0
            no_cost    = sum(1 for r in ws if r["cost"] == 0)
            best_gm    = max((r for r in ws if r["cost"] > 0), key=lambda x: x["gm"], default=None)
            lines += [
                f"💰 {date_str} 成本毛利分析",
                f"销售额 ¥{total_sa:,.2f} · 成本 ¥{total_cogs:,.2f} · 毛利润 ¥{total_gp:,.2f}",
                f"综合毛利率 {total_gm:.1%}" + (f"（注：{no_cost} 款无成本数据，实际毛利率可能偏高）" if no_cost > 0 else ""),
                "",
                f"按毛利润降序（共 {len(ws)} 款有销售）",
            ]
            for i, r in enumerate(ws[:N], 1):
                gm_s = f"{r['gm']:.1%}" if (r["sa"] > 0 and r["cost"] > 0) else "无成本数"
                lines.append(
                    f"{i}. {r['name'][:24]}"
                    f"  ¥{r['sa']:,.0f} · 毛利¥{r['gp']:,.0f} · {gm_s}"
                )
            if best_gm:
                lines.append(f"\n💡 毛利率最高的是「{best_gm['name'][:18]}」（{best_gm['gm']:.1%}），可考虑重点推广")

        elif analysis_type == "inventory":
            wi = sorted(
                [r for r in rows_data if r["inv"] > 0],
                key=lambda x: x["inv_v"], reverse=True
            )
            if not wi:
                return "当前无在库商品"
            total_inv = sum(r["inv"]   for r in wi)
            total_iv  = sum(r["inv_v"] for r in wi)
            active    = sum(1 for r in wi if r["sq"] > 0)
            stuck_iv  = sum(r["inv_v"] for r in wi if r["sq"] == 0)
            stuck_pct = stuck_iv / total_iv if total_iv > 0 else 0
            lines += [
                f"📦 {date_str} 库存分析",
                f"在库 {len(wi)} 款 · 共 {total_inv} 件 · 价值 ¥{total_iv:,.2f}",
                f"活跃 {active} 款有销售；零销售 {len(wi)-active} 款压了 ¥{stuck_iv:,.0f}（占 {stuck_pct:.0%}）",
                "",
                f"按库存价值降序（共 {len(wi)} 款）",
            ]
            for i, r in enumerate(wi[:N], 1):
                ivs  = f"¥{r['inv_v']:,.0f}" if r["inv_v"] > 0 else "—"
                di_s = f"周转{r['dinv']:.0f}天" if (0 < r["dinv"] < 999) else ("无销售" if r["sq"] == 0 else "库存已清")
                lines.append(
                    f"{i}. {r['name'][:24]}"
                    f"  {r['inv']}件 · {ivs} · {di_s}"
                )

        elif analysis_type == "sales":
            ws = sorted(
                [r for r in rows_data if r["sq"] > 0],
                key=lambda x: x["sa"], reverse=True
            )
            if not ws:
                return f"{date_str} 无销售记录"
            total_sa  = sum(r["sa"] for r in ws)
            total_qty = sum(r["sq"] for r in ws)
            total_oc  = sum(r["oc"] for r in ws)
            daily_sa  = total_sa / period_days if period_days > 0 else 0
            # 找帕累托点（前N款占80%销售额）
            cum = 0.0
            pareto_n = len(ws)
            for idx, r in enumerate(ws, 1):
                cum += r["sa"]
                if cum / total_sa >= 0.8:
                    pareto_n = idx
                    break
            lines += [
                f"📊 {date_str} 销售分析（共 {period_days} 天）",
                f"销售 {len(ws)} 款 · 总销量 {total_qty} 件 · 总订单 {total_oc} 单 · 销售额 ¥{total_sa:,.2f}",
                f"日均销售额 ¥{daily_sa:,.0f}，最畅销的是「{ws[0]['name'][:16]}」",
                "",
                f"按销售额排行（共 {len(ws)} 款）",
            ]
            for i, r in enumerate(ws[:N], 1):
                share = r["sa"] / total_sa if total_sa > 0 else 0
                lines.append(
                    f"{i}. {r['name'][:24]}"
                    f"  ¥{r['sa']:,.0f} · {r['sq']}件 · 日均{r['daily']:.1f}件 · {share:.1%}"
                )
            lines.append(f"\n💡 前 {pareto_n} 款贡献了 80% 的销售额，其余 {len(ws)-pareto_n} 款合计占 20%")

        else:  # comprehensive
            with_s = [r for r in rows_data if r["sq"] > 0]
            with_i = [r for r in rows_data if r["inv"] > 0]
            slow   = [r for r in rows_data if r["inv"] > 0 and (r["sq"] == 0 or r["dinv"] > 90)]
            ts     = sum(r["sa"]    for r in with_s)
            tq     = sum(r["sq"]    for r in with_s)
            to_    = sum(r["oc"]    for r in with_s)
            tc     = sum(r["cogs"]  for r in with_s)
            tgp    = ts - tc
            tgm    = tgp / ts if ts > 0 else 0
            ti     = sum(r["inv"]   for r in with_i)
            tiv    = sum(r["inv_v"] for r in with_i)
            stiv   = sum(r["inv_v"] for r in slow)
            stuck_pct = stiv / tiv if tiv > 0 else 0
            daily_sa  = ts / period_days if period_days > 0 else 0

            fast5  = sorted([r for r in with_i if 0 < r["dinv"] < float("inf")], key=lambda x: x["dinv"])[:5]
            top5s  = sorted(with_s, key=lambda x: x["sa"], reverse=True)[:5]
            slow5  = sorted(slow, key=lambda x: x["inv_v"], reverse=True)[:5]
            urgent = [r for r in with_i if r["inv"] <= 5 and 0 < r["dinv"] < 14]

            lines += [
                f"📋 {date_str} 综合经营分析（统计 {period_days} 天）",
                "",
                "【销售】",
                f"  {len(with_s)} 款在卖 · 销量 {tq} 件 · 订单 {to_} 单 · 销售额 ¥{ts:,.2f}（日均 ¥{daily_sa:,.0f}）",
                f"  毛利润 ¥{tgp:,.2f} · 毛利率 {tgm:.1%}",
                "",
                "【库存】",
                f"  在库 {len(with_i)} 款 · {ti} 件 · 价值 ¥{tiv:,.2f}",
                f"  滞销 {len(slow)} 款，压了 ¥{stiv:,.0f}（占库存价值 {stuck_pct:.0%}）",
                "",
            ]
            if fast5:
                lines.append("🚀 周转最快 Top5")
                for r in fast5:
                    lines.append(f"  · {r['name'][:24]}  周转{r['dinv']:.0f}天 · 库存{r['inv']}件 · 日销{r['daily']:.1f}件")
                lines.append("")
            if top5s:
                lines.append("🏆 销售额 Top5")
                for r in top5s:
                    lines.append(f"  · {r['name'][:24]}  ¥{r['sa']:,.0f} · 销量{r['sq']}件")
                lines.append("")
            if slow5:
                lines.append("⚠️ 滞销压库 Top5（库存价值最高）")
                for r in slow5:
                    di = f"{r['dinv']:.0f}天" if (0 < r["dinv"] < 9999) else "无销售"
                    iv = f"¥{r['inv_v']:,.0f}" if r["inv_v"] > 0 else "无成本数"
                    lines.append(f"  · {r['name'][:24]}  库存{r['inv']}件（{iv}）· 周转{di}")
                lines.append("")
            if urgent:
                lines.append(f"🔔 需补货（周转<14天且库存≤5件，共 {len(urgent)} 款）")
                for r in urgent[:5]:
                    lines.append(f"  · {r['name'][:24]}  剩{r['inv']}件 · 周转{r['dinv']:.0f}天")

        return "\n".join(lines)

    except Exception as e:
        return f"分析失败：{e}"


# ─── 统一查询执行 ─────────────────────────────────────────────────

_SELF_INTRO_REPLY = (
    "您好！我是好未来内购商城智能客服助手，可以帮您：\n\n"
    "🛍 **商品查询**\n"
    "· 搜索商品信息（价格、库存、规格等）\n\n"
    "📖 **产品使用说明 & 资料**\n"
    "· 收录 100+ 款内购产品的使用说明、激活步骤、适用年龄、课程内容、常见问题\n"
    "· 覆盖点读笔（激活/兼容书目）、摩比系列、RAZ/ABCtime/Reading A-Z、哈佛外教、迪士尼英语等主力品\n"
    "· 直接问「XXX 怎么激活」「XXX 适合几岁」「XXX 包含什么内容」「XXX 使用说明」即可\n\n"
    "📋 **订单查询**\n"
    "· 查询内购订单状态（自动识别工号，也可提供订单号直查）\n\n"
    "🚚 **物流查询**\n"
    "· 查询快递物流状态\n\n"
    "🔧 **售后服务**\n"
    "· 售后问题引导、退换货申请\n\n"
    "💡 **商品建议**\n"
    "· 补货申请、希望上架的商品收集\n\n"
    "📊 **经营数据分析**（需智能客服系统权限）\n"
    "· 销售额/销量查询与趋势分析\n"
    "· 商品周转率/周转天数分析\n"
    "· 滞销商品识别与库存预警\n"
    "· 成本/毛利润/毛利率分析\n"
    "· 库存价值/库存情况分析\n"
    "· 综合经营概览看板\n\n"
    "📷 **图片识别**\n"
    "· 发一张商品图片，我来帮您识别并查询内购价格/库存\n\n"
    "🎨 **AI 生图**\n"
    "· 根据文字描述生成图片，说「帮我画…」即可\n\n"
    "🎬 **AI 视频**\n"
    "· 文生视频 / 图生视频，说「帮我做个视频…」即可\n\n"
    "🏪 内购商城入口：https://t.tal.com/e3KJoD\n"
    "👆 用手机知音楼扫码进入内购商城 📱\n"
    "![内购商城二维码](https://yach-static.zhiyinlou.com/online/person/1779503218959/79343BF9AFA2A679883BA3482474BE93/86852FE6-309F-429E-B758-3C7FCC0D2CC3.PNG)\n\n"
    "有什么可以帮您的吗？"
)


def _execute_query(intent: str, entities: dict, query: str, user_id: str = "") -> str:
    """根据意图和实体执行对应系统查询，返回格式化文本（供 LLM 参考）。"""
    py = sys.executable

    if intent == "self_intro":
        return _SELF_INTRO_REPLY

    if intent == "product_query":
        kw = entities.get("keyword", "").strip()
        if not kw:
            # entities 没提取到，用正则兜底清洗原始 query
            import re
            kw = re.sub(r'^(查询?|搜索|找|看看|有没有|查一下|帮我查|帮我看下?|看下)\s*', '', query).strip()
            kw = re.sub(r'(的价格|价格是多少|多少钱|怎么样|好不好|几款|是多少|有货吗|有没有货|有没有|有吗|价格|啥价|多少|有哪款|有哪些|都有哪些|都有哪款|哪款|哪些|有哪几|什么款|什么类型|啥款|啥类型)[？?。，,。]*$', '', kw).strip()
        if not kw:
            return ""
        try:
            r = subprocess.run([py, S["cs_product"], "--keyword", kw],
                               capture_output=True, text=True,
                               encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS, timeout=20)
            return r.stdout.strip() if r.returncode == 0 else ""
        except Exception:
            return ""

    if intent == "order_query":
        ent_user_id = entities.get("user_id", "")
        order_id    = entities.get("order_id", "")
        self_query  = entities.get("self_query", False)
        # "我的订单/查一下我的订单" → 自动用发送者工号
        if not ent_user_id and not order_id and (self_query or re.search(r'我的|帮我查|查我', query)):
            ent_user_id = user_id
        # UUID 未绑定时从 query 提取工号兜底
        if not ent_user_id and not order_id and not user_id:
            _m = re.search(r'\b((?=[A-Za-z0-9]*\d)[A-Za-z0-9]{4,12})\b', query)
            if _m:
                ent_user_id = _m.group(1)
        try:
            r = subprocess.run([py, S["cs_order"],
                                "--user_id",  ent_user_id,
                                "--order_id", order_id],
                               capture_output=True, text=True,
                               encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS, timeout=20)
            return r.stdout.strip() if r.returncode == 0 else ""
        except Exception:
            return ""

    if intent == "logistics_query":
        express_no     = entities.get("express_no", "")
        order_id       = entities.get("order_id", "")
        wants_tracking = entities.get("wants_tracking", False)
        self_query     = entities.get("self_query", False)
        # 用户想查「快递单号是多少」→ 数字应作为订单号，让脚本去找运单号
        if wants_tracking and not express_no and not order_id:
            import re as _re2
            m2 = _re2.search(r'\b(\d{8,})\b', query)
            if m2:
                order_id = m2.group(1)
        # "查我的快递/我的物流" 且没有单号 → 用发送者工号自动查最近订单的快递单号
        if not express_no and not order_id and user_id and (self_query or re.search(r'我的|帮我查|查我', query)):
            try:
                r0 = subprocess.run([py, S["cs_order"],
                                     "--user_id", user_id, "--order_id", "", "--json_output"],
                                    capture_output=True, text=True,
                                    encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS, timeout=20)
                if r0.returncode == 0 and r0.stdout.strip():
                    orders = json.loads(r0.stdout)
                    # 优先取有快递单号的订单，否则取第一个订单号
                    for o in orders:
                        if o.get("express_no"):
                            express_no = o["express_no"]
                            order_id   = o.get("order_id", "")
                            break
                    if not express_no and orders:
                        order_id = orders[0].get("order_id", "")
            except Exception:
                pass
        try:
            r = subprocess.run([py, S["cs_logistics"],
                                "--express_no", express_no,
                                "--order_id",   order_id],
                               capture_output=True, text=True,
                               encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS, timeout=20)
            return r.stdout.strip() if r.returncode == 0 else ""
        except Exception:
            return ""

    if intent == "sales_query":
        if user_id not in _SALES_ALLOWED:
            return "抱歉，销售额和订单量数据仅限内购管理员查看，无法为您提供。如需帮助请联系丁洋老师（工号：215734）。"
        specific_date = (entities.get("specific_date") or "").strip()
        if specific_date:
            return _query_sales_from_teable("specific", date_from=specific_date, date_to=specific_date)
        period = entities.get("period", "today") or "today"
        if period not in ("today", "yesterday", "week", "month"):
            period = "today"
        return _query_sales_from_teable(period)

    if intent == "sales_refresh":
        # Teable 自动化 webhook 触发：后台刷新全量订单数据
        tid = uuid.uuid4().hex[:8]
        with _lock:
            _tasks[tid] = {"task": "sales_refresh", "status": "running",
                           "created_at": datetime.now().isoformat(), "logs": []}
        def _do_refresh():
            try:
                subprocess.run([py, S["sales_refresh"]], timeout=600,
                               capture_output=True, creationflags=_POPEN_FLAGS)
                with _lock:
                    _tasks[tid]["status"] = "done"
            except Exception as e:
                with _lock:
                    _tasks[tid]["status"] = f"failed:{e}"
        threading.Thread(target=_do_refresh, daemon=True).start()
        return f"订单数据刷新已启动（task_id={tid}），通常需要 3-5 分钟完成。"

    if intent == "ls_query":
        if user_id not in _SALES_ALLOWED:
            return "抱歉，库存数据仅限内购管理员查看，无法为您提供。如需帮助请联系丁洋老师（工号：215734）。"
        return ""

    if intent == "aftersale":
        return _STATIC_REPLY["aftersale"]

    if intent == "suggestion":
        return _STATIC_REPLY["suggestion"]

    if intent == "courier_query":
        return _STATIC_REPLY["courier_query"]

    # 其他任务 → 启动异步任务，返回空让 LLM 给引导文案
    if intent in _TASK_MAP:
        tid = uuid.uuid4().hex[:8]
        with _lock:
            _tasks[tid] = {"task": _TASK_MAP[intent], "status": "pending",
                           "created_at": datetime.now().isoformat(), "logs": [], "query": query}
        threading.Thread(target=run_cs_task,
                         args=(tid, _TASK_MAP[intent], query, ""), daemon=True).start()
        return ""

    if intent == "board_generate":
        tid = uuid.uuid4().hex[:8]
        with _lock:
            _tasks[tid] = {"task": "board_generate", "status": "pending",
                           "created_at": datetime.now().isoformat(), "logs": []}
        threading.Thread(target=run_board_pipeline, args=(tid,), daemon=True).start()
        return ""

    # unknown → 尝试商品搜索（用正则提取的关键词），搜不到再返回空让 LLM 自由对话
    _greetings = {"你好","好的","谢谢","感谢","再见","不用了","ok","好",
                  "嗯","哦","是的","是","知道了","明白","没问题","hello","hi"}
    if query.lower().strip() not in _greetings:
        kw = entities.get("keyword", "").strip() or query
        try:
            r = subprocess.run([py, S["cs_product"], "--keyword", kw],
                               capture_output=True, text=True,
                               encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS, timeout=15)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.strip()
        except Exception:
            pass
    return ""


# ─── Agent 模式：GLM tool_use 智能对话 ───────────────────────────

_AGENT_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_products",
            "description": "搜索内购商城商品，获取商品名称、内购价格、市场价、可售库存",
            "parameters": {
                "type": "object",
                "properties": {
                    "keyword": {"type": "string", "description": "商品搜索关键词，如'点读笔'、'运动鞋'、'香皂'"}
                },
                "required": ["keyword"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "query_sales",
            "description": "查询内购商城销售统计（销售额、订单量），必须传入具体日期",
            "parameters": {
                "type": "object",
                "properties": {
                    "date_from": {"type": "string", "description": "查询开始日期，格式 YYYY-MM-DD"},
                    "date_to":   {"type": "string", "description": "查询结束日期，格式 YYYY-MM-DD"}
                },
                "required": ["date_from", "date_to"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "query_order",
            "description": "查询员工的内购订单状态。每次用户问订单必须调用此工具获取实时数据，不允许凭记忆或历史对话回答。查本人订单时 user_id 留空，server 自动补全。查他人订单时：直接传工号或姓名均可，server 自动将姓名解析为工号。",
            "parameters": {
                "type": "object",
                "properties": {
                    "user_id":  {"type": "string", "description": "查本人订单时留空；查他人订单时传工号或姓名均可，如「王雪」或「333437」，server 自动识别"},
                    "order_id": {"type": "string", "description": "订单号（用户主动提供时填写，否则留空）"}
                }
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "query_logistics",
            "description": "查询快递物流状态",
            "parameters": {
                "type": "object",
                "properties": {
                    "express_no": {"type": "string", "description": "快递单号，必须有字母前缀（如 SF1234567890、JT0023119290362）；纯数字串不是快递单号。多个快递单号用英文逗号分隔"},
                    "order_id":   {"type": "string", "description": "九凤订单号（纯数字，通常12位以上）；用户提供纯数字串时填此字段，不要填 express_no。多个订单号用英文逗号分隔"}
                }
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "query_product_ranking",
            "description": "查询指定日期范围内按货品维度的排行榜，支持销量排行（按数量）和销售额排行（按兑换价格元汇总）",
            "parameters": {
                "type": "object",
                "properties": {
                    "date_from": {"type": "string", "description": "查询开始日期，格式 YYYY-MM-DD"},
                    "date_to":   {"type": "string", "description": "查询结束日期，格式 YYYY-MM-DD"},
                    "top_n":     {"type": "integer", "description": "返回前N名，默认10"},
                    "sort_by":   {"type": "string", "description": "排序维度：qty=按销量数量排行，amount=按销售额排行，默认qty"}
                },
                "required": ["date_from", "date_to"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "query_product_analysis",
            "description": (
                "综合商品经营分析——整合内购订单明细（销售数据）和九凤商品明细（成本+库存），"
                "计算周转率、周转天数、滞销商品、毛利润、库存价值等指标。"
                "用户问以下任意内容时调用：周转率/周转天数/滞销/滞销分析/库存分析/成本分析/"
                "毛利率/毛利润/库存价值/库存情况/销售情况/综合分析/经营分析。"
                "权限与 query_sales 相同，无权限用户不得调用。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "date_from":     {"type": "string", "description": "统计开始日期，格式 YYYY-MM-DD"},
                    "date_to":       {"type": "string", "description": "统计结束日期，格式 YYYY-MM-DD"},
                    "analysis_type": {
                        "type": "string",
                        "description": (
                            "分析维度：\n"
                            "  turnover    = 周转率/周转天数分析\n"
                            "  slow_moving = 滞销商品分析（库存>0且周转天>90）\n"
                            "  cost        = 成本/毛利润分析\n"
                            "  inventory   = 库存情况分析\n"
                            "  sales       = 销售情况分析\n"
                            "  comprehensive = 综合分析（默认，包含以上所有概要）"
                        )
                    },
                    "keyword":   {"type": "string", "description": "按商品名称过滤，留空则分析全部商品"},
                    "top_n":     {"type": "integer", "description": "每维度展示前N款，默认20"}
                },
                "required": ["date_from", "date_to"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "generate_image",
            "description": "根据文字描述生成新图片。调用前必须先判断用户意图：用户是否在明确请求「现在帮我创作一张新图片」？只有意图明确为「创作新图」才调用。意图判断方法：用户的话能否替换成「请帮我画一张[具体内容]」？能 → 调用；不能 → 不调用，正常回复。常见不调用场景：夸奖已有图片（「画得太好了」「好看」「漂亮」「厉害」）、确认收到（「好的」「嗯」「收到」）、表达满意或反馈感受——这些都是情绪/态度表达，不是创作请求。对图片质量有不满（「太暗」「不够好看」「换个风格」）时，先问「要重新画一张吗？」再等确认，不要自动重画。",
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string", "description": "图片描述提示词，尽量详细，中文英文均可"}
                },
                "required": ["prompt"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "generate_video",
            "description": (
                "调用 happyhorse 模型生成 AI 视频。调用前必须先判断用户意图：用户是否在明确请求「现在帮我创作一段新视频」？"
                "意图测试：用户的话能否自然替换成「请帮我做一段[具体内容]的视频」？能 → 调用；不能 → 不调用，正常回复。"
                "夸奖已有视频（「视频拍得真好」「效果不错」「好看」「厉害」）= 情绪表达，不是创作请求，直接回应即可，绝不调用。"
                "对视频质量有意见（「太短了」「画质不好」「换个风格」）= 先问「要重新生成一段吗？」等确认，不要自动重做。"
                "支持两种模式：text=文生视频（只有文字描述，可指定分辨率/比例/时长）；image=图生视频（提供首帧图片URL，宽高比自动跟随图片，不支持ratio）。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {
                        "type": "string",
                        "description": "视频内容描述，中文英文均可，尽量详细"
                    },
                    "mode": {
                        "type": "string",
                        "description": "生成模式：text（默认，纯文字生成）/ image（首帧图片驱动生成）"
                    },
                    "resolution": {
                        "type": "string",
                        "description": "分辨率，仅文生视频有效：720P（默认）/ 1080P"
                    },
                    "ratio": {
                        "type": "string",
                        "description": "宽高比，仅文生视频有效：16:9（默认）/ 9:16 / 1:1"
                    },
                    "duration": {
                        "type": "integer",
                        "description": "视频时长（秒），仅文生视频有效，默认 5"
                    },
                    "img_url": {
                        "type": "string",
                        "description": "图生视频（mode=image）时的首帧图片 URL"
                    }
                },
                "required": ["prompt"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "request_delegate_confirm",
            "description": (
                "向丁洋老师（工号215734）发送委派确认请求。"
                "当用户要求执行内购补货/内购上新/商品上架/内购选品/WMS审核等自动化任务时调用。"
                "智能客服自身不直接执行这些任务，必须先通过此工具请求丁洋老师确认。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "bot": {
                        "type": "string",
                        "description": (
                            "目标数字伙伴标识: "
                            "replenishment=内购补货助手, "
                            "new_product=内购上新助手, "
                            "upload=九凤上架助手, "
                            "selection=内购选品助手, "
                            "selection_upload=内购选品助手（导入待上架明细）, "
                            "wms_audit=WMS出入库审核助手"
                        )
                    },
                    "requester_note": {
                        "type": "string",
                        "description": "用户原始请求摘要，发给丁洋老师看（如：工号091234 请求跑补货）"
                    },
                    "sheet_url": {
                        "type": "string",
                        "description": "【selection_upload专用】待上架明细表格的知音楼在线表格 URL（yach-doc-shimo.zhiyinlou.com 开头）"
                    },
                    "qc_no": {
                        "type": "string",
                        "description": "【wms_audit专用】出库单号，QC开头"
                    },
                    "qr_no": {
                        "type": "string",
                        "description": "【wms_audit专用】入库单号，QR开头"
                    },
                    "warehouse": {
                        "type": "string",
                        "description": "【wms_audit专用】仓库名称，如武清仓/黄陂仓，默认武清仓"
                    }
                },
                "required": ["bot"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "execute_pending_delegate",
            "description": (
                "执行待确认的委派任务。仅当用户在委派确认权限组（_DELEGATE_ALLOWED）内且说对应确认词时调用。"
                "无委派权限的用户说确认均不得调用。"
            ),
            "parameters": {
                "type": "object",
                "properties": {},
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "cancel_pending_delegate",
            "description": "取消待确认的委派任务。当委派权限用户说「取消」或任何用户说「取消委派」时调用。",
            "parameters": {
                "type": "object",
                "properties": {},
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "notify_admin",
            "description": (
                "通知内购管理员丁洋老师（215734）跟进某个问题。"
                "在群聊中遇到以下情况必须调用：商品缺货/没有上架/补货需求/无法确认补货时间/快递投诉/售后无法自动处理/其他需要人工介入的问题。"
                "调用此工具会向丁洋老师发送 P2P 私信说明情况，确保问题有人跟进。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "reason": {
                        "type": "string",
                        "description": "需要跟进的问题描述，包含用户问了什么、当前情况是什么（如：用户询问摩比分级阅读补货时间，商城目前仅有微瑕版，无正品库存）"
                    },
                    "asker": {
                        "type": "string",
                        "description": "提问用户的工号或称呼，没有工号时填空字符串"
                    }
                },
                "required": ["reason"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "manage_permission",
            "description": (
                "权限管理工具。"
                "action=list：查看所有员工当前权限；"
                "action=grant：给员工新增指定权限（不影响已有权限，需 target 工号 + types）；"
                "action=remove：移除员工的指定权限类型（部分移除，保留其余权限，需 target 工号 + types）；"
                "action=revoke：取消员工全部权限（需 target 工号）。"
                "list 任何人可用；其余操作仅超级管理员（215734）可执行。"
                "只有姓名没工号时先询问工号，拿到后再调用。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["list", "grant", "remove", "revoke"],
                        "description": "list=查看权限，grant=新增权限，remove=移除指定权限，revoke=取消全部权限"
                    },
                    "target": {
                        "type": "string",
                        "description": "目标员工工号（grant/remove/revoke 时必填）"
                    },
                    "types": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "权限类型列表，可填：数据、订单、委派、全部。grant/remove 时使用"
                    }
                },
                "required": ["action"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "query_job_status",
            "description": (
                "查询后台异步任务（AI生图/视频生成）的进度状态。"
                "当用户问「图/视频好了吗」「进度怎么样」「生成完了吗」「还在跑吗」「出来了吗」等时调用。"
            ),
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
]


_ADMIN_PERMS_FILE = r"D:\windows powershells\ips_cache\admin_permissions.json"
_SUPERADMIN = "215734"          # 超级管理员，不可移除
_SALES_ALLOWED:       set = {"215734"}   # 查看销售额/订单量/库存/排行
_DELEGATE_ALLOWED:    set = {"215734"}   # 委派确认/取消权限
_ORDER_QUERY_ALLOWED: set = {"215734"}   # 跨工号订单查询权限
_STAFF_NAMES:         dict = {"215734": "超级管理员"}   # 工号 → 姓名备注

def _load_admin_perms():
    global _SALES_ALLOWED, _DELEGATE_ALLOWED, _ORDER_QUERY_ALLOWED, _STAFF_NAMES
    try:
        if os.path.exists(_ADMIN_PERMS_FILE):
            with open(_ADMIN_PERMS_FILE, encoding="utf-8") as _f:
                _p = json.load(_f)
            _SALES_ALLOWED       = set(_p.get("data_allowed",     [_SUPERADMIN]))
            _DELEGATE_ALLOWED    = set(_p.get("delegate_allowed", [_SUPERADMIN]))
            _ORDER_QUERY_ALLOWED = set(_p.get("order_allowed",    [_SUPERADMIN]))
            _STAFF_NAMES         = _p.get("staff_names", {})
    except Exception:
        pass
    _SALES_ALLOWED.add(_SUPERADMIN)
    _DELEGATE_ALLOWED.add(_SUPERADMIN)
    _ORDER_QUERY_ALLOWED.add(_SUPERADMIN)
    _STAFF_NAMES.setdefault(_SUPERADMIN, "超级管理员")

def _save_admin_perms():
    try:
        with open(_ADMIN_PERMS_FILE, "w", encoding="utf-8") as _f:
            json.dump({
                "data_allowed":     sorted(_SALES_ALLOWED),
                "delegate_allowed": sorted(_DELEGATE_ALLOWED),
                "order_allowed":    sorted(_ORDER_QUERY_ALLOWED),
                "staff_names":      _STAFF_NAMES,
            }, _f, ensure_ascii=False, indent=2)
    except Exception:
        pass

_load_admin_perms()

# Dify/知音楼 UUID → 工号 映射（Dify 传来的 sys.user_id 是 UUID 而非工号）
_UUID_MAP_FILE        = r"D:\windows powershells\ips_cache\uuid_staff_map.json"
_YACH_NAME_CACHE_FILE = r"D:\windows powershells\ips_cache\yach_name_cache.json"
_uuid_staff_map:    dict = {}

# Teable 权限管理表
_TEABLE_PERM_TABLE  = "tblvmF035LLP9Ra2LvG"
_TEABLE_PERM_URL    = f"https://yach-teable.zhiyinlou.com/api/table/{_TEABLE_PERM_TABLE}/record"
_TEABLE_PERM_TOKEN  = "Bearer teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw="
# 字段名（直接用中文名，Teable API 默认按 name 索引）
_TF = {
    "工号":     "工号",
    "备注":     "姓名备注",
    "数据权限": "数据查询权限",
    "委派权限": "委派确认权限",
    "订单权限": "订单查询权限",
    "更新时间": "最后更新",
}

def _load_uuid_map():
    global _uuid_staff_map
    try:
        if os.path.exists(_UUID_MAP_FILE):
            with open(_UUID_MAP_FILE, encoding="utf-8") as f:
                _uuid_staff_map = json.load(f)
    except Exception:
        pass

def _save_uuid_map():
    try:
        with open(_UUID_MAP_FILE, "w", encoding="utf-8") as f:
            json.dump(_uuid_staff_map, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _load_yach_name_cache():
    """启动时从磁盘恢复工号→姓名映射，使得历史群消息中见过的员工私聊时也能自动识别。"""
    global _yach_user_name_cache
    try:
        if os.path.exists(_YACH_NAME_CACHE_FILE):
            with open(_YACH_NAME_CACHE_FILE, encoding="utf-8") as f:
                _yach_user_name_cache.update(json.load(f))
    except Exception:
        pass

def _save_yach_name_cache():
    try:
        with open(_YACH_NAME_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(_yach_user_name_cache, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _resolve_user_id(raw: str, query: str = "") -> str:
    """将 Dify UUID 解析为真实工号；已是工号格式（4~12位字母数字）则直接返回；未知 UUID 记录到日志供管理员绑定"""
    if re.match(r'^[A-Za-z0-9]{4,12}$', raw or ""):
        return raw
    if not raw:
        return ""
    mapped = _uuid_staff_map.get(raw, "")
    if mapped:
        return mapped
    # 知音楼 UUID（纯数字，无连字符）→ 直接调 /user/get 反查工号，成功则自动绑定
    if "-" not in raw:
        wc = _yach_workcode_for_uuid(raw)
        if wc:
            _uuid_staff_map[raw] = wc
            _save_uuid_map()
            _log_ops(f"🔗 Yach UUID 自动绑定: {raw[:12]}… → {wc}")
            return wc
    return ""

_teable_sync_lock = threading.Lock()
_teable_sync_last: float = 0.0        # 上次同步时间戳，防止高频刷新
_TEABLE_SYNC_MIN_INTERVAL = 300       # 至少间隔 5 分钟才重新同步
_TEABLE_GET_PARAMS = "?take=200&fieldKeyType=name"

def _teable_delete_records(ids: list):
    """用 query string 方式批量删除 Teable 记录（每批最多 100 条）。"""
    for i in range(0, len(ids), 100):
        batch = ids[i:i+100]
        qs = "&".join(f"recordIds[]={rid}" for rid in batch)
        _http.delete(f"{_TEABLE_PERM_URL}?{qs}",
                     headers={"Authorization": _TEABLE_PERM_TOKEN}, timeout=10)

def _sync_perms_to_teable(force: bool = False):
    """Upsert 模式同步权限到 Teable：每个工号只保留一行，不新增重复行。"""
    global _teable_sync_last
    if _http is None:
        return
    import time as _t
    if not force and (_t.time() - _teable_sync_last < _TEABLE_SYNC_MIN_INTERVAL):
        return  # 距上次同步不足 5 分钟，跳过
    if not _teable_sync_lock.acquire(blocking=False):
        return  # 已有同步在跑，跳过本次
    try:
        hdrs = {"Authorization": _TEABLE_PERM_TOKEN, "Content-Type": "application/json"}
        # 读取现有记录（必须加 fieldKeyType=name 才能拿到字段值）
        r = _http.get(_TEABLE_PERM_URL + _TEABLE_GET_PARAMS, headers=hdrs, timeout=10)
        existing = r.json().get("records", []) if r.ok else []
        rec_map: dict = {}        # staff_no → record_id
        rec_fields_map: dict = {} # staff_no → existing field values (for diff check)
        stale_ids = []
        for rec in existing:
            sno = str(rec.get("fields", {}).get(_TF["工号"], "") or "").strip()
            if sno and sno not in rec_map:
                rec_map[sno] = rec["id"]
                rec_fields_map[sno] = rec.get("fields", {})
            else:
                stale_ids.append(rec["id"])  # 空行或重复行

        # 目标工号集合
        target = _SALES_ALLOWED | _DELEGATE_ALLOWED | _ORDER_QUERY_ALLOWED
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        to_update, to_create = [], []
        _names_updated = False
        for sno in sorted(target):
            _nm = _get_staff_name(sno)
            if _nm and not _STAFF_NAMES.get(sno):   # cache 有但 _STAFF_NAMES 没有，顺手回填
                _STAFF_NAMES[sno] = _nm
                _names_updated = True
            core_fields = {
                _TF["工号"]:     sno,
                _TF["备注"]:     _nm,
                _TF["数据权限"]: sno in _SALES_ALLOWED,
                _TF["委派权限"]: sno in _DELEGATE_ALLOWED,
                _TF["订单权限"]: sno in _ORDER_QUERY_ALLOWED,
            }
            if sno in rec_map:
                rec_id = rec_map.pop(sno)  # 始终移出 map，避免误计入 stale_ids
                existing_f = rec_fields_map.get(sno, {})
                # 只比较核心字段（不含时间戳）；Teable checkbox 未勾选返回 None 而非 False，需归一化
                if any((existing_f.get(k) or type(v)()) != v for k, v in core_fields.items()):
                    to_update.append({"id": rec_id, "fields": {**core_fields, _TF["更新时间"]: ts}})
            else:
                to_create.append({"fields": {**core_fields, _TF["更新时间"]: ts}})

        # rec_map 里剩余的 = 已从权限表移除的工号
        stale_ids += list(rec_map.values())

        if _names_updated:
            _save_admin_perms()

        if to_update:
            _http.patch(_TEABLE_PERM_URL + "?fieldKeyType=name", headers=hdrs,
                        json={"records": to_update}, timeout=10)
        if to_create:
            _http.post(_TEABLE_PERM_URL + "?fieldKeyType=name", headers=hdrs,
                       json={"records": to_create}, timeout=10)
        if stale_ids:
            _teable_delete_records(stale_ids)

        _teable_sync_last = _t.time()
        if to_update or to_create or stale_ids:
            _log_ops(f"🔄 Teable 权限变更 更新{len(to_update)} 新增{len(to_create)} 删除{len(stale_ids)}")
    except Exception as e:
        _log_ops(f"⚠️ Teable 同步失败: {e}")
    finally:
        _teable_sync_lock.release()

def _load_perms_from_teable():
    """从 Teable 权限表读取数据，更新本地权限集合与员工姓名"""
    global _SALES_ALLOWED, _DELEGATE_ALLOWED, _ORDER_QUERY_ALLOWED, _STAFF_NAMES
    if _http is None:
        return False
    try:
        hdrs = {"Authorization": _TEABLE_PERM_TOKEN}
        r = _http.get(_TEABLE_PERM_URL + _TEABLE_GET_PARAMS, headers=hdrs, timeout=10)
        if not r.ok:
            return False
        records = r.json().get("records", [])
        new_sales  = {_SUPERADMIN}
        new_dele   = {_SUPERADMIN}
        new_order  = {_SUPERADMIN}
        for rec in records:
            f   = rec.get("fields", {})
            sno = str(f.get(_TF["工号"], "") or "").strip()
            if not re.match(r'^[A-Za-z0-9]{4,12}$', sno):
                continue
            if f.get(_TF["数据权限"]):
                new_sales.add(sno)
            if f.get(_TF["委派权限"]):
                new_dele.add(sno)
            if f.get(_TF["订单权限"]):
                new_order.add(sno)
            name = str(f.get(_TF["备注"], "") or "").strip()
            if name:
                _STAFF_NAMES[sno] = name
        _SALES_ALLOWED       = new_sales
        _DELEGATE_ALLOWED    = new_dele
        _ORDER_QUERY_ALLOWED = new_order
        _save_admin_perms()
        _log_ops(f"⬇️ 从 Teable 同步权限完成: data={sorted(_SALES_ALLOWED)} delegate={sorted(_DELEGATE_ALLOWED)} order={sorted(_ORDER_QUERY_ALLOWED)}")
        nameless = [sno for sno in (_SALES_ALLOWED | _DELEGATE_ALLOWED | _ORDER_QUERY_ALLOWED)
                    if not _STAFF_NAMES.get(sno)]
        if nameless:
            threading.Thread(target=_backfill_staff_names, args=(nameless,), daemon=True).start()
        return True
    except Exception as e:
        _log_ops(f"⚠️ 从 Teable 拉取权限失败: {e}")
        return False



_load_uuid_map()
_load_yach_name_cache()


def _get_staff_name(sno: str) -> str:
    """工号 → 姓名：优先 _STAFF_NAMES，fallback _yach_user_name_cache。"""
    return _STAFF_NAMES.get(sno) or _yach_user_name_cache.get(sno) or ""


def _backfill_staff_names(codes: list):
    """批量为无姓名的工号从知音楼 API 补查，完成后持久化并回写 Teable。"""
    updated = False
    for _sno in codes:
        if not _STAFF_NAMES.get(_sno):
            _name = _yach_user_name_cache.get(_sno) or _yach_lookup_user_name(_sno)
            if _name:
                _STAFF_NAMES[_sno] = _name
                updated = True
    if updated:
        _save_admin_perms()
        _sync_perms_to_teable(True)
        _log_ops(f"✅ 已补全姓名并回写 Teable: {codes}")


def _execute_tool(name: str, args: dict, user_id: str = "", is_group: bool = False, group_id: str = "", notify_ctx: dict = None, query: str = "", raw_uid: str = "", hkey: str = "") -> str:
    """执行 Agent 工具调用，返回文本结果"""
    py = sys.executable
    try:
        if name == "search_products":
            kw = (args.get("keyword") or "").strip()
            if not kw:
                return "请提供商品关键词"
            # LLM 有时会把品类词拼进关键词（如"五年级书籍"），在这里兜底剥离
            # 只有剥除后还剩下内容才替换（防止 keyword="绘本" 被整个清空）
            _stripped_kw = re.sub(r'(书籍?|绘本|课本|教材|练习册|玩具|益智|套装|商品|产品|周边|礼品|礼盒|文具|配件)$', '', kw).strip()
            if _stripped_kw:
                kw = _stripped_kw
            # 阿拉伯数字年级/册转中文（"5年级"→"五年级"，"3册"→"三册"）
            _CN = {'1':'一','2':'二','3':'三','4':'四','5':'五','6':'六','7':'七','8':'八','9':'九'}
            kw = re.sub(r'([1-9])([年级册])', lambda m: _CN[m.group(1)] + m.group(2), kw)
            # ABCtime（上册）、Reading A-Z（下册）、RAZ（单词王点读大书）是三个独立品，不做别名合并
            if not kw:
                return "请提供商品关键词"
            r = subprocess.run([py, S["cs_product"], "--keyword", kw],
                               capture_output=True, text=True,
                               encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS, timeout=20)
            return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else "未查询到相关商品信息"

        if name == "query_sales":
            if user_id not in _SALES_ALLOWED:
                return "抱歉，销售额和订单量数据仅限内购管理员查看，无法为您提供。如需帮助请联系丁洋老师（工号：215734）。"
            date_from = (args.get("date_from") or "").strip()
            date_to   = (args.get("date_to")   or "").strip()
            if not date_from or not date_to:
                return "请提供查询日期范围（date_from 和 date_to）"
            return _query_sales_from_teable("custom", date_from=date_from, date_to=date_to)

        if name == "query_order":
            ent_uid  = (args.get("user_id",  "") or "").strip()
            order_id = (args.get("order_id", "") or "").strip()
            # 姓名→工号：LLM 传姓名时服务端自动解析（含中文则视为姓名）
            if ent_uid and re.search(r'[一-鿿]', ent_uid):
                _name_to_resolve = ent_uid
                _resolved = ""
                for _wc, _nm in {**_yach_user_name_cache, **_STAFF_NAMES}.items():
                    if _nm and _nm in _name_to_resolve and re.match(r'^[A-Za-z0-9]{4,12}$', _wc):
                        _resolved = _wc
                        break
                if _resolved:
                    ent_uid = _resolved
                else:
                    return f"未找到「{_name_to_resolve}」的工号，请确认姓名后重试，或直接提供工号。"
            # 权限控制：普通用户只能查本人订单，_ORDER_QUERY_ALLOWED 内成员可查任意工号
            if user_id and user_id not in _ORDER_QUERY_ALLOWED:
                if ent_uid and ent_uid != user_id:
                    return "订单查询仅限本人，如需查询其他人的订单请联系丁洋老师（知音楼工号：215734）"
                if not order_id:
                    ent_uid = user_id
            # LLM 没传工号时自动用发送者工号
            if not ent_uid and not order_id and user_id:
                ent_uid = user_id
            # UUID 未绑定时（user_id 为空），从原始 query 文本中提取工号作为兜底
            if not ent_uid and not order_id and not user_id and query:
                _m = re.search(r'\b((?=[A-Za-z0-9]*\d)[A-Za-z0-9]{4,12})\b', query)
                if _m:
                    ent_uid = _m.group(1)
            if not ent_uid and not order_id:
                return "未能获取订单信息，请提供订单号（如 JD123456）重新查询，或联系丁洋老师（215734）帮您核实。"
            r = subprocess.run([py, S["cs_order"],
                                "--user_id", ent_uid, "--order_id", order_id],
                               capture_output=True, text=True,
                               encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS, timeout=20)
            return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else "未查询到相关订单信息"

        if name == "query_logistics":
            import re as _re_tool
            raw_exp = (args.get("express_no", "") or "").strip()
            raw_oid = (args.get("order_id",   "") or "").strip()
            # 拆分逗号分隔的多个单号
            exp_list = [x.strip() for x in raw_exp.split(",") if x.strip()]
            oid_list = [x.strip() for x in raw_oid.split(",") if x.strip()]
            # 逐项纠正：含字母前缀 → express_no；纯数字≥15位 → order_id
            for item in list(exp_list):
                if _re_tool.match(r'^\d+$', item) and len(item) >= 15:
                    exp_list.remove(item)
                    oid_list.append(item)
            for item in list(oid_list):
                if _re_tool.match(r'^[A-Za-z]', item):
                    oid_list.remove(item)
                    exp_list.append(item)
            # 没有任何单号 → 用发送者工号自动查最近订单的快递单号
            if not exp_list and not oid_list and user_id:
                try:
                    r0 = subprocess.run([py, S["cs_order"],
                                         "--user_id", user_id, "--order_id", "", "--json_output"],
                                        capture_output=True, text=True,
                                        encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS, timeout=20)
                    if r0.returncode == 0 and r0.stdout.strip():
                        orders = json.loads(r0.stdout)
                        for o in orders:
                            if o.get("express_no"):
                                exp_list.append(o["express_no"])
                                break
                        if not exp_list and orders and orders[0].get("order_id"):
                            oid_list.append(orders[0]["order_id"])
                except Exception:
                    pass
            # 组合为所有 (express_no, order_id) 对：各取一项查询
            pairs = []
            for e in exp_list:
                pairs.append((e, ""))
            for o in oid_list:
                pairs.append(("", o))
            if not pairs:
                return "请提供快递单号或订单号"
            results = []
            for express_no, order_id in pairs:
                r = subprocess.run([py, S["cs_logistics"],
                                    "--express_no", express_no, "--order_id", order_id],
                                   capture_output=True, text=True,
                                   encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS, timeout=20)
                out = r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else "未查询到物流信息"
                results.append(out)
            return "\n\n---\n\n".join(results)

        if name == "query_product_ranking":
            if user_id not in _SALES_ALLOWED:
                return "抱歉，销售排行数据仅限内购管理员查看，如需帮助请联系丁洋老师（工号：215734）。"
            date_from = (args.get("date_from") or "").strip()
            date_to   = (args.get("date_to")   or "").strip()
            top_n     = int(args.get("top_n") or 0)   # 0 = 全量
            sort_by   = (args.get("sort_by") or "qty").strip()
            if not date_from or not date_to:
                return "请提供查询日期范围"
            return _query_product_ranking(date_from, date_to, top_n, sort_by)

        if name == "query_product_analysis":
            if user_id not in _SALES_ALLOWED:
                return "抱歉，经营分析数据仅限内购管理员查看，如需帮助请联系丁洋老师（工号：215734）。"
            date_from     = (args.get("date_from")     or "").strip()
            date_to       = (args.get("date_to")       or "").strip()
            analysis_type = (args.get("analysis_type") or "comprehensive").strip()
            keyword       = (args.get("keyword")       or "").strip()
            top_n         = int(args.get("top_n") or 0)   # 0 = 全量，正数 = 按需截取
            if not date_from or not date_to:
                return "请提供统计日期范围（date_from 和 date_to）"
            return _query_product_analysis(date_from, date_to, analysis_type, keyword, top_n)

        if name == "generate_image":
            prompt = (args.get("prompt") or "").strip()
            if not prompt:
                return "请提供图片描述"
            _log_ops(f"  → 生图（异步）prompt={prompt[:60]}")
            _uid = user_id or ""
            _is_group = is_group
            _gid = group_id or ""
            _job_id = str(uuid.uuid4())
            _async_job_save(_job_id, {"type": "image", "uid": _uid, "prompt": prompt, "ts": time.time(),
                                      "is_group": _is_group, "group_id": _gid})
            _img_hkey = hkey
            def _bg_image(p, uid, jid, img_hkey, bg_is_group, bg_gid):
                try:
                    url = _generate_image(p)
                    if url and url.startswith("http"):
                        _log_ops(f"  ← 异步生图完成: {url[:80]}")
                        if bg_is_group and bg_gid:
                            _yach_send_group_image(bg_gid, url, user_id=uid)
                        elif uid:
                            _yach_send_p2p_markdown(uid, "🎨 图片生成好了！", "🎨 图片生成好了！\n\n![图片](" + url + ")")
                        if img_hkey:
                            _h = list(_get_history(img_hkey))
                            _h.append({"role": "assistant", "content": f"（已生成图片并通过知音楼发送给用户，完整生图 prompt：{p}）"})
                            _save_history(img_hkey, _h)
                    else:
                        _log_ops(f"  ✗ 异步生图失败: {url}")
                        if uid:
                            _yach_send_p2p(uid, "抱歉，图片生成暂时失败了，可能是网络波动，稍后重新发送「生成」指令重试即可 🙏")
                except Exception as e:
                    _log_ops(f"  ✗ 异步生图异常: {e}")
                    if uid:
                        _yach_send_p2p(uid, "抱歉，图片生成暂时失败了，稍后重新发送「生成」指令重试即可 🙏")
                finally:
                    _async_job_done(jid)
            threading.Thread(target=_bg_image, args=(prompt, _uid, _job_id, _img_hkey, _is_group, _gid), daemon=True).start()
            return "🖼️ 图片生成请求已提交！正在后台生成中，预计 2~3 分钟，完成后会直接在知音楼发送给您。\n\n想查询进度，随时问我「图片生成好了吗」即可 😊"

        if name == "generate_video":
            prompt     = (args.get("prompt")     or "").strip()
            mode       = (args.get("mode")       or "text").strip()
            resolution = (args.get("resolution") or "720P").strip()
            ratio      = (args.get("ratio")      or "16:9").strip()
            duration   = int(args.get("duration") or 5)
            img_url_v  = (args.get("img_url")    or "").strip()
            if not prompt:
                return "请提供视频内容描述"
            video_script = S.get("cs_video", "")
            if not video_script or not os.path.exists(video_script):
                return "视频生成服务暂不可用（脚本未找到）"
            _log_ops(f"  → 生视频（异步）mode={mode} prompt={prompt[:50]}")
            _uid = user_id or ""
            _is_group_v = is_group
            _gid_v = group_id or ""
            _vjob_id = str(uuid.uuid4())
            _async_job_save(_vjob_id, {
                "type": "video", "uid": _uid, "prompt": prompt,
                "mode": mode, "resolution": resolution, "ratio": ratio,
                "duration": duration, "img_url": img_url_v,
                "ts": time.time(), "is_group": _is_group_v, "group_id": _gid_v,
            })
            _cmd = [sys.executable, video_script,
                    "--mode",       mode,
                    "--prompt",     prompt,
                    "--resolution", resolution,
                    "--ratio",      ratio,
                    "--duration",   str(duration)]
            if img_url_v:
                _cmd += ["--img_url", img_url_v]
            _vid_hkey = hkey
            def _bg_video(cmd, uid, jid, vid_hkey, vp, bg_is_group=False, bg_gid=""):
                _video_gen_sem.acquire()
                try:
                    r = subprocess.run(cmd, capture_output=True, text=True,
                                       encoding="utf-8", errors="replace", creationflags=_POPEN_FLAGS)
                    stdout = r.stdout.strip()
                    if r.returncode != 0:
                        err = r.stderr.strip()[:300]
                        _log_ops(f"  ✗ 异步视频生成失败: {err}")
                        if uid:
                            if "SubAppId" in err or "401" in err or "403" in err:
                                _yach_send_p2p(uid, "抱歉，图生视频功能暂未开通权限，请改用文字描述生成视频 🙏")
                            else:
                                _yach_send_p2p(uid, "抱歉，视频生成失败了，稍后重新发送「生成视频」重试即可 🙏")
                        return
                    video_url = ""
                    for line in stdout.splitlines():
                        if line.startswith("VIDEO_URL="):
                            video_url = line.split("=", 1)[1].strip()
                    if video_url:
                        _log_ops(f"  ← 异步视频生成完成: {video_url[:80]}")
                        if bg_is_group and bg_gid:
                            _yach_send_group_markdown(bg_gid, "🎬 视频生成好了！", "🎬 视频生成好了！" + chr(10) + chr(10) + "[点击查看视频](" + video_url + ")", uid)
                        elif uid:
                            _yach_send_p2p_markdown(uid, "视频生成好了", "🎬 视频生成好了！" + chr(10) + chr(10) + "[点击查看视频](" + video_url + ")")
                        if vid_hkey:
                            _h = list(_get_history(vid_hkey))
                            _h.append({"role": "assistant", "content": f"（已生成视频并通过知音楼发送给用户，完整生成 prompt：{vp}，链接：{video_url}）"})
                            _save_history(vid_hkey, _h)
                    else:
                        if uid:
                            _yach_send_p2p(uid, "抱歉，视频生成完成但未获取到链接，请重试。")
                except Exception as e:
                    _log_ops(f"  ✗ 异步视频生成异常: {e}")
                    if uid:
                        _yach_send_p2p(uid, "抱歉，视频生成出错了，稍后重新发送「生成视频」重试即可 🙏")
                finally:
                    _video_gen_sem.release()
                    _async_job_done(jid)
            threading.Thread(target=_bg_video, args=(_cmd, _uid, _vjob_id, _vid_hkey, prompt, _is_group_v, _gid_v), daemon=True).start()
            return "视频正在后台生成中，预计 5~10 分钟，完成后会直接在知音楼发送给您。\n\n想查询进度，随时问我「视频生成好了吗」即可 😊"

        # ─── 委派任务工具 ───────────────────────────────────────────────

        if name == "request_delegate_confirm":
            import time as _time, random, string
            bot       = (args.get("bot") or "").strip()
            note      = (args.get("requester_note") or "").strip()
            qc_no     = (args.get("qc_no")    or "").strip().upper()
            qr_no     = (args.get("qr_no")    or "").strip().upper()
            warehouse = (args.get("warehouse") or "武清仓").strip()
            sheet_url = (args.get("sheet_url") or "").strip()
            conf = _DELEGATE_REGISTRY.get(bot)
            if not conf:
                return f"未知任务类型: {bot}，可选: {list(_DELEGATE_REGISTRY)}"

            if bot == "selection_upload":
                if not sheet_url:
                    return "导入待上架明细需要提供表格 URL，请重新发送表格链接。"
                extra_lines = f"\n表格：{sheet_url}"
                note = note or f"导入待上架明细：{sheet_url}"
            elif bot == "wms_audit":
                if not qc_no or not qr_no:
                    return "WMS审核需要提供出库单号（QC开头）和入库单号（QR开头），请补充后重试。"
                extra_lines = f"\n出库单：{qc_no}\n入库单：{qr_no}\n仓库：{warehouse}"
                note = note or f"{qc_no} / {qr_no} {warehouse}"
            else:
                extra_lines = ""

            token = "CONF-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
            _pending_delegations[token] = {
                "bot": bot, "note": note,
                "ts": _time.time(), "requester": user_id,
                "params": {"qc_no": qc_no, "qr_no": qr_no,
                           "warehouse": warehouse, "requester": user_id,
                           "sheet_url": sheet_url},
            }
            _save_delegates()
            _log_ops(f"  📋 委派请求: token={token} bot={bot} requester={user_id}")

            confirm_kw = conf.get("confirm_keyword", "确认执行")
            notice = (
                f"📋 委派确认请求\n\n"
                f"智能客服收到任务委派申请\n"
                f"任务：{conf['bot_name']}\n"
                f"发起人：工号 {user_id or '未知'}\n"
                f"内容：{note or '（未备注）'}"
                f"{extra_lines}\n\n"
                f"✅ 同意请回复：{confirm_kw}\n"
                f"❌ 拒绝请回复：取消\n\n"
                f"（令牌：{token}，30 分钟内有效）"
            )
            sent = _yach_send_p2p("215734", notice)
            if sent:
                reply = f"已向丁洋老师申请确认，批准后将自动通知{conf['bot_name']}执行。"
                return reply
            else:
                del _pending_delegations[token]
                _save_delegates()
                return "抱歉，通知丁洋老师时发生网络错误，请稍后重试。"

        if name == "execute_pending_delegate":
            import time as _time
            if is_group:
                return "委派确认请在与我的私聊窗口中操作。"
            if user_id not in _DELEGATE_ALLOWED:
                return "抱歉，委派确认权限不足，如需开通请联系丁洋老师（工号：215734）。"
            now = _time.time()
            valid = {
                t: v for t, v in _pending_delegations.items()
                if now - v["ts"] < _DELEGATE_EXPIRE
            }
            if not valid:
                return "当前没有待确认的委派任务（已过期或不存在）。"
            results = []
            for token, pending in sorted(valid.items(), key=lambda x: x[1]["ts"]):
                bot    = pending["bot"]
                params = pending.get("params", {})
                _log_ops(f"  ✅ 丁洋确认执行: token={token} bot={bot}")
                try:
                    results.append(_delegate_teable_write(bot, params))
                except Exception as e:
                    results.append(f"委派{bot}失败：{e}")
                del _pending_delegations[token]
            _save_delegates()
            return "\n\n".join(results)

        if name == "cancel_pending_delegate":
            import time as _time
            if is_group:
                return "委派取消请在与我的私聊窗口中操作。"
            if user_id not in _DELEGATE_ALLOWED:
                return "抱歉，委派取消权限不足，如需开通请联系丁洋老师（工号：215734）。"
            now = _time.time()
            expired = [t for t, v in _pending_delegations.items() if now - v["ts"] >= _DELEGATE_EXPIRE]
            for t in expired:
                del _pending_delegations[t]
            if expired:
                _save_delegates()
            if not _pending_delegations:
                return "当前没有待取消的委派任务。"
            count = len(_pending_delegations)
            _pending_delegations.clear()
            _save_delegates()
            _log_ops(f"  ❌ 委派任务已取消 (共 {count} 条)")
            return "已取消所有待确认的委派任务，不会执行任何自动化操作。"

        if name == "notify_admin":
            reason = (args.get("reason") or "").strip()
            _log_ops(f"  📨 notify_admin: {reason[:80]}")
            if notify_ctx is not None:
                # 延迟发送：等 LLM 生成完整回复后一并发出
                notify_ctx["reason"]   = reason
                notify_ctx["group_id"] = group_id
                notify_ctx["user_id"]  = user_id
            else:
                threading.Thread(
                    target=_yach_send_group_at,
                    args=(reason,),
                    kwargs={"group_id": group_id, "user_id": user_id},
                    daemon=True,
                ).start()
            return "已通知丁洋老师（215734）跟进处理。"

        if name == "manage_permission":
            action  = (args.get("action") or "").strip()
            target  = (args.get("target") or "").strip()
            types   = args.get("types") or []
            type_str = " ".join(types)

            if action == "list":
                all_wcs = sorted(_SALES_ALLOWED | _DELEGATE_ALLOWED | _ORDER_QUERY_ALLOWED)
                if not all_wcs:
                    return "当前没有任何已授权员工。"
                lines = ["**当前权限列表**\n"]
                for wc in all_wcs:
                    nm = _get_staff_name(wc)
                    label = f"{nm}（{wc}）" if nm else wc
                    perms = []
                    if wc in _SALES_ALLOWED:       perms.append("数据")
                    if wc in _DELEGATE_ALLOWED:    perms.append("委派")
                    if wc in _ORDER_QUERY_ALLOWED: perms.append("订单")
                    lines.append(f"· {label}：{'、'.join(perms)}权限")
                return "\n".join(lines)

            if user_id != _SUPERADMIN:
                return "权限管理操作（授权/取消授权）仅限超级管理员（215734）执行。"

            if not target:
                return "请提供目标员工的工号。"

            nm    = _get_staff_name(target)
            label = f"{nm}（{target}）" if nm else target

            if action == "revoke":
                if target == _SUPERADMIN:
                    return "超级管理员权限不可移除。"
                _SALES_ALLOWED.discard(target)
                _DELEGATE_ALLOWED.discard(target)
                _ORDER_QUERY_ALLOWED.discard(target)
                _save_admin_perms()
                threading.Thread(target=_sync_perms_to_teable, args=(True,), daemon=True).start()
                _log_ops(f"🔐 [perm] 取消授权: {target}（{nm}）by {user_id}")
                return f"已取消 {label} 的全部权限 ✅"

            if action == "grant":
                has_all = "全部" in type_str or not type_str
                granted = []
                if has_all or any(k in type_str for k in ("数据", "销售", "经营", "库存")):
                    _SALES_ALLOWED.add(target); granted.append("数据")
                if has_all or "订单" in type_str or "跨工号" in type_str:
                    _ORDER_QUERY_ALLOWED.add(target); granted.append("订单")
                if has_all or any(k in type_str for k in ("委派", "确认")):
                    _DELEGATE_ALLOWED.add(target); granted.append("委派")
                if not granted:
                    return "请指定要授予的权限类型（数据/订单/委派/全部）。"
                if not _STAFF_NAMES.get(target):
                    _backfill_staff_names([target])
                    nm    = _get_staff_name(target)
                    label = f"{nm}（{target}）" if nm else target
                _save_admin_perms()
                threading.Thread(target=_sync_perms_to_teable, args=(True,), daemon=True).start()
                _log_ops(f"🔐 [perm] 授权: {target}（{nm}）{'、'.join(granted)} by {user_id}")
                return f"已给 {label} 授予{'、'.join(granted)}权限 ✅"

            if action == "remove":
                if not type_str:
                    return "请指定要移除的权限类型（数据/订单/委派）。"
                removed = []
                if any(k in type_str for k in ("数据", "销售", "经营", "库存")):
                    _SALES_ALLOWED.discard(target); removed.append("数据")
                if "订单" in type_str or "跨工号" in type_str:
                    _ORDER_QUERY_ALLOWED.discard(target); removed.append("订单")
                if any(k in type_str for k in ("委派", "确认")):
                    _DELEGATE_ALLOWED.discard(target); removed.append("委派")
                if not removed:
                    return "请指定要移除的权限类型（数据/订单/委派）。"
                _save_admin_perms()
                threading.Thread(target=_sync_perms_to_teable, args=(True,), daemon=True).start()
                _log_ops(f"🔐 [perm] 移除权限: {target}（{nm}）{'、'.join(removed)} by {user_id}")
                return f"已移除 {label} 的{'、'.join(removed)}权限 ✅"

            return f"未知 action: {action}"

        if name == "query_job_status":
            try:
                if os.path.exists(_ASYNC_JOBS_FILE):
                    with open(_ASYNC_JOBS_FILE, 'r', encoding='utf-8') as _jf:
                        jobs = json.load(_jf)
                else:
                    jobs = {}
            except Exception:
                jobs = {}
            if not jobs:
                return "所有任务都已完成啦！如果没收到结果，可能是任务期间服务重启导致中断，请重新发起生成请求 🙏"
            img_jobs = [j for j in jobs.values() if j.get('type') == 'image']
            vid_jobs = [j for j in jobs.values() if j.get('type') == 'video']
            parts = []
            if img_jobs:
                descs = '、'.join(f"「{j.get('prompt','')[:20]}…」" for j in img_jobs)
                parts.append(f"🎨 图片生成中（{len(img_jobs)}个）：{descs}")
            if vid_jobs:
                descs = '、'.join(f"「{j.get('prompt','')[:20]}…」" for j in vid_jobs)
                parts.append(f"🎬 视频生成中（{len(vid_jobs)}个）：{descs}")
            return "任务还在后台跑呢，请稍等～\n\n" + "\n".join(parts) + "\n\n完成后会直接推送到您的知音楼消息 😊"


        return f"未知工具: {name}"
    except Exception as e:
        return f"工具执行异常: {e}"


def _glm_agent_chat(query: str, user_id: str = "", user_name: str = "",
                    image_content: list = None,
                    hist_uid: str = "", is_group: bool = False, group_id: str = "",
                    context: str = "", backend: dict = None, notify_event: "threading.Event" = None,
                    is_webhook: bool = False, group_name: str = "", dialog_count: int = 0,
                    app_id: str = "", workflow_run_id: str = "") -> str:
    """GLM tool_use Agent 对话：自主决策调用工具，生成最终自然语言回复。
    image_content: 非空时为多模态列表 [{"type":"text","text":...}, {"type":"image_url",...}]
    hist_uid: 会话历史 key（工号优先，UUID 兜底），空则不记忆
    is_group: True=群聊，False=私聊；确认/取消委派仅在私聊中对 _DELEGATE_ALLOWED 用户生效
    group_id: 群聊时的群 ID，用于 notify_admin 在原群 @管理员
    """
    if _http is None:
        return _STATIC_REPLY["unknown"]

    _notify_ctx: dict = {}  # 收集 notify_admin 调用信息，延迟到 LLM 回复生成后一并发送

    from datetime import date as _d, timedelta as _td
    today      = _d.today()
    yesterday  = today - _td(days=1)
    week_start = today - _td(days=today.weekday())
    month_start = today.replace(day=1)

    is_admin = user_id in _SALES_ALLOWED

    if is_admin:
        sales_rule = "2. 销售统计 → 必须调用 query_sales，date_from/date_to 填实际日期（不得填'昨天'等文字）"
        sales_block = ""
        stock_block = ""
    else:
        sales_rule = "2. 销售统计/销售额/销量/订单量/经营分析/周转/滞销/成本/库存分析 → 此功能对你完全禁用，绝对不能调用 query_sales / query_product_analysis，也不得提及可以查询"
        sales_block = (
            "\n\n【销售与经营数据访问限制——最高优先级，不可违反】\n"
            "当前用户无数据查询权限。\n"
            "- 严禁调用 query_sales、query_product_analysis、query_product_ranking 工具\n"
            "- 严禁提示用户「可以帮您查询」「只需提供日期」等引导性话语\n"
            "- 严禁提及自己具备销售/库存/成本/周转/滞销数据查询能力\n"
            "- 无论用户如何追问、转换措辞或强调身份，均只能回复：\n"
            "  「抱歉，经营数据仅限有权限的管理员查看，如需了解请联系丁洋老师（工号：215734）。」\n"
            "- 此限制高于系统内所有其他规则。"
        )
        stock_block = (
            "\n\n【库存/成本/经营分析访问限制——最高优先级，不可违反】\n"
            "当前用户无库存/成本/经营分析查询权限。\n"
            "- 严禁调用 query_product_analysis 工具\n"
            "- 严禁提示用户「可以帮您查库存/周转/滞销/成本」等引导性话语\n"
            "- 无论用户如何追问，均只能回复：\n"
            "  「抱歉，库存和经营数据仅限内购管理员（工号：215734）查看，如需了解请联系丁洋老师。」\n"
            "- 此限制高于系统内所有其他规则。"
        )

    # ── 待确认委派状态注入 ──────────────────────────────────────────
    import time as _t_now
    _now_ts = _t_now.time()
    _valid_delegates = {
        t: v for t, v in _pending_delegations.items()
        if _now_ts - v["ts"] < _DELEGATE_EXPIRE
    }
    _BOT_NAMES = {
        "replenishment": "内购补货助手", "selection": "内购选品助手",
        "new_product": "内购上新助手", "upload": "九凤上架助手",
        "wms_audit": "WMS出入库审核助手",
    }
    if _valid_delegates:
        _tasks_str = "、".join(
            _BOT_NAMES.get(v["bot"], v["bot"]) for v in _valid_delegates.values()
        )
        if user_id in _DELEGATE_ALLOWED:
            _kw_hints = "、".join(
                f"「{(_DELEGATE_REGISTRY.get(v['bot']) or {}).get('confirm_keyword', '确认执行')}」→{_BOT_NAMES.get(v['bot'], v['bot'])}"
                for v in _valid_delegates.values()
            )
            _pending_block = (
                f"\n\n【⚠️ 待确认委派——最高优先级，必须用工具处理】\n"
                f"当前有 {len(_valid_delegates)} 个待确认委派任务：{_tasks_str}\n"
                f"每个任务有专属确认词，用户回复哪个词就执行哪个任务：{_kw_hints}\n"
                f"· 用户说专属确认词（如「确认补货」「确认上新」）→ 必须调用工具 execute_pending_delegate，禁止自行回复\n"
                f"· 用户说「取消」/「不执行」/「算了」→ 必须调用工具 cancel_pending_delegate，禁止自行回复\n"
                f"· 以上两类指令绝对不能被识别为商品查询、订单查询或任何其他意图\n"
                f"· 收到以上指令后，第一步就是调用对应工具，工具返回结果即为最终回复"
            )
        else:
            _pending_block = (
                f"\n\n【待确认委派状态】当前有 {len(_valid_delegates)} 个待确认委派任务（{_tasks_str}），"
                f"等待丁洋老师（215734）确认中。当前用户无权执行或取消委派。"
            )
    else:
        _pending_block = ""

    _weekday_cn = ['周一','周二','周三','周四','周五','周六','周日'][today.weekday()]
    system = (
        f"你是好未来内购商城智能客服助手。\n\n"
        f"【🚨 绝对禁止——违反即为错误回复】\n"
        f"凡涉及以下内容，必须先调工具获取实时数据，绝对禁止凭训练知识、历史对话、猜测或「我知道」来回答：\n"
        f"· 商品是否有货/上架/价格/库存/图片/链接 → 必须调 search_products\n"
        f"· 订单状态/订单号/是否发货 → 必须调 query_order\n"
        f"· 物流/快递单号/签收状态 → 必须调 query_logistics\n"
        f"· 销售数据/销量/滞销/经营分析 → 必须调 query_sales / query_product_analysis\n"
        f"违禁行为举例（以下全部错误）：\n"
        f"  ❌ 「这款商品暂时没有库存」（没调工具）\n"
        f"  ❌ 「您的订单应该发货了」（没调工具）\n"
        f"  ❌ 「我们有这款产品，价格大概是XX元」（没调工具）\n"
        f"  ❌ 「根据之前查询结果……」（用了历史数据而不是重新查）\n"
        f"正确做法：不管问题多简单，只要涉及商品/订单/物流，先调工具，用工具返回的数据回答。\n\n"
        f"【工作方式 — 每条消息必须按这三步走】\n"
        f"第一步·想清楚：收到消息先在心里想：「用户到底在问什么？是产品推荐、价格查询、兼容性、使用说明、还是闲聊？涉及哪些产品？需要调哪些工具？」\n"
        f"第二步·行动：根据判断并行调用所有必要工具，一次拿齐所有数据。涉及兼容性/推荐类的问题，必须把所有相关 keyword 都搜到，不能只搜一两个就回复。\n"
        f"第三步·回复：用口语、有温度的方式整理答案，像真人客服一样——不念规则、不套模板、自然亲切。每款商品完整展示（价格+库存+图片+链接），一款都不省略。\n"
        f"内购业务是主线，也可以随口聊几句，但自然带回业务就好。\n\n"
        f"【当前上下文】\n"
        + (f"当前用户：{user_name}老师（工号 {user_id}）{'（委派确认权限）' if user_id in _DELEGATE_ALLOWED else ''}\n"
           if user_name and user_id else
           f"当前用户工号：{user_id or '未知（首次使用，尚未绑定）'}{'（委派确认权限）' if user_id in _DELEGATE_ALLOWED else ''}\n")
        + _build_workcode_unknown_block(user_id, is_group)
        + f"今天：{today}（{_weekday_cn}）｜昨天：{yesterday}｜本周：{week_start}～{today}｜本月：{month_start}～{today}\n"
        f"{_pending_block}\n\n"
        + (f"【产品知识库】以下是从知识库检索到的相关产品文档（JSON 格式，取 answer 字段的文本内容）：\n{context}\n\n"
           f"【知识库解析与融合规则（强制）】\n"
           f"0. 解析：上方 context 是 JSON，先提取 answer 字段的文本（即产品介绍正文），再按以下规则融合\n"
           f"1. 知识库内容只是产品介绍，商城实时数据（价格/库存/图片/购买链接）需另外调用 search_products 查询\n"
           f"2. 场景A—推荐类（用户问「X岁适合什么/有什么产品/推荐」）：\n"
           f"   a. 从 answer 文本中逐一提取所有提到的产品名\n"
           f"   b. 对每个产品名调用 search_products(keyword=产品名)——不要用年龄段或品类词做 keyword\n"
           f"   c. **逐款展示**：search_products 返回几款就展示几款，每款必须包含：名称、内购价、市场价、库存状态（✅有货/⚠️待上架/⚠️暂无货）、🔗商品直达链接、图片——所有字段均原样复制自工具返回，不得删减\n"
           f"   格式规范（强制，违反就是错）：每款必须用以下 4 行多行格式，**绝对禁止**压成单行紧凑写法（「N. 商品名 — ¥X 状态」这种就是错的）：\n"
           f"     ```\n"
           f"     N. 商品名\n"
           f"     内购价：¥X.XX  市场价：¥Y.YY  ✅有货/⚠️暂无货\n"
           f"     🔗 [商品直达](url)\n"
           f"     \n"
           f"     ![商品图片](img_url)\n"
           f"     ```\n"
           f"   每款的图片行前留一个空行，让 ![ 独立成段；URL 必须从工具结果**原样复制**，不得删减、不得省略图片\n"
           f"   d. 禁止用「系列代表」「举例介绍」「以下是部分」等方式省略——工具返回多少款就展示多少款，一条不能少\n"
           f"   e. 回复再长也要一次性输出完整内容，禁止问「还需要看更多吗」——续发机制会自动分段送达\n"
           f"3. 场景B—兼容性类（用户问「点读笔适合哪些书/XXX支持哪些书」）：知识库给出兼容表格 → 完整展示表格，**同时对表格第一列的每个书名/产品名分别调用 search_products**，在每行旁边补充内购价/库存/直达链接；无法搜到的注明「商城暂无上架」\n"
           f"4. 禁止只输出知识库表格而不搜商城；禁止说「告诉我你想查哪款的价格」——直接查完一起发\n"
           f"5. 商城搜不到的条目注明「商城暂无上架」，有货的必须附直达链接和图片\n\n"
           if context and len(context.strip()) >= 20 else
           f"【产品知识库（本轮未命中）】Dify hybrid_search 本轮没匹配到段落。**这只是关键词没对上**——并不能据此判断「知识库里有没有这款产品的文档」，你不知道知识库里收录了什么、没收录什么。\n\n"
           f"【产品兜底知识图谱（仅用于关键词映射，不是产品介绍来源）】\n"
           f"用户问的产品名常有别名/简称，下表帮你识别用户**意图**和搜索 keyword，不能当作产品介绍内容来源：\n"
           f"- 小猴点读笔（学而思官方点读笔）— 用户问「适用/支持/搭配/兼容/能读/配套哪些产品/书」时，\n"
           f"  必须逐一搜索以下全部 keyword（一个都不能少）：\n"
           f"  \"小猴点读笔\"（笔本体）、\"哈佛外教英语启蒙\"、\"ABCtime\"（上册）、\"Reading\"（下册 Reading A-Z）、\"RAZ\"（单词王）、\"摩比分级数学\"、\"摩比汉语分级\"、\"摩比自然拼读\"、\"迪士尼英语\"、\"大师英文\"\n"
           f"  共 10 次 search_products，全部搜完后按系列分组输出，有货的每款附图片和直达链接，搜不到结果的系列注明「商城暂无上架」\n"
           f"- ABCtime、Reading A-Z、RAZ 是三个独立的品，不得合并查询：\n"
           f"  ABCtime（上册）→ keyword=\"ABCtime\"；Reading A-Z（下册）→ keyword=\"Reading\"；RAZ 单词王 → keyword=\"RAZ\"\n"
           f"- 摩比爱数学 和 摩比分级数学 是两个不同的品，不能互相替代：\n"
           f"  用户说「摩比爱数学」→ keyword=\"摩比爱数学\"；用户说「摩比分级数学」→ keyword=\"摩比分级数学\"\n"
           f"- 摩比数学（含糊时）→ 两个都查，分别展示结果\n"
           f"- 摩比爱语文/摩比语文 → 摩比汉语分级（先查 keyword=\"摩比汉语分级\"）\n"
           f"- 哈佛外教 / 哈佛启蒙 → 哈佛外教英语启蒙\n"
           f"- 迪士尼英语 / Disney English → 迪士尼英语\n"
           f"- 其他用户提到的产品名按字面 keyword 直接查，找不到再用主体词重试\n\n"
           f"【未命中处理规则（最高优先级，违反=回复错误）】\n"
           f"⚠️ **核心原则**：诚实 + 主动查 + 不说谎 + 不追问。\n\n"
           f"1. 🚨 **严禁谎称「知识库里没有」**——下列说法**全部禁止**，因为你**根本不知道**知识库里有什么：\n"
           f"   ❌「XX 不在我目前收录的产品知识库里」\n"
           f"   ❌「暂时没有它的官方使用说明文档」\n"
           f"   ❌「我的知识库里没有这款产品的资料」\n"
           f"   ❌「目前知识库中暂未收录 XX 的详细文档」\n"
           f"   ✅ 正确做法：直接调工具查，把查到的告诉用户；产品文档没匹配上就**绝口不提知识库这事**，只展示能拿到的（商城信息 + 用户上下文中已有的信息）\n\n"
           f"2. 🚨 **严禁追问用户「您想了解哪一款 / 哪一方面」**——这违反「主动思考」原则\n\n"
           f"3. 推断流程（每一步必须执行）：\n"
           f"   a. 提取产品名：从用户当前问题 + **对话历史最近 3 轮**里提取产品名/品牌主体词（如用户上一句问「迪士尼英语的使用说明」，下一句「使用说明发我下」→ 当前主体仍是「迪士尼英语」）\n"
           f"   b. 别名映射：对照上方图谱，ABCtime/Reading A-Z/RAZ 是三个独立品（上册/下册/单词王），不得合并；摩比爱数学和摩比分级数学同样独立，不得互换\n"
           f"   c. 调 search_products(keyword=映射后产品名)，把价格/库存/链接/图片展示给用户\n"
           f"   d. 如用户问的是「使用说明/怎么用/激活步骤」类**产品文档型**问题，工具返回后再尝试追加调用 1 次 search_products(keyword=具体级别名)，看是否有更精准结果——**绝不胡编使用说明内容**\n\n"
           f"4. 关于「产品文档型」问题（用户问使用说明/激活/适合年龄/课程内容/Q&A）的诚实回复模板：\n"
           f"   - 先列出从 search_products 拿到的商城信息（价格/库存/图片/链接）\n"
           f"   - 然后说：「关于 {{产品名}} 的详细 {{使用说明 / 课程内容 / 适合年龄}}，**这次没查到对应的产品文档**——你换一个更具体的问法（比如「{{产品名}}+具体级别」或「{{产品名}}怎么激活」）我再帮您查一次。」\n"
           f"   - **关键**：说「这次没查到」，不要说「知识库里没有」——前者是事实（确实这次没拿到），后者是说谎（你不知道）\n\n"
           f"5. 兼容性查询（含「适合/兼容/支持哪/搭配/配套/能用/可以用/哪些书/哪些产品」）：\n"
           f"   - 按上方图谱逐个产品分别调 search_products（小猴点读笔必须搜全部 7 个 keyword；其他产品也要把图谱里列出的每个 keyword 都搜一遍）\n"
           f"   - 输出按系列分组：`### 一、产品名` 标题 + 该 keyword 下全部商品\n"
           f"   - **每款必须用 4 行多行格式**，绝对禁止压成「N. 商品名 — ¥X 状态」单行：\n"
           f"     ```\n"
           f"     N. 商品名\n"
           f"     内购价：¥X.XX  市场价：¥Y.YY  ✅有货/⚠️暂无货\n"
           f"     🔗 [商品直达](url)\n"
           f"     \n"
           f"     ![商品图片](img_url)\n"
           f"     ```\n"
           f"   - URL 和图片 URL **从工具结果原样复制**，不得删减；图片行前留空行成独立段\n"
           f"   - 商城无结果的系列保留标题 + 注「商城暂无上架」\n\n"
           f"6. 全程不暴露「检索失败」「知识库未命中」「context 为空」等技术细节\n\n"
           )
        + f"【称谓】对人一律称「老师」，禁用「同学」。售后联系人：内购管理员丁洋老师（知音楼工号：215734）。\n\n"
        f"【你能调用的工具】\n"
        f"· search_products(keyword)  —  查商品价格/库存/规格/图片\n"
        f"  - keyword 只用品牌名、产品名主体或年级描述词，去掉「书籍/玩具/绘本/套装」等品类词\n"
        f"  - 例：「摩比的书籍有哪些」→ keyword=\"摩比\"；「学而思玩具」→ keyword=\"学而思\"；「5年级的书」→ keyword=\"五年级\"（数字年级必须用中文）\n"
        f"  - 【三品独立规则】ABCtime（上册）、Reading A-Z（下册）、RAZ（单词王点读大书）是三个独立品，绝不合并查询：\n"
        f"    用户问「ABCtime有什么」→ keyword=\"ABCtime\"；「Reading A-Z有哪些」→ keyword=\"Reading\"；「RAZ」→ keyword=\"RAZ\"\n"
        f"  - 工具返回的是该关键词下全部在售商品，必须逐条完整列出所有结果，绝对禁止按品类二次过滤或省略\n"
        f"  - 即使用户问的是「摩比的书籍」，只要 keyword 是「摩比」，就把所有摩比商品全部展示，一条都不能省\n"
        f"  - 禁止用分类标题（如「书籍类」「玩具类」）分组，禁止说「另外还有X款」——直接按编号1.2.3...列完\n"
        f"  - 所有结果均逐条含图片和链接展示，无论结果数量多少，禁止以「结果太多」为由省略图片或链接\n"
        f"  - 工具返回的文本末尾已含商城链接，直接原样保留，不要删除或改写\n"
        f"  - 搜不到时必须立即换更短/更通用的关键词重试一次，不能直接告诉用户没有\n"
        f"  - 结果含图片链接就用 ![商品图片](url) 展示出来\n"
        f"  - 每款商品已含库存状态（✅ 有货 / ⚠️ 暂无货）和「🔗 商品直达：」手机端直链，原样保留，不要删改\n"
        f"  - 商城整体入口「🏪 内购商城入口：」和商品直达链接「🔗 商品直达：」是两个不同地址，区分清楚\n"
        f"  - 用户说「直达链接/发个链接/我要链接」→ 直接从当前或历史搜索结果中找到对应商品的 🔗 商品直达链接给出，禁止说「没有独立链接」\n"
        f"  【链接完整性规则（强制）】\n"
        f"  - 所有 🔗 商品直达 URL 必须原样复制自工具返回结果，禁止任何修改、截断或自行构造\n"
        f"  - 工具结果中有链接的商品必须保留该链接；工具结果中无链接的商品不要自行添加链接\n"
        f"  - 禁止把A商品的链接贴到B商品名称下面\n"
        f"  - 所有商品均应附上图片（工具结果中有图片链接就展示）和直达链接，完整呈现\n"
        f"  - 用户发图片时，keyword 用图片里识别到的文字（书名/品牌名），不用卡通角色名或吉祥物名\n"
        f"{sales_rule}\n"
        f"· query_product_ranking(date_from, date_to, sort_by, top_n)  —  销售排行榜\n"
        f"  销量排行用 sort_by=qty，销售额排行用 sort_by=amount；top_n 不传或传0=全量（默认），指定数字=取前N名\n"
        f"· query_product_analysis(date_from, date_to, analysis_type, keyword, top_n)  —  综合经营分析\n"
        f"  整合销售 + 成本 + 库存数据，一次调用完成以下任意分析：\n"
        f"  analysis_type 取值：\n"
        f"    turnover    = 周转率/周转天数（库存消耗速度）\n"
        f"    slow_moving = 滞销商品（库存>0且周转天>90，或零销售）\n"
        f"    cost        = 成本/毛利润分析（销售额-成本=毛利）\n"
        f"    inventory   = 库存情况（当前库存量、库存价值）\n"
        f"    sales       = 销售情况（按销售额/销量排序）\n"
        f"    comprehensive = 综合概要（默认，包含以上全部摘要）\n"
        f"  keyword 可过滤特定商品；top_n 控制展示条数（默认0=全量；用户说「前十」传10，说「全部」或未指定传0）\n"
        f"  用户问「周转率」「滞销」「成本分析」「库存情况」「经营分析」「毛利率」「综合分析」时均调用此工具\n"
        f"  权限与 query_sales 相同（_SALES_ALLOWED），无权限时拒绝并说明只有管理员可查\n"
        f"· query_order(user_id, order_id)  —  订单查询\n"
        f"  🚨 铁律：每次用户问订单，必须实时调用此工具，绝对不允许凭对话记忆直接回答——订单状态会变化，记忆里的结果可能已过期\n"
        f"  用户说「我的订单/查一下我的/帮我查」→ {'**直接调用**，user_id 传空，server 自动识别，不要问用户工号' if user_id else '先问一次工号（见上方⚠️规则），拿到工号后再调工具'}\n"
        f"  ⚠️ 权限限制：普通用户只能查本人订单；有订单查询权限的管理员可查任意工号\n"
        f"  {'✅ 您有跨员工订单查询权限；规则：① 当前这条消息里有对方的工号数字 → 直接调 query_order；② 当前这条消息里只有姓名没有工号 → 必须回复「请提供对方的工号」，等对方回复后再调工具，⚠️ 严禁从历史记录中提取工号（历史里的工号可能张冠李戴）' if user_id in _ORDER_QUERY_ALLOWED else '用户要查别人的订单 → 直接告知「订单查询仅限本人，如需查他人订单请联系丁洋老师（215734）」，不要调工具'}\n"
        f"· query_logistics(express_no, order_id)  —  物流查询\n"
        f"  含字母前缀（SF/JT/YT/ZTO等）判为 express_no，纯数字判为 order_id；多个单号一次全传，不分开调用\n"
        f"  用户说「查我的快递/我的物流/快到哪了」但没给单号 → 先调 query_order(user_id={user_id or '当前工号'}) 拿快递单号，再查物流\n"
        f"· manage_permission(action, target, types)  —  权限管理\n"
        f"  action=list 查看权限；grant 新增指定权限；remove 移除指定权限（保留其余）；revoke 取消全部权限\n"
        f"  {'✅ 您是超级管理员，可执行全部权限操作；target 传工号；types 填：数据/订单/委派/全部' if user_id == _SUPERADMIN else '⚠️ list 查询任何人可用；其余仅超级管理员可执行'}\n"
        f"· query_job_status()  —  查询 AI 生图/视频后台任务进度，用户问「好了吗/进度/完成了吗」时调用\n"
        f"· generate_image(prompt)  —  AI 生图，完成后用 ![图片](URL) 展示\n"
        f"  🚫 严禁触发 generate_image 的情形：用户说「好的」「真棒」「谢谢」「不错」「收到」「好」「嗯」等简短确认/夸奖，图片刚生成完用户只是在回应，或用户没提任何新图片内容。只有用户本轮明确提出新的创作描述才可调用。\n"
        f"  ⚠️ 必须先判断用户要的是「商品图」还是「AI创作图」，再决定用哪个工具：\n"
        f"  📦 情况A：用户问已知商品（内购商城产品，如小猴点读笔/摩比/哈佛外教/迪士尼等）的图片/照片/图\n"
        f"    → 立即调 search_products(该商品名)，结果中的 ![商品图片] 就是商品图，直接展示\n"
        f"    → 绝对不要调 generate_image（AI生成的不是真实商品图）\n"
        f"    → 绝对不要说「请您发一下图片，我来帮您识别」——用户要的是商品图，不是让你识别\n"
        f"  🎨 情况B：用户要AI创作/合成的图（「画一只猫」「生成XXX场景图」「做张海报」「帮我P图」）\n"
        f"    → 才调 generate_image(prompt=内容描述)，完成后用 ![图片](URL) 展示\n"
        f"  🧠 调用 generate_image 的意图判断原则（适用所有情况）：\n"
        f"    → 先问自己：用户是否在明确请求「现在帮我创作一张新图」？\n"
        f"    → 意图测试：用户的话能否自然替换成「请帮我画一张[具体内容]」？能 → 调用；不能 → 不调用\n"
        f"    → 夸奖已有图片（「画得太好了」「好看」「太棒了」「厉害」）= 情绪/态度表达，不是创作请求，直接回应即可\n"
        f"    → 对图片有调整意见（「太暗」「换个风格」「不好看」）= 先问「要重新画一张吗？」等确认，不要自动重画\n"
        f"    → 以上两种情况都不涉及售后/商品，严禁通知丁洋老师\n"
        f"  ❌ 情况C：用户主动发来图片附件（消息里已含图片文件）\n"
        f"    → 才是图片识别场景，识别后说出商品名称，如需确认再问\n"
        f"  🚨 铁律：用户说「提供/给我/发/来/看看 XX 的图片/照片/图」——\n"
        f"    ✅ XX 是内购商品 → search_products(XX)，展示商品图\n"
        f"    ✅ XX 是创意内容 → generate_image(prompt=XX)\n"
        f"    ❌ 无论哪种情况，都绝对禁止回复「请您发一下图片，我来帮您识别」——那是答非所问\n\n"
        f"· generate_video(prompt, mode, size, duration)  —  AI 视频生成\n"
        f"  🧠 调用前先判断意图：用户是否在明确请求「现在帮我创作一段新视频」？\n"
        f"  意图测试：用户的话能否替换成「请帮我做一段[具体内容]的视频」？能 → 调用；不能 → 不调用\n"
        f"  夸奖已有视频（「视频好看」「效果不错」「厉害」）= 情绪表达，直接回应，绝不调用\n"
        f"  对视频有意见（「太短」「画质不好」「换个风格」）= 先问「要重新生成一段吗？」等确认\n"
        f"  ✅ 用户描述想要的画面内容 → 提取核心描述作为 prompt，mode 默认 text\n"
        f"  ✅ 用户发图片 + 说要视频 → mode=image，img_url 用刚识别到的图片 URL\n"
        f"  ✅ 用户给视频链接 + 说「基于这个/改一改」→ mode=remix，提取 ID\n"
        f"  size 默认竖屏(720x1280)；用户说「横屏/横版」→ 1280x720\n"
        f"  duration 默认8秒；只支持 4/8/12，用户说其他值取最近值\n"
        f"  完成后口语化说「视频生成好了👉 [点击查看](URL)」，不要只甩链接\n"
        f"  生成中别让用户等着干等：先回「正在生成，稍等一下～」再调工具\n\n"
        f"· query_order(user_id, order_id)  —  订单查询\n"
        f"  🚨 铁律：每次用户问订单，必须实时调用此工具，绝对不允许凭对话记忆直接回答——订单状态实时变化，记忆结果可能已过期\n"
        f"  🎯 触发词：「我的订单/查一下我的/我买了啥/下单了吗/收到没/到货了吗/查单」\n"
        f"  ✅ 用户查本人订单：**直接调用 query_order，user_id 传空或当前工号均可，server 自动识别**\n"
        f"  {'✅ **严禁**询问用户工号——系统已知身份，直接查，不要问' if user_id else '✅ 工号未知：若要查本人订单/物流且无单号，先问一次工号（见上方⚠️规则），不要直接调工具'}\n"
        f"  ✅ 有 order_id 时一并传；用户只说「我的订单」不提编号 → 只传 user_id 查全部\n"
        f"  ⚠️ 权限：普通用户只能查本人订单；有订单查询权限的管理员可查任意工号\n"
        f"  {'✅ 您有跨员工订单查询权限；规则：① 当前这条消息里有对方的工号数字 → 直接调 query_order；② 当前这条消息里只有姓名没有工号 → 必须回复「请提供对方的工号」，等对方回复后再调工具，⚠️ 严禁从历史记录中提取工号（历史里的工号可能张冠李戴）' if user_id in _ORDER_QUERY_ALLOWED else '用户要查别人的订单 → 直接告知「订单查询仅限本人，如需查他人订单请联系丁洋老师（215734）」，不要调工具'}\n"
        f"  回复要口语化：「您的订单 XX 已发货，快递单号 YY」，不要念原始 JSON\n"
        f"  查不到：「商城那边还没查到这个订单，可能还在处理中，或者让丁洋老师帮看一下～」\n\n"
        f"· query_logistics(express_no, order_id)  —  快递/物流查询\n"
        f"  🎯 触发词：「快递到哪了/物流/发货了吗/快到了吗/运单/查快递/快递单号」\n"
        f"  ✅ 用户给单号（含字母前缀 SF/YT/ZTO/JT 等）→ 判为 express_no 直接查\n"
        f"  ✅ 纯数字 → 判为 order_id\n"
        f"  ✅ 多个单号 → 一次全传，不要分次调用\n"
        f"  ✅ 用户没给单号（「查我的快递」）→ 先调 query_order 拿运单号，再查物流\n"
        f"  回复口语化：「您的快递现在在 XX，预计 XX 到」，最新状态放在最前面\n"
        f"  查不到轨迹：「暂时查不到最新轨迹，可能刚揽件还没扫描，稍后再查～」\n\n"
        f"· query_sales(date_from, date_to)  —  销售额/订单量统计（含线上商城 + 线下收款明细）\n"
        f"  🎯 触发词：「销售额/成交额/流水/卖了多少钱/营业额/GMV/销量/多少订单/卖出多少件」\n"
        f"  📦 线下收款明细：query_sales 返回结果自动包含线下收款数据，按「活动事件」分类记录，类型包括：\n"
        f"    · 线下内购无头件（无头件售卖）\n"
        f"    · 线下学习机内购（学习机线下销售）\n"
        f"    · 未来市集内购活动\n"
        f"    · 废纸箱售卖\n"
        f"  用户问「线下销售/线下收款/无头件销售/学习机销售/线下情况」等 → 直接调用 query_sales，工具返回里会包含对应明细，按活动事件分行展示给用户\n"
        f"  🗓 日期推断（严格按以下规则，今天={today}）：\n"
        f"    「今天」→ {today}～{today}\n"
        f"    「昨天」→ {yesterday}～{yesterday}\n"
        f"    「本周/这周」→ {week_start}～{today}\n"
        f"    「上周」→ 上周一～上周日（自行推算）\n"
        f"    「本月/这个月」→ {month_start}～{today}\n"
        f"    「上个月」→ 上月1日～上月末（自行推算）\n"
        f"    用户说「最近X天」→ 今天往前推X天\n"
        f"    用户没说日期 → 默认本月（{month_start}～{today}）\n"
        f"  回复时把数字说得有意义：「本月销售额 XX 万元，共 YY 笔订单」，不要只列数字\n\n"
        f"· query_product_ranking(date_from, date_to, sort_by, top_n)  —  销售排行榜\n"
        f"  🎯 触发词：「排行榜/哪个卖得最好/最畅销/销量前X名/销售额最高的/爆品」\n"
        f"  sort_by=qty 销量排行，sort_by=amount 销售额排行；用户没说 → 默认 qty\n"
        f"  top_n 用户说「前5/前十/前20」→ 传对应数字；没说 → 传0（全量）\n"
        f"  🗓 日期推断规则同 query_sales\n"
        f"  回复带点点评：「本月销量冠军是 XX，共卖出 YY 件，遥遥领先～」\n\n"
        f"· query_product_analysis(date_from, date_to, analysis_type, keyword, top_n)  —  经营分析\n"
        f"  🎯 触发词：「周转率/滞销/成本/毛利/库存情况/经营分析/哪些商品卖不动/综合分析」\n"
        f"  analysis_type 映射：\n"
        f"    周转率/周转天数 → turnover\n"
        f"    滞销/卖不动/积压 → slow_moving\n"
        f"    成本/毛利/利润 → cost\n"
        f"    库存/存货 → inventory\n"
        f"    销售情况 → sales\n"
        f"    综合/整体/全面分析 → comprehensive（默认）\n"
        f"  🗓 日期推断规则同 query_sales\n"
        f"  keyword 用户指定品类/商品名时传入，没说就不传\n"
        f"  回复要有分析视角，不只是念数字：「目前库存周转最慢的是 XX，建议关注一下」\n\n"
        f"· request_delegate_confirm(bot, ...)  —  发起自动化任务委派请求（需丁洋老师确认）\n"
        f"· execute_pending_delegate()  —  执行待确认委派（有委派权限的工号在私聊中操作）\n"
        f"· cancel_pending_delegate()  —  取消待确认委派\n\n"
        f"· manage_permission(action, target, types)  —  权限管理\n"
        f"  🎯 触发词：「权限列表/谁有权限/查询员工权限/员工权限/授权/取消授权/去掉某权限/移除某权限」\n"
        f"  action=list：查看所有员工及其权限，任何人可用\n"
        f"  action=grant：新增指定权限，target=工号，types=[\"数据\"/\"订单\"/\"委派\"/\"全部\"]\n"
        f"  action=remove：移除指定权限类型（保留其余权限），target=工号，types=[要移除的类型]\n"
        f"  action=revoke：取消该员工全部权限，target=工号\n"
        f"  ⚠️ 🚨 区分 grant/remove/revoke：「加权限/授权」→ grant；「去掉/移除某权限」→ remove；「取消全部权限」→ revoke。绝对禁止用 grant 来「保留某权限」——grant 只加不减\n"
        f"  {'✅ 您是超级管理员，直接执行；只有姓名没工号时先问工号再调工具' if user_id == _SUPERADMIN else '⚠️ list 任何人可用；其余仅超级管理员（215734）可执行'}\n\n"
        f"· query_job_status()  —  AI 任务进度查询\n"
        f"  🎯 触发词：「好了吗/完成了吗/进度怎样/生成了吗/出来了吗/还在跑吗/图出来没/视频好了吗」\n"
        f"  无需任何参数，直接调用，返回当前所有后台生图/视频任务状态\n\n"
        f"【几条不能绕过的约束】\n"
        f"① 每轮对话中凡涉及商品价格/库存/是否有货，必须在本轮重新调用 search_products——\n"
        f"   不得引用对话历史中的搜索结果（历史结果可能是旧数据或当时登录失败导致的误报）\n"
        f"② 售后问题（损坏/退货/退款/换货/投诉/破损/缺件等）回复里必须同时含：\n"
        f"   路径：流程中心 → 搜索【内购商城售后申请】\n"
        f"   链接：https://oa.zhiyinlou.com/v20/formRender?wfId=1475\n"
        f"⑨ 学习机购买（用户问「怎么买学习机」「学习机怎么申请」「想买学习机」「学习机内购」等）：\n"
        f"   学习机不在内购商城，购买流程：① 先提交审批，路径：流程中心 → 内购商城学习机样机内购申请，链接：https://oa.zhiyinlou.com/mob/approval?wfId=1490 ② 审批通过后联系丁洋老师（知音楼工号：215734）安排线下自提\n"
        f"   回复里必须同时包含审批链接和联系丁洋老师两步说明\n"
        f"③ 补货/缺货/什么时候有货/有货吗 → 处理流程（必须严格执行）：\n"
        f"   Step1：先调用 search_products 查当前商城库存状态\n"
        f"   Step2：根据结果判断（严格按顺序）：\n"
        f"     a. 搜到商品且有库存（包括微瑕版）→ 展示全部商品，标注是否微瑕，不说缺货，不调 notify_admin，不提补货\n"
        f"     b. 用户明确说要「正品」或「什么时候补货」且只有微瑕版 → 展示微瑕版 + 说明正品暂缺 + 附补货表 + 必须先调用 notify_admin 工具，再生成回复文本\n"
        f"     c. 完全搜不到该商品 / 库存为0 → 告知未上架/缺货 + 附补货表 + 必须先调用 notify_admin 工具，再生成回复文本\n"
        f"   ⚠️ 铁律（b/c情况）：必须在输出任何回复文字之前完成 notify_admin 工具调用。回复文本里不要写「@丁洋」，系统会自动发送。\n"
        f"   补货表链接（仅 b/c 情况附上）：https://yach-doc-shimo.zhiyinlou.com/sheets/8Nk6MWvrBdTVo4qL/MODOC/\n"
        f"⑦ 快递公司/发货方式问题（顺丰/圆通/中通/韵达/快递怎么发等）→ 口语化告知：商城快递由系统随机分配，无法指定，不要加工号，自然结束就好\n"
        f"⑧ 仅在以下情况才调用 notify_admin 工具，其余问题自行回答，不要随便@：\n"
        f"   · 商品确认缺货/未上架（用户要买但买不了）\n"
        f"   · 售后问题需要人工介入（退货/退款/损坏/换货等流程引导后用户仍需人工跟进）\n"
        f"   · 用户明确说「要找人工」「让丁洋老师处理」等\n"
        f"   ⚠️ 以下情况不要调 notify_admin：能查到商品且有库存、普通咨询能回答的问题、产品使用说明类问题\n"
        f"   ℹ️ 调用 notify_admin 后，系统会自动在你回复之后发送 @丁洋 老师的通知，你的回复文本里不需要再写「@丁洋」。\n"
        f"④ 真的不知道的问题，口语化说「这个我暂时没法解答，可以联系一下丁洋老师」，不编造\n"
        f"⑤ 多个问题同时问时，一轮内并行调用多个工具，拿到全部数据后再统一回复，不要分步让用户等待\n"
        f"⑥ 查询结果必须逐条完整展示：工具返回几条就列出几条，不截断、不省略、不分类汇总、不用「另外还有X款」代替——\n"
        f"   每一款都要单独编号列出名称+内购价（+图片）\n"
        f"【委派任务意图识别】\n"
        f"用户明确要「启动/执行/让助手跑」某任务才触发委派，普通咨询（什么时候补货/有没有上新）不触发：\n"
        f"  补货 → bot=replenishment | 上新 → bot=new_product | 上架/九凤上架 → bot=upload\n"
        f"  选品 → bot=selection | WMS审核+QC/QR单号 → bot=wms_audit（缺单号先要求补充）\n"
        f"  消息含「待上架明细」+知音楼表格URL → bot=selection_upload，sheet_url=URL\n"
        f"委派成功后直接输出工具返回的文案，不要自己加操作指引。\n\n"
        f"【委派确认/取消权限】（严格执行）\n"
        f"{'群聊模式：确认/取消委派必须在私聊中操作，这里收到此类指令直接告知去私聊。' if is_group else ('工号' + user_id + ('，有确认权限：收到确认词立即调用 execute_pending_delegate；收到「取消」立即调用 cancel_pending_delegate。' if user_id in _DELEGATE_ALLOWED else '，无确认权限：收到确认/取消委派请求，直接告知需要丁洋老师（215734）操作。'))}\n\n"
        f"🏪 内购商城入口：https://t.tal.com/e3KJoD（手机端知音楼→工作台→教师应用→好未来内购商城）\n"
        f"{sales_block}"
        f"{stock_block}"
        f"\n【上下文代词解析（必须严格执行）】\n"
        f"用户用「他」「那个」「这个」「它」「该商品」等代词时，必须从对话历史中找到最近一次明确提到的商品名称，"
        f"直接用该名称调用工具，禁止重新询问「是哪个商品」。\n"
        f"例：历史中刚查过「学而思小猴点读笔」，用户说「那他的销量是多少」→ 直接查「学而思小猴点读笔」的销量，不问商品名。\n\n"
        f"\n【图片识别能力（被动触发，非工具调用）】\n"
        f"【⚠️ 触发条件】：仅当用户的消息中已经包含图片附件（系统已收到图片文件）时，才进入识别流程；\n"
        f"如果消息是纯文字「请发/提供/给我/生成 X 的图片」，这是生图请求，应调 generate_image，绝不能说「请您发一下图片」。\n"
        f"触发后：系统自动识别图片内容，无需用户再说明；识别后结合对话历史决定查商品还是先问需求。\n"
        f"介绍能力时必须包含：「发一张商品图片，我来帮您识别并查询内购价格/库存」；同时必须提到产品使用说明查询能力（如点读笔激活/兼容书目/适用年龄/课程内容等）。\n\n"
        f"【⚠️ 内购商城二维码规则】\n"
        f"系统会在每条提及商城的回复末尾自动追加二维码图片，**你不需要也不能自己嵌入二维码图片**。\n"
        f"用户说「发二维码/嵌入/显示二维码」→ 正常回复文字（如「好的，商城二维码在下方👇」），在回复中包含 🏪 内购商城入口 行，系统自动附上图片。\n"
        f"绝对禁止在回复中出现 ![内购商城二维码](...) 这样的 markdown 图片标签。\n\n"
        f"\n【商城入口展示规则（强制）】\n"
        f"每次回复中只要涉及引导用户访问内购商城，必须用以下固定格式（不可省略 🏪，系统会在这行后自动注入二维码）：\n"
        f"  🏪 内购商城入口：https://t.tal.com/e3KJoD\n"
        f"禁止把链接拆散、内嵌到其他句子中，必须单独成行。\n\n"
        f"\n【介绍能力/功能时，必须逐项介绍以下所有能力（用 Markdown 分项列出，每项带简短说明），并附上实用链接】\n"
        f"1. 🛍 商品查询：价格、库存、规格，发图片也能识别查询\n"
        f"2. 📖 产品使用说明 & 资料：收录 100+ 款产品文档，可回答激活步骤、兼容书目、适用年龄、课程内容等（如「点读笔怎么激活」「ABCtime 适合几岁」）\n"
        f"3. 📋 订单查询：提供工号或订单号即可查\n"
        f"4. 🚚 物流查询：快递单号或订单号\n"
        f"5. 🔧 售后服务：引导退换货、售后申请\n"
        f"6. 💡 补货/选品建议：提交缺货反馈\n"
        f"7. 📊 经营数据分析（需权限）：销售额、库存周转、滞销分析等\n"
        f"8. 🎨 AI 生图 / 🎬 AI 视频：文字生成图片或视频\n"
        f"- 内购商城：https://t.tal.com/e3KJoD\n"
        f"- 售后申请：流程中心 → 搜索【内购商城售后申请】→ https://oa.zhiyinlou.com/v20/formRender?wfId=1475\n"
        f"- 学习机购买：① 流程中心 → 内购商城学习机样机内购申请 → https://oa.zhiyinlou.com/mob/approval?wfId=1490 ② 审批后联系丁洋老师（215734）线下自提\n"
        f"- 补货/选品建议：https://yach-doc-shimo.zhiyinlou.com/sheets/8Nk6MWvrBdTVo4qL/MODOC/\n"
        f"- 联系管理员：内购管理员丁洋老师（知音楼工号：215734）\n"
        f"\n\n【最高优先级】所有回复必须用中文，不得输出英文推理过程或内部分析，只给用户看最终回答。"
    )

    # ── 最高优先级拦截：广告审批回复（优先于委派快速拦截，防止「补货广告拒绝」被误认为补货关键词）──
    import re as _promo_re_early
    _PROMO_KW_EARLY = ("新品广告通过", "新品广告拒绝", "补货广告通过", "补货广告拒绝",
                       "广告通过", "广告拒绝")
    _has_rid_early = _promo_re_early.search(r'审批ID[：:]\s*rec\w+', query)
    if _has_rid_early or any(kw in query for kw in _PROMO_KW_EARLY):
        try:
            import sys as _sys_early
            _promo_dir_early = r'D:\windows powershells'
            if _promo_dir_early not in _sys_early.path:
                _sys_early.path.insert(0, _promo_dir_early)
            from promo_approval import parse_reply_and_act as _parse_reply_and_act_early
            _promo_result_early = _parse_reply_and_act_early(query)
            _log_ops(f"⚡ 广告审批拦截(最高优先级): {query[:60]} → {_promo_result_early}")
            _log_chat(query, "agent_precheck_promo", _promo_result_early)
            return _promo_result_early, 200, _CT
        except Exception as _e_early:
            _log_ops(f"  ⚠ 广告审批处理异常(最高优先级): {_e_early}")

    # ── 快速拦截：有待确认委派时，「取消」/「确认XXX」直接处理，不走 GLM ──
    if _valid_delegates and not is_group and user_id in _DELEGATE_ALLOWED:
        _q = query.strip()
        _CANCEL_WORDS = {"取消", "取消执行", "不执行", "不用了", "算了"}

        # 构建专属确认词 → token 映射
        _kw_map: dict = {}  # confirm_keyword → (token, pending)
        for _tok, _pd in _valid_delegates.items():
            _ck = (_DELEGATE_REGISTRY.get(_pd["bot"]) or {}).get("confirm_keyword", "")
            if _ck:
                _kw_map[_ck] = (_tok, _pd)

        # 判断是否命中某个专属确认词
        _matched_tok, _matched_pd = _kw_map.get(_q, (None, None))

        # 兼容旧词"确认执行"/"确认"/"执行"（仅当只有 1 个待确认任务时）
        if _matched_tok is None and _q in {"确认执行", "确认", "执行"} and len(_valid_delegates) == 1:
            _matched_tok, _matched_pd = next(iter(_valid_delegates.items()))
            _matched_pd = _matched_pd  # noqa

        if _matched_tok is not None:
            _bot    = _matched_pd["bot"]
            _params = _matched_pd.get("params", {})
            try:
                _result_msg = _delegate_teable_write(_bot, _params)
            except Exception as _e:
                _result_msg = f"委派失败：{_e}"
            del _pending_delegations[_matched_tok]
            _save_delegates()
            _log_ops(f"  ✅ 快速拦截确认: token={_matched_tok} bot={_bot}")
            # 若还有其他待确认任务，提示剩余
            _remaining = {t: v for t, v in _pending_delegations.items()
                         if _t_now.time() - v["ts"] < _DELEGATE_EXPIRE}
            if _remaining:
                _rem_hints = "、".join(
                    f"回复「{(_DELEGATE_REGISTRY.get(v['bot']) or {}).get('confirm_keyword', v['bot'])}」确认{(_BOT_NAMES.get(v['bot'], v['bot']))}"
                    for v in _remaining.values()
                )
                _result_msg += f"\n\n还有 {len(_remaining)} 个待确认任务：{_rem_hints}"
            return _result_msg

        if _q in _CANCEL_WORDS:
            count = len(_valid_delegates)
            for t in list(_valid_delegates):
                _pending_delegations.pop(t, None)
            _save_delegates()
            _log_ops(f"  ❌ 快速拦截：委派已取消 (共 {count} 条)")
            return "已取消所有待确认的委派任务，不会执行任何自动化操作。"

    # 加载该用户的历史对话（上下文记忆）
    _hkey = hist_uid or user_id
    history = _get_history(_hkey) if _hkey else []

    # 图片处理：先 vision-only 调用描述图片，再把描述注入 agent 上下文
    # （TAL API 不支持 tools + multimodal 同时使用，拆成两步）
    _hist_query = query   # 默认：历史记录存原始文字
    if image_content:
        img_desc = _describe_image(image_content, query)
        if img_desc:
            # 区分有真实需求 vs 仅发图没说需求（Dify 占位符 "用户发送了一个图片"）
            _real_q = query if (query and query != "用户发送了一个图片") else ""
            ctx = f"【用户发送了图片，图片内容如下】\n{img_desc}"
            if _real_q:
                # 有真实问题：带上问题，让 agent 按需求处理
                ctx += f"\n\n用户的问题：{_real_q}"
                # 历史存「用户文字+识别摘要」，让下轮 LLM 知道识别了什么商品
                _hist_query = f"{_real_q}（图片识别：{img_desc[:300]}）"
            else:
                # 仅发图无需求：结合对话历史处理——有历史需求则直接回答，否则告知识别结果并询问
                ctx += (
                    "\n\n【提示】请结合对话历史：若历史中用户已有明确需求（如查价格/库存/是否有货），"
                    "请直接按需求调用工具回答；若历史中无明确需求，"
                    "请先用1~2句话告知识别到的图片内容，再询问用户需要什么帮助，"
                    "不要主动调用工具搜索。"
                )
                # 历史存识别摘要，确保下轮 LLM 知道识别了哪个商品
                _hist_query = f"（已发送图片，识别内容：{img_desc[:300]}）"
            user_msg_content = ctx
        else:
            # 描述失败：直接返回引导语，不继续 agent 流程
            fallback = (
                "您好！我已经收到您发送的图片了，不过目前图片识别功能还在优化中，"
                "暂时无法自动识别图片内容。\n\n"
                "请直接告诉我商品名称或关键词，我来帮您在内购商城查询～\n"
                "例如：ABC Time上册有没有？"
            )
            if query:
                # 如果同时有文字，尝试按文字处理
                user_msg_content = query
            else:
                if _hkey:
                    _save_history(_hkey, list(history) +
                                  [{"role": "user", "content": "（用户发送了图片）"},
                                   {"role": "assistant", "content": fallback}])
                return fallback
    else:
        user_msg_content = query

    messages = [{"role": "system", "content": system}] + history + [
        {"role": "user", "content": user_msg_content},
    ]

    _kb_search_results_all: list = []  # KB模式收集所有 search_products 成功结果，用于后处理补全

    for round_num in range(5):
        try:
            resp = _glm_post_with_retry(messages, _AGENT_TOOLS, backend or _BACKENDS[0])
            if resp.status_code >= 400:
                _log_ops(f"  ✗ [{backend['model']}] HTTP {resp.status_code}: {resp.text[:300]}")
            resp.raise_for_status()
            choice  = resp.json()["choices"][0]
            message = choice["message"]
            finish  = choice.get("finish_reason", "")

            if finish == "tool_calls" or message.get("tool_calls"):
                # 规范化 arguments：确保历史里每条 tool_use.input 始终是合法 dict，
                # 防止空串/null/非对象 JSON 在下轮重放时引发 Claude 400 ValidationException
                for _tc in (message.get("tool_calls") or []):
                    _raw_args = _tc.get("function", {}).get("arguments", "") or ""
                    try:
                        _parsed = json.loads(_raw_args) if _raw_args else {}
                        if not isinstance(_parsed, dict):
                            _parsed = {}
                    except Exception:
                        _parsed = {}
                    _tc["function"]["arguments"] = json.dumps(_parsed, ensure_ascii=False)
                messages.append(message)
                _all_tcs = message.get("tool_calls") or []
                for tc in _all_tcs:
                    fn_name = tc["function"]["name"]
                    fn_args = json.loads(tc["function"]["arguments"])
                    if not isinstance(fn_args, dict):
                        fn_args = {}
                    args_short = "  ".join(f"{k}={v}" for k, v in fn_args.items())
                    _log_ops(f"  → [R{round_num}] 调用工具 {fn_name}({args_short})")
                    tool_result = _execute_tool(fn_name, fn_args, user_id=user_id, is_group=is_group, group_id=group_id, notify_ctx=_notify_ctx, query=query, raw_uid=hist_uid, hkey=_hkey)
                    result_short = tool_result.replace('\n', ' ').strip()[:120]
                    _log_ops(f"  ← [R{round_num}] 工具返回: {result_short}")
                    print(f"[agent] round={round_num} tool={fn_name} args={fn_args} → {tool_result[:100]}")
                    # 多次 search_products 时收集结果，供后处理检测 LLM 是否有遗漏商品
                    if fn_name == "search_products" and tool_result.startswith("【内购商品查询结果】") and len(_all_tcs) >= 2:
                        _kb_search_results_all.append((fn_args.get("keyword", ""), tool_result))
                    messages.append({
                        "role":         "tool",
                        "tool_call_id": tc["id"],
                        "content":      tool_result,
                    })
                continue

            # 最终回复（过滤 extended thinking 推理文本）
            reply = _strip_thinking_text(message.get("content") or "")
            if not reply:
                reply = _STATIC_REPLY["unknown"]
            # 自动补全 LLM 遗漏的商品（搜到了但回复里没展示）：
            # KB 命中场景或兼容性兜底场景（≥2 次 search_products）均启用
            if _kb_search_results_all and len(_kb_search_results_all) >= 2:
                _missing_blocks = []
                _reply_stripped = re.sub(r'[【】\s]', '', reply)   # 与 _pname_key 同等处理，确保括号/空格不影响匹配
                for _kw, _tr in _kb_search_results_all:
                    # 提取工具结果中的第一个商品名，检查是否出现在 reply 中
                    _plines = [l.strip() for l in _tr.split('\n') if re.match(r'^\d+\.', l.strip())]
                    if not _plines:
                        continue
                    _pname = re.sub(r'^\d+\.\s*', '', _plines[0]).split('  ')[0].strip()
                    # 取前8个字符做模糊匹配，避免格式差异导致误判
                    _pname_key = re.sub(r'[【】\s]', '', _pname)[:8]
                    if _pname_key and _pname_key not in _reply_stripped:
                        # 剥离首行（纯标识行）只展示商品数据
                        _tr_display = _tr.split('\n', 1)[1].lstrip('\n') if '\n' in _tr else _tr
                        _missing_blocks.append(_tr_display)
                if _missing_blocks:
                    # 找 reply 中最后一个编号（兼容 "N." 和 "### N." 两种格式）
                    _last_nums = re.findall(r'(?m)^(?:#{1,6}\s+)?(\d+)\.', reply)
                    _next_num = int(_last_nums[-1]) + 1 if _last_nums else 1
                    _renumbered = []
                    for _blk in _missing_blocks:
                        # 剥离引导文字（"「X」的话有N款..."）：只保留从第一个 N. 开始的行
                        _blk_start = re.search(r'(?m)^\d+\.', _blk)
                        if _blk_start:
                            _blk = _blk[_blk_start.start():]
                        # 剥离底部「🏪 内购商城入口」行及其后内容
                        _blk = re.sub(r'\n\n🏪\s*内购商城入口.*$', '', _blk, flags=re.DOTALL).rstrip()
                        # 知音楼对缩进的 Markdown 图片/链接不渲染——去掉每行的前置缩进
                        _blk = re.sub(r'(?m)^[ \t]+', '', _blk)
                        # 图片行紧贴上一行（链接行）会被解析器视作链接续行，强制图片行前留空行成为独立段落
                        _blk = re.sub(r'(?m)\n(!\[商品图片\])', r'\n\n\1', _blk)
                        # 编号商品行前也留空行，确保每款独立成段
                        _blk = re.sub(r'(?m)\n(\d+\.)', r'\n\n\1', _blk)
                        # 折叠多余的连续空行（>2 个换行 → 2 个）
                        _blk = re.sub(r'\n{3,}', '\n\n', _blk).strip()
                        _blk = _fix_md_links(_blk)
                        _blk_item_nums = sorted(set(int(m) for m in re.findall(r'(?m)^(\d+)\.', _blk)))
                        if not _blk_item_nums:
                            _renumbered.append(_blk)
                            continue
                        _min_n, _base = _blk_item_nums[0], _next_num
                        _blk_fixed = re.sub(r'(?m)^(\d+)\.', lambda m: str(_base + int(m.group(1)) - _min_n) + '.', _blk)
                        _next_num = _base + _blk_item_nums[-1] - _min_n + 1
                        _renumbered.append(_blk_fixed)
                    reply += '\n\n' + '\n\n'.join(_renumbered)
                    _log_ops(f"  📦 KB自动补全：追加 {len(_missing_blocks)} 个遗漏商品区块（序号接续，已去缩进）")
                # 二维码注入由后续无条件注入块统一处理（末尾追加）
            # 修复 LLM 在 Markdown 链接/图片 URL 括号内换行导致链接失效
            reply = _fix_md_links(reply)
            # 补注 LLM 遗漏的商品图片标签（有 [商品直达] 但下一行缺 ![商品图片]）
            if _kb_search_results_all:
                _img_map: dict = {}
                for _, _tr in _kb_search_results_all:
                    for _im in re.finditer(r'\[商品直达\]\(([^)]+)\)\n!\[商品图片\]\(([^)]+)\)', _tr):
                        _img_map[_im.group(1)] = _im.group(2)
                if _img_map:
                    _reply_lines = reply.split('\n')
                    _new_lines: list = []
                    for _li, _rl in enumerate(_reply_lines):
                        _new_lines.append(_rl)
                        _url_m = re.search(r'\[商品直达\]\(([^)]+)\)', _rl)
                        if _url_m:
                            _prod_url = _url_m.group(1)
                            # 向后看5行窗口，避免图片行前有空行时误判为缺失
                            _window = '\n'.join(_reply_lines[_li:min(_li + 5, len(_reply_lines))])
                            if '![商品图片]' not in _window and _prod_url in _img_map:
                                _new_lines.append(f'![商品图片]({_img_map[_prod_url]})')
                                _log_ops(f"  🖼️ 补注商品图片: ...{_prod_url[-25:]}")
                    reply = '\n'.join(_new_lines)
            # 知音楼不渲染列表/缩进内的 Markdown 图片——去掉图片行前置空白，并确保图片行前有空行
            reply = re.sub(r'(?m)^[ \t]+(!\[)', r'\1', reply)
            reply = re.sub(r'(?m)\n(!\[)', r'\n\n\1', reply)
            reply = re.sub(r'\n{3,}', '\n\n', reply).strip()
            # ── 商城二维码：先剥掉 LLM 自嵌的（位置不可控），再统一追加末尾 ──
            _QR_IMG_CONST = '![内购商城二维码](https://yach-static.zhiyinlou.com/online/person/1779503218959/79343BF9AFA2A679883BA3482474BE93/86852FE6-309F-429E-B758-3C7FCC0D2CC3.PNG)'
            _has_mall_ref = any(ak in reply for ak in ('🏪', 't.tal.com/e3KJoD', '内购商城入口'))
            if _QR_IMG_CONST in reply:
                reply = re.sub(r'\n*👆[^\n]*\n' + re.escape(_QR_IMG_CONST), '', reply)
                reply = reply.replace(_QR_IMG_CONST, '')
                reply = re.sub(r'\n{3,}', '\n\n', reply).rstrip()
                _log_ops(f"  🏪 剥离 LLM 自嵌 QR")
            if _has_mall_ref:
                reply = reply.rstrip() + '\n\n👆 用手机知音楼扫码进入内购商城 📱\n' + _QR_IMG_CONST
                _log_ops(f"  🏪 商城二维码追加至末尾")
            # 保存对话历史（只存文本，不存工具调用/结果）
            # 用 _hist_query 而非 query：图片轮次保存识别摘要，确保下轮 LLM 知道识别了哪个商品
            if _hkey:
                new_hist = list(history)
                new_hist.append({"role": "user", "content": _hist_query})
                new_hist.append({"role": "assistant", "content": reply})
                _save_history(_hkey, new_hist)
            # 兜底：LLM 漏调 notify_admin 工具的两类情况
            # （非 sonnet 模型如 kimi/glm/deepseek/qwen 偶发会写文字但不调工具）
            if not _notify_ctx.get("reason"):
                _fallback_reason = None
                # 情况 1：回复里出现"丁洋"+承诺动词 → 必然是承诺通知
                # 用 regex 兼容各种措辞：已/正在/将/会 + 通知/同步/告知/联系/转告/转交/反馈/告诉/转给/提交 + 丁洋
                _PROMISE_RE = re.compile(
                    r'(已|帮您|帮你|正在|稍后|将|会|马上|即刻|立即)?\s*'
                    r'(通知|同步|告知|联系|转告|转交|反馈|告诉|转给|提交给?|发送给?|交给|反映给?)'
                    r'[^。\n]*?丁洋'
                )
                _ASSIST_RE = re.compile(r'丁洋[^。\n]*?(老师)?[^。\n]*?(跟进|处理|确认|反馈|安排|协助|帮您|帮你|看一下)')
                if _PROMISE_RE.search(reply) or _ASSIST_RE.search(reply):
                    _fallback_reason = f"工号{user_id or '?'}询问「{(query or '')[:50]}」（LLM 文字承诺通知丁洋但未调 notify_admin 工具，server 兜底）"
                # 情况 2：用户问题明显是售后/缺货类，但 LLM 整轮都没调 notify_admin（连承诺都没写）
                elif query:
                    _NEEDS_HUMAN_KW = (
                        '售后', '退货', '退款', '换货', '投诉', '损坏', '坏了', '破损',
                        '缺件', '没收到', '丢了', '丢失', '质量问题', '维权',
                    )
                    if any(kw in query for kw in _NEEDS_HUMAN_KW):
                        _fallback_reason = f"工号{user_id or '?'}询问「{(query or '')[:50]}」（疑似缺货/售后问题但 LLM 未调 notify_admin，server 兜底）"
                # 情况 3：多轮对话达到阈值仍未触发 notify_admin → 强制升级人工
                if not _fallback_reason and dialog_count >= 4:
                    _fallback_reason = f"工号{user_id or '?'}已进行第{dialog_count}轮对话仍未解决，询问「{(query or '')[:50]}」（多轮自动升级）"
                if _fallback_reason:
                    _notify_ctx["reason"] = _fallback_reason
                    _notify_ctx["group_id"] = group_id
                    _notify_ctx["user_id"] = user_id
                    _log_ops(f"  ⚙️ notify_admin 兜底触发: {_fallback_reason[:80]}")
            # 若本轮触发了 notify_admin：正常回复给 Dify（第一条），后台等 Dify 送达后再发 @丁洋（第二条）
            if _notify_ctx.get("reason"):
                nc_group_id = _notify_ctx.get("group_id") or group_id
                nc_user_id  = _notify_ctx.get("user_id")  or user_id
                def _delayed_at(_reason=_notify_ctx["reason"], _gid=nc_group_id, _uid=nc_user_id,
                                _evt=notify_event, _huid=hist_uid, _src_group=is_group,
                                _is_webhook=is_webhook, _orig_query=query,
                                _group_name=group_name, _dialog_count=dialog_count,
                                _wrid=workflow_run_id):
                    try:
                        import time as _t
                        start_ts = _t.time()
                        _log_ops(f"  🔔 @丁洋线程启动 gid={repr(_gid)} uid={_uid} is_group={_src_group}")
                        # 构建咨询人信息：工号 → 姓名（admin备注 > 知音楼API查询 > 仅工号）
                        _eff_uid = _uid or _uuid_staff_map.get(_huid, "")
                        # 尝试从 Dify UUID 反查知音楼工号（知音楼短 UUID 格式）
                        if not _eff_uid and _huid and "-" not in _huid:
                            _eff_uid = _yach_workcode_for_uuid(_huid)
                        _sender_name = (_STAFF_NAMES.get(_eff_uid, "")
                                        or (_yach_lookup_user_name(_eff_uid) if _eff_uid else ""))
                        if _sender_name:
                            _sender_info = f"{_sender_name}老师（工号：{_eff_uid}）"
                        elif _eff_uid:
                            _sender_info = f"工号：{_eff_uid}"
                        elif _huid:
                            _send_dt = datetime.fromtimestamp(start_ts).strftime("%m-%d %H:%M")
                            _sender_info = f"未绑定用户（发送时间：{_send_dt}，Dify ID: {_huid[:12]}…）"
                        else:
                            _sender_info = "未知用户"
                        # 路由：在群里发消息 → 群消息API能找到该消息 → 群@；真私聊 → 找不到 → P2P
                        _log_ops(f"  🔔 开始群ID解析 gid={repr(_gid)} uid={_uid} src_group={_src_group}")
                        # is_group 可信来源：① Webhook（始终可信）② 新版 Dify 工作流（有 workflow_run_id）
                        # 两者 is_group=False → 确认私聊，跳过扫群，消除边缘误判
                        _trusted_src = _is_webhook or bool(_wrid)
                        if _trusted_src and not _src_group:
                            real_gid = ""
                        else:
                            real_gid = _gid if (_gid and "-" not in _gid) else _resolve_yach_group(_gid, _uid, _orig_query, user_uuid=_huid or "")
                        # 已解析到群：通过内容匹配补全发件人姓名和工号（已绑定工号但群未识别身份的情况）
                        if real_gid and not _eff_uid and _huid:
                            _found_name, _found_wc = _fetch_group_sender(real_gid, _orig_query)
                            if _found_name or _found_wc:
                                _send_dt_l = datetime.fromtimestamp(start_ts).strftime("%m-%d %H:%M")
                                if _found_name and _found_wc:
                                    _sender_info = f"{_found_name}老师（工号：{_found_wc}）"
                                elif _found_name:
                                    _sender_info = f"{_found_name}（未绑定工号，发送时间：{_send_dt_l}）"
                                else:
                                    _sender_info = f"工号：{_found_wc}（发送时间：{_send_dt_l}）"
                        _log_ops(f"  🔔 群ID解析结果: {repr(real_gid)}，咨询人: {_sender_info}")
                        if not real_gid:
                            # 私聊 Dify 触发（无群上下文）→ P2P 通知丁洋
                            if _evt:
                                _evt.wait(timeout=10)
                            # P2P 必须带：姓名+工号+完整原始问题
                            _orig_q_full = (_orig_query or "").strip()
                            _src_tag = f"来源群：{_group_name}\n" if _group_name else ""
                            _dlg_tag = f"对话轮数：第{_dialog_count}轮\n" if _dialog_count >= 2 else ""
                            _p2p_msg = (
                                f"📌 内购商城问题反馈\n\n"
                                f"咨询人：{_sender_info}\n"
                                f"{_src_tag}"
                                f"{_dlg_tag}"
                                f"原始问题：{_orig_q_full}"
                            )
                            _yach_send_p2p("215734", _p2p_msg)
                            _log_ops(f"  🔔 @丁洋: P2P通知（{_sender_info}）")
                            return
                        # 等 worker finally 把 req.event 设置（= Flask 收到回复，即将发给 Dify）
                        if _evt:
                            _evt.wait(timeout=15)
                            _log_ops(f"  🔔 回复已交给 Flask，立即发@丁洋")
                        _grp_tag = f"【{_group_name}】" if _group_name else ""
                        _dlg_tag2 = f"（第{_dialog_count}轮）" if _dialog_count >= 2 else ""
                        _at_text = f"{_grp_tag}有用户咨询{_dlg_tag2}：{(_orig_query or '')[:100]}\n麻烦看一下～"
                        _yach_send_group_at(_reason, group_id=real_gid, user_id=_uid,
                                            full_text=_at_text)
                    except Exception as _e:
                        _log_ops(f"  ✗ @丁洋线程异常: {_e}")
                threading.Thread(target=_delayed_at, daemon=True).start()
            return reply

        except _LLMRateLimit:
            raise   # 透传给 worker，由 worker 切换下一个 backend
        except Exception as e:
            import traceback as _tb
            _log_ops(f"  ✗ [R{round_num}] GLM异常: {e}\n{_tb.format_exc()}")
            print(f"[glm_agent] round={round_num} error: {e}\n{_tb.format_exc()}")
            break

    # GLM 调用失败兜底：关键词匹配 + 工具查询，确保用户得到回复
    _log_ops("  ✗ GLM 不可用，降级关键词兜底")
    intent   = _keyword_intent(query)
    entities = _extract_entities_regex(query)
    result   = _execute_query(intent, entities, query, user_id=user_id)
    if result:
        if intent == "sales_query" and not result.startswith("抱歉"):
            fb = f"查到了～\n\n{result}"
        elif intent == "product_query" and result.startswith("【内购商品查询结果】"):
            lines = result.split("\n")
            fb = "\n".join(lines[1:]).strip()
        else:
            fb = result
    else:
        fb = _STATIC_REPLY.get(intent, _STATIC_REPLY["unknown"])
    raise _LLMFallback(fb)


# ─── HTTP 路由 ────────────────────────────────────────────────────

@app.route('/video/<filename>', methods=['GET'])
def serve_video(filename):
    from flask import send_from_directory, abort
    import re as _re
    if not _re.match(r'^[\w\-\.]+\.(mp4|png|jpg|jpeg|webp)$', filename):
        abort(404)
    _mime = {'mp4': 'video/mp4', 'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'webp': 'image/webp'}
    _ext = filename.rsplit('.', 1)[-1].lower()
    resp = send_from_directory(_VIDEO_DIR, filename, mimetype=_mime.get(_ext, 'application/octet-stream'))
    resp.headers["ngrok-skip-browser-warning"] = "true"
    return resp


@app.route('/api/task/submit', methods=['POST'])
def submit_task():
    data = request.get_json(silent=True) or {}
    task_name = data.get("task", "")
    task_id   = uuid.uuid4().hex[:8]

    base = {
        "task": task_name,
        "status": "pending",
        "created_at": datetime.now().isoformat(),
        "logs": [],
    }

    if task_name == "board_generate":
        days = int(data.get("days", 90))
        with _lock:
            _tasks[task_id] = base
        threading.Thread(target=run_board_pipeline, args=(task_id, days), daemon=True).start()
        return jsonify({
            "status": "accepted",
            "task_id": task_id,
            "message": "看板生成任务已接受，后台执行中，完成后推送知音楼通知"
        }), 202

    if task_name in ("cs_product", "cs_order", "cs_logistics", "cs_aftersale", "cs_suggestion"):
        query       = data.get("query", "")
        receiver_id = data.get("receiver_id", "")
        if not query:
            return jsonify({"status": "error", "message": "缺少 query 字段"}), 400
        with _lock:
            _tasks[task_id] = {**base, "query": query}
        threading.Thread(target=run_cs_task, args=(task_id, task_name, query, receiver_id), daemon=True).start()
        return jsonify({
            "status": "accepted",
            "task_id": task_id,
            "message": f"{task_name} 任务已接受，处理完成后推送结果"
        }), 202

    return jsonify({"status": "unknown_task", "task": task_name,
                    "supported": ["board_generate", "cs_product", "cs_order",
                                  "cs_logistics", "cs_aftersale", "cs_suggestion"]}), 400


@app.route('/api/sync/now', methods=['POST'])
def sync_now():
    """定时自动化专用：直接触发全量订单同步，无需关键词匹配。"""
    global _sales_refresh_running
    if _sales_refresh_running:
        return jsonify({"status": "already_running"}), 200
    def _do():
        global _sales_refresh_running
        _sales_refresh_running = True
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location("update_sales", S["sales_refresh"])
            mod  = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.main()
            print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [sync/now] 全量同步完成 ✓")
        except Exception as e:
            print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [sync/now] 同步失败: {e}")
        finally:
            _sales_refresh_running = False
    threading.Thread(target=_do, daemon=False).start()
    return jsonify({"status": "accepted"}), 202


@app.route('/api/agent/chat', methods=['POST'])
def agent_chat():
    """Agent 模式：GLM tool_use 全自动处理，知音楼/Dify 调用此接口获得智能回复。
    传 {"query": "用户消息", "user_id": "工号"} 即可，user_id 用于权限控制。
    图片识别：额外传 image_url（外部URL）或 image_base64（base64字符串）。
    """
    data      = request.get_json(silent=True) or {}
    query     = data.get("query", "").strip()
    raw_uid   = str(data.get("user_id", "") or "").strip()
    # work_code：Dify v6 新增字段，知音楼会话信息收集若直传工号则此处非空，优先使用
    _dify_wc  = str(data.get("work_code", "") or "").strip()
    # 首次见面标记：在写入缓存前判断，用于后续注入欢迎语
    _is_first_time = bool(raw_uid and raw_uid not in _uuid_staff_map and _dify_wc
                          and re.match(r'^[A-Za-z0-9]{4,12}$', _dify_wc))
    if _dify_wc and re.match(r'^[A-Za-z0-9]{4,12}$', _dify_wc):
        user_id = _dify_wc
        if raw_uid and _dify_wc != raw_uid:
            _uuid_staff_map[raw_uid] = _dify_wc
            _save_uuid_map()
    else:
        user_id = _resolve_user_id(raw_uid, query)
    user_name = str(data.get("user_name", "") or "").strip()
    is_group        = bool(data.get("is_group", False))
    group_id        = str(data.get("group_id", "") or "").strip()
    group_name      = str(data.get("group_name", "") or "").strip()
    dialog_count    = int(data.get("dialog_count", 0) or 0)
    app_id          = str(data.get("app_id", "") or "").strip()
    workflow_run_id = str(data.get("workflow_run_id", "") or "").strip()
    _src = "[v6直传]" if _dify_wc and user_id == _dify_wc else "[兜底链]" if user_id else "[未知]"
    _wrid_tag = f" wrid={workflow_run_id[:8]}" if workflow_run_id else ""
    _app_tag  = f" app={app_id[:8]}" if app_id else ""
    _log_ops(f"📥 agent_chat {_src}: raw_uid={raw_uid!r} → user_id={user_id!r} user_name={user_name!r} is_group={is_group} dialog={dialog_count}{_wrid_tag}{_app_tag}")
    _CT = {"Content-Type": "text/plain; charset=utf-8"}

    # ── 过滤知音楼把机器人自己发的消息当成用户 query 传入的情况 ──────────────
    # 当用户引用机器人推送的图片/视频消息时，知音楼 v6 会把被引用消息的 content 作为 query 传入。
    # 特征：query 以机器人推送头部开头（🎨/🎬），且不含用户真实意图文字。
    _BOT_MSG_PREFIXES = ("🎨 图片生成好了", "🎬 视频生成好了", "图片生成好了", "视频生成好了")
    _query_is_bot_msg = any(query.startswith(p) for p in _BOT_MSG_PREFIXES)
    if _query_is_bot_msg:
        # 从 query 中提取图片 URL（如果有），作为 image_url 传给后续逻辑；query 置空让 Dify 层重新构造
        _bot_img_match = re.search(r'!\[.*?\]\((https?://[^\)]+)\)', query)
        if _bot_img_match:
            # 把图片 URL 注入 data，后续 image_content 处理会取到它
            data["image_url"] = _bot_img_match.group(1).strip()
        query = ""
        _log_ops(f"  ⚠ query 为机器人自发消息（引用场景），已清空 query，图片URL={data.get('image_url','无')}")

    # ── 竞争消除：webhook 与 Dify 同时触发时，webhook 会同步写 _yach_user_name_cache ────
    # 若姓名尚不在任何缓存中，创建 Event 等待 webhook 写入后主动唤醒，无轮询无固定间隔
    if raw_uid and not user_id and user_name:
        _in_cache = (any(n == user_name for n in _yach_user_name_cache.values()) or
                     any(n == user_name for n in _STAFF_NAMES.values()))
        if not _in_cache:
            with _webhook_name_events_lock:
                _wevt = _webhook_name_events.setdefault(user_name, threading.Event())
            _wevt.wait(timeout=10)   # 阻塞直到 webhook 写入缓存，10s 为安全兜底
            with _webhook_name_events_lock:
                _webhook_name_events.pop(user_name, None)

    # ── 姓名自动绑定：UUID 未映射时，用 Dify 传来的 user_name 反查已知姓名表 ──
    if raw_uid and not user_id and user_name:
        _name_idx: dict = {}
        for _s, _n in {**_yach_user_name_cache, **_STAFF_NAMES}.items():
            if _n and re.match(r'^[A-Za-z0-9]{4,12}$', _s):
                _name_idx.setdefault(_n, []).append(_s)
        _hit = list(set(_name_idx.get(user_name, [])))
        if len(_hit) == 1:
            _sno = _hit[0]
            _uuid_staff_map[raw_uid] = _sno
            _save_uuid_map()
            user_id = _sno
            _yach_user_name_cache[_sno] = user_name
            _save_yach_name_cache()
            threading.Thread(target=_sync_perms_to_teable, daemon=True).start()
            _log_ops(f"🔗 姓名自动绑定: {raw_uid[:12]}… → {_sno}（{user_name}）")

    # 注意：sniff_sender_workcode 仅用于 notify_admin 定位来源群，不再用于工号绑定
    # 内容匹配会误把同内容消息的发送者工号绑定到其他用户身上（已发现 bug，已禁用）

    # ── 工号自报绑定：所有自动识别均失败后，检查消息本身是否是工号 ──────────────
    if raw_uid and not user_id and query:
        _self_wc = _parse_self_reported_workcode(query)
        if _self_wc:
            _uuid_staff_map[raw_uid] = _self_wc
            _save_uuid_map()
            user_id = _self_wc
            if user_name:
                _yach_user_name_cache[_self_wc] = user_name
                _save_yach_name_cache()
            _log_ops(f"🔗 工号自报绑定: {raw_uid[:12]}… → {_self_wc}（{user_name}）")
            # 消息仅是工号本身（无其他内容），直接回确认，不走 LLM
            if re.match(r'^[A-Za-z]?\d{5,8}$', query.strip()):
                _workcode_only_msg = True
                return (
                    f"好的，已记录您的工号 {_self_wc}～以后发消息我就认识您了，不用再填啦 😊\n\n"
                    f"请问有什么可以帮您？"
                ), 200, _CT

    # Dify 传来的用户名写入缓存（绑定后更新；仅在名称有变化时落盘，避免每次请求都写磁盘）
    if user_name:
        if user_id:
            if _yach_user_name_cache.get(user_id) != user_name:
                _yach_user_name_cache[user_id] = user_name
                threading.Thread(target=_save_yach_name_cache, daemon=True).start()

    # ── 图片内容处理（image_url 优先，files_json 次之，image_base64 最后）──────
    image_content = None
    img_url_raw   = (data.get("image_url") or "").strip()

    # files_json：Dify 传整个 sys.files 数组序列化后的字符串，解析提取第一张图片 URL
    files_json_raw = (data.get("files_json") or "").strip()
    if files_json_raw and not img_url_raw:
        try:
            import json as _json
            files_list = _json.loads(files_json_raw) if isinstance(files_json_raw, str) else files_json_raw
            if isinstance(files_list, list) and files_list:
                first = files_list[0]
                img_url_raw = (first.get("url") or first.get("remote_url") or "") if isinstance(first, dict) else ""
                if img_url_raw:
                    _log_ops(f"  📷 从 files_json 提取 URL: {img_url_raw[:80]}")
        except Exception as _e:
            _log_ops(f"  ⚠ files_json 解析失败: {_e}")
    # 过滤所有未解析的 Dify 模板字面量（{{#...#}} 或 {{...}}），否则大模型会胡编
    if (img_url_raw.startswith("{{") and img_url_raw.endswith("}}")
            or not img_url_raw.startswith(("http://", "https://", "data:"))):
        if img_url_raw:
            _log_ops(f"  ⚠ image_url 非合法 URL，已丢弃: {img_url_raw[:60]}")
        img_url_raw = ""
    img_b64_raw   = (data.get("image_base64") or "").strip()
    if img_url_raw or img_b64_raw:
        if img_url_raw:
            _log_ops(f"  📷 下载图片: {img_url_raw[:80]}")
            img_src = _fetch_image_b64(img_url_raw)
            if not img_src:
                # 下载失败，不再把无效 URL 传给大模型（会导致胡编）
                _log_ops(f"  ⚠ 图片下载失败，跳过图片识别")
                img_url_raw = ""
                img_src = None
            else:
                _log_ops(f"  ✓ 图片下载成功，转 base64")
        else:
            img_src = f"data:image/jpeg;base64,{img_b64_raw}"
        if img_src:
            image_content = [
                {"type": "text",      "text": query or "请描述这张图片的内容"},
                {"type": "image_url", "image_url": {"url": img_src}},
            ]

    # ── 预处理短路：广告审批 → 只要消息含 [审批ID: rec 就拦截，不要求关键词精确 ──
    import re as _promo_re
    _PROMO_KW = ("新品广告通过", "新品广告拒绝", "补货广告通过", "补货广告拒绝",
                 "广告通过", "广告拒绝")
    _has_rid = _promo_re.search(r'审批ID[：:]\s*rec\w+', query)
    if _has_rid or any(kw in query for kw in _PROMO_KW):
        try:
            import sys as _sys
            if r'D:\windows powershells' not in _sys.path:
                _sys.path.insert(0, r'D:\windows powershells')
            from promo_approval import parse_reply_and_act
            _promo_result = parse_reply_and_act(query)
            _log_ops(f"⚡ 广告审批拦截: {query[:60]} → {_promo_result}")
            _log_chat(query, "agent_precheck_promo", _promo_result)
            return _promo_result, 200, _CT
        except Exception as _e:
            _log_ops(f"  ⚠ 广告审批处理异常: {_e}")

    # ── 预处理短路：待上架明细 + shimo URL → 跳过 LLM 直接委派 ─────────
    # 背景：消息带图片附件时 LLM 可能直接输出文本而不调用工具（hallucination）
    # 修复：此处用正则匹配，命中后直接执行委派逻辑，100% 可靠，不走 LLM
    import re as _pre_re, time as _pt, random as _pr, string as _ps
    _SHIMO_URL_RE = _pre_re.compile(r'https://yach-doc-shimo\.zhiyinlou\.com/sheets/[^\s\]>\"\']+')
    if '待上架明细' in query:
        _shimo_m = _SHIMO_URL_RE.search(query)
        if _shimo_m:
            _sheet_url = _shimo_m.group(0).rstrip('/.,;:')
            _log_ops(f"⚡ 预处理短路: 待上架明细+shimo URL → selection_upload  user={user_id}  url={_sheet_url}")
            _conf = _DELEGATE_REGISTRY["selection_upload"]
            _note = f"导入待上架明细：{_sheet_url}"
            _token = "CONF-" + "".join(_pr.choices(_ps.ascii_uppercase + _ps.digits, k=5))
            _pending_delegations[_token] = {
                "bot": "selection_upload", "note": _note,
                "ts": _pt.time(), "requester": user_id,
                "params": {"qc_no": "", "qr_no": "", "warehouse": "",
                           "requester": user_id, "sheet_url": _sheet_url},
            }
            _save_delegates()
            _log_ops(f"  📋 委派请求(预处理): token={_token} bot=selection_upload requester={user_id}")
            _notice = (
                f"📋 委派确认请求\n\n"
                f"智能客服收到任务委派申请\n"
                f"任务：{_conf['bot_name']}\n"
                f"发起人：工号 {user_id or '未知'}\n"
                f"内容：{_note}\n"
                f"表格：{_sheet_url}\n\n"
                f"✅ 同意请回复：确认执行\n"
                f"❌ 拒绝请回复：取消\n\n"
                f"（令牌：{_token}，30 分钟内有效）"
            )
            _sent = _yach_send_p2p("215734", _notice)
            if _sent:
                _result = f"已向丁洋老师申请确认，批准后将自动通知{_conf['bot_name']}导入《待上架明细》数据。"
            else:
                del _pending_delegations[_token]
                _save_delegates()
                _result = "抱歉，通知丁洋老师时发生网络错误，请稍后重试。"
            _log_chat(query, "agent_precheck_selection_upload", _result)
            _log_ops(f"✓ 预处理短路完成")
            return _result, 200, _CT

    # ── 串行排队：等上一个请求完整处理完再开始下一个 ─────────────────
    global _glm_active
    with _glm_act_lock:
        _glm_active += 1
        depth = _glm_active

    t0     = datetime.now()
    display_uid = f"{user_id}(uuid={raw_uid[:8]}…)" if user_id and user_id != raw_uid else (user_id or raw_uid or "?")
    queue_hint = f"  [排队第{depth}位，预计等待{(depth-1)*20}s]" if depth > 1 else ""
    _log_ops(f"▶ 收到请求  user={display_uid}{queue_hint}  Q: {query[:60]}")
    # hist_uid：用工号优先，UUID 兜底，确保未绑定用户也有上下文记忆
    hist_uid = user_id or raw_uid

    kb_context = str(data.get("context", "") or "").strip()
    # 过滤 Dify 返回的无意义占位符（长度 < 20 则视为空，如单个 "{"）
    if len(kb_context) < 20:
        if kb_context:
            _log_ops(f"  📚 知识库上下文无效（长度={len(kb_context)}），已忽略：{kb_context!r}")
        else:
            _log_ops(f"  📚 Dify KB 为空，尝试 Teable 产品文档知识库...")
        kb_context = ""
        # Dify 未返回 context → 回退到 Teable 产品文档知识库
        teable_ctx = _search_doc_kb(query)
        if teable_ctx:
            kb_context = teable_ctx
            _log_ops(f"  📚 Teable KB 命中，长度={len(kb_context)}，预览：{kb_context[:80]}")
        else:
            _log_ops(f"  📚 Teable KB 未命中")
    else:
        _log_ops(f"  📚 Dify KB 上下文已收到，长度={len(kb_context)}，预览：{kb_context[:100]}")
    req = _GlmReq(query, user_id, image_content, hist_uid, is_group, group_id, context=kb_context, user_name=user_name,
                  group_name=group_name, dialog_count=dialog_count, app_id=app_id, workflow_run_id=workflow_run_id)
    _glm_queue.put(req)
    try:
        req.event.wait()                   # 等 worker 完成（无超时）
        result = req.result if req.result is not None else _STATIC_REPLY["unknown"]
    finally:
        with _glm_act_lock:
            _glm_active -= 1
    elapsed = (datetime.now() - t0).total_seconds()
    # 等待超过 20 秒时，在回复前加一句自然的致歉语（空串=robot静默场景跳过）
    if elapsed > 20 and result and not result.startswith("抱歉"):
        import random
        apologies = [
            "抱歉等了一下，来了～\n\n",
            "不好意思稍微慢了点，这就给你：\n\n",
            "让你久等了，查到了：\n\n",
        ]
        result = random.choice(apologies) + result
    # 首次见面欢迎语：仅 Dify v6 直传工号且该 UUID 之前从未见过时触发
    if _is_first_time and user_name and result and result != "__SILENT__":
        result = f"你好，{user_name}老师！😊\n\n" + result
    if result == "__SILENT__":
        _log_ops(f"✓ 完成 {elapsed:.1f}s [SILENT-204]")
        return "", 204, _CT
    _log_chat(query, "agent", result)
    _log_ops(f"✓ 完成 {elapsed:.1f}s  📏 回复{len(result)}字符/{len(result.encode('utf-8'))}字节")
    print(f"[agent_chat] user={user_id or '?'} '{query[:40]}' → {elapsed:.1f}s")
    _uid_for_p2p    = str(user_id) if user_id and re.match(r'^\d{5,10}$', str(user_id)) else None
    _has_product_img = _PRODUCT_IMG_TAG in result

    # ── 超长消息续发：含商品图片按数量分批（≤8款/批），分节格式降级为字符分割 ──
    if _has_product_img:
        _parts = _split_products_by_count(result)
        if len(_parts) == 1 and len(result) > _REPLY_MAX_LEN:   # 分节格式降级
            _parts = _split_reply(result, _REPLY_MAX_LEN)
    else:
        _parts = _split_reply(result, _REPLY_MAX_LEN)
    if len(_parts) > 1:
        result = _parts[0]
        _cont = _parts[1:]
        _total = len(_parts)
        _uid_for_p2p = str(user_id) if user_id and re.match(r'^\d{5,10}$', str(user_id)) else None

        def _p2p_clean(t):
            return re.sub(r'!\[[^\]]*\]\([^)]+\)', '', t).strip()

        def _send_cont_parts(wc: str, parts_list: list, has_img: bool, total: int):
            time.sleep(4)
            for _i, _p in enumerate(parts_list):
                if has_img:
                    _title = f"商品列表（{_i + 2}/{total}）"
                    _yach_send_p2p_markdown(wc, _title, _p)
                else:
                    _yach_send_p2p(wc, _p2p_clean(_p))
                if _i < len(parts_list) - 1:
                    time.sleep(1)

        _mode = "商品分批" if _has_product_img else "超长"
        if _uid_for_p2p:
            _uid_snap = _uid_for_p2p
            _cont_snap = list(_cont)
            _img_snap = _has_product_img
            threading.Thread(
                target=lambda: _send_cont_parts(_uid_snap, _cont_snap, _img_snap, _total),
                daemon=True,
            ).start()
            _log_ops(f"  ✂ {_mode}拆成 {_total} 批，后 {len(_cont)} 批 P2P {'markdown含图' if _has_product_img else 'text'} → {_uid_for_p2p}")
        else:
            _query_snap = query
            _cont_snap = list(_cont)
            _parts_count = _total
            _img_snap = _has_product_img
            def _send_cont_auto():
                time.sleep(4)
                try:
                    _src_group, _auto_wc = _sniff_sender_workcode(_query_snap)
                    if _auto_wc:
                        _log_ops(f"  🔍 自动识别工号: {_auto_wc} (群{_src_group}) → P2P续发{len(_cont_snap)}批")
                        _send_cont_parts(_auto_wc, _cont_snap, _img_snap, _parts_count)
                        return
                except Exception as _ex_auto:
                    _log_ops(f"  ⚠️ 自动嗅探发送者失败: {_ex_auto}")
                _log_ops(f"  ✂ 自动嗅探无结果，仅 Dify 发第1批（共{_parts_count}批）")
            threading.Thread(target=_send_cont_auto, daemon=True).start()
            _log_ops(f"  ✂ {_mode}拆成 {_total} 批，后 {len(_cont)} 批 → 自动嗅探工号续发")
    return result, 200, _CT


# ─── 知音楼 Outgoing Webhook（直接接收群消息，彻底绕开 Dify）──────────────
# 在知音楼开放平台后台将机器人「消息接收地址」配置为：
#   https://confining-enjoyer-haiku.ngrok-free.dev/webhook/yach

_webhook_seen_ids: set = set()
_webhook_seen_lock = threading.Lock()


@app.route('/webhook/yach', methods=['POST'])
def webhook_yach():
    """接收知音楼机器人 Outgoing Webhook，用机器人 API 直接发回复，实现单条消息 + 蓝色 @丁洋。"""
    data = request.get_json(silent=True) or {}

    # ── 消息去重（知音楼超时会重试）──────────────────────────────────────
    msg_id = str(data.get("msgId") or data.get("msg_id") or "")
    if msg_id:
        with _webhook_seen_lock:
            if msg_id in _webhook_seen_ids:
                return jsonify({"msgtype": "empty"})
            _webhook_seen_ids.add(msg_id)
            if len(_webhook_seen_ids) > 2000:
                _webhook_seen_ids.clear()

    # ── 解析字段 ─────────────────────────────────────────────────────────
    msgtype         = str(data.get("msgtype") or data.get("msg_type") or "text").lower()
    sender_staff_id = str(
        data.get("senderStaffId") or data.get("sender_staff_id") or
        (data.get("sender") or {}).get("work_code") or ""
    ).strip()
    sender_name = str(
        data.get("senderNick") or data.get("sender_nick") or
        data.get("senderName") or data.get("sender_name") or
        (data.get("sender") or {}).get("name") or ""
    ).strip()
    # 姓名兜底：从内存缓存取，或异步调 Yach API 查
    if sender_staff_id and not sender_name:
        sender_name = _yach_user_name_cache.get(sender_staff_id, "")
    # 更新姓名缓存（工号→姓名，持久化，后续免查 Yach API）
    if sender_staff_id:
        _yach_user_name_cache[sender_staff_id] = sender_name
        # 通知正在等待该姓名的 agent_chat 请求（消除 webhook/Dify 竞争条件）
        if sender_name:
            with _webhook_name_events_lock:
                evt = _webhook_name_events.get(sender_name)
            if evt:
                evt.set()
    conversation_id = str(data.get("conversationId") or data.get("conversation_id") or "").strip()
    conv_type       = str(data.get("conversationType") or data.get("conversation_type") or "1")
    is_group        = (conv_type == "2")

    # 消息文本（群聊时知音楼会在开头加 "@机器人名 "，需要剥离）
    text_obj = data.get("text") or data.get("content") or {}
    raw_text = (text_obj.get("content") if isinstance(text_obj, dict) else str(text_obj or "")).strip()
    query    = re.sub(r'^@\S+\s*', '', raw_text).strip()

    # 图片 URL
    img_url = ""
    if msgtype in ("picture", "image", "file"):
        pic = data.get("picture") or data.get("image") or data.get("content") or {}
        if isinstance(pic, dict):
            img_url = (pic.get("photoURL") or pic.get("photo_url") or
                       pic.get("downloadUrl") or pic.get("download_url") or "").strip()

    # 引用消息（msgtype=6）里提取图片 URL：解析 quoteMsg 里的 markdown ![图片](url)
    if not img_url:
        quote_raw = data.get("quoteMsg") or data.get("quote_msg") or ""
        if quote_raw:
            try:
                quote_obj = json.loads(quote_raw) if isinstance(quote_raw, str) else quote_raw
                quote_content = ""
                if isinstance(quote_obj, dict):
                    quote_content = str(quote_obj.get("content") or "")
                m = re.search(r'!\[.*?\]\((https?://[^\)]+)\)', quote_content)
                if m:
                    img_url = m.group(1).strip()
                    _log_ops(f"  📷 [webhook] 从引用消息提取图片: {img_url[:80]}")
            except Exception as _qe:
                _log_ops(f"  ⚠ quoteMsg 解析失败: {_qe}")

    if not query and not img_url:
        _log_ops(f"⚠ [webhook] 消息为空 msgtype={msgtype} raw={raw_text[:40]}")
        return jsonify({"msgtype": "empty"})

    _log_ops(f"▶ [webhook] {'群' if is_group else 'P2P'} user={sender_staff_id or '?'} "
             f"conv={conversation_id[:12] if conversation_id else '?'} Q={query[:50]}")

    # ── 图片内容准备 ──────────────────────────────────────────────────────
    image_content = None
    if img_url:
        _log_ops(f"  📷 [webhook] 下载图片: {img_url[:80]}")
        img_src = _fetch_image_b64(img_url)
        if img_src:
            image_content = [
                {"type": "text",      "text": query or "请描述这张图片的内容"},
                {"type": "image_url", "image_url": {"url": img_src}},
            ]

    hist_uid = sender_staff_id or conversation_id

    # ── 图文双向问询：有图意图但无图，先问用户发图 ─────────────────────────
    if image_content is None and _is_image_intent(query):
        ask_img = "好的，请您发一下图片，我来帮您识别～"
        _hist_early = _get_history(hist_uid) if hist_uid else []
        _save_history(hist_uid, list(_hist_early) + [
            {"role": "user",      "content": query},
            {"role": "assistant", "content": ask_img},
        ])
        send_fn = _yach_send_group_msg if is_group else _yach_send_p2p
        send_args = (conversation_id, ask_img, sender_staff_id) if is_group else (sender_staff_id, ask_img)
        threading.Thread(target=send_fn, args=send_args, daemon=True).start()
        return jsonify({"msgtype": "empty"})

    # ── 入队处理，异步回复（知音楼 webhook 需立刻 ACK，LLM 最长 30s+）──────
    global _glm_active
    with _glm_act_lock:
        _glm_active += 1

    glm_req = _GlmReq(query, sender_staff_id, image_content, hist_uid, is_group, conversation_id, is_webhook=True)
    _glm_queue.put(glm_req)

    def _send_reply():
        global _glm_active
        try:
            glm_req.event.wait()
            result = glm_req.result if glm_req.result is not None else _STATIC_REPLY["unknown"]
            if result == "__SILENT__":
                # notify_admin 触发：_glm_agent_chat 已发含蓝色 @丁洋 的完整回复，无需再发
                _log_ops(f"✓ [webhook] SILENT — @丁洋 已通过机器人API发出")
                return
            _log_chat(query, "webhook_agent", result)
            _has_img_wb = _PRODUCT_IMG_TAG in result
            if _has_img_wb:
                _parts = _split_products_by_count(result)
                if len(_parts) == 1 and len(result) > _REPLY_MAX_LEN:
                    _parts = _split_reply(result, _REPLY_MAX_LEN)
            else:
                _parts = _split_reply(result, _REPLY_MAX_LEN)
            _log_ops(f"✓ [webhook] 回复 {len(result)}字{'→'+str(len(_parts))+'批' if len(_parts)>1 else ''} → {'群' if is_group else 'P2P'}")
            for _i, _p in enumerate(_parts):
                if is_group:
                    _yach_send_group_msg(conversation_id, _p, sender_staff_id)
                else:
                    if _has_img_wb:
                        _wb_title = f"商品列表（{_i + 1}/{len(_parts)}）" if len(_parts) > 1 else "商品列表"
                        _yach_send_p2p_markdown(sender_staff_id, _wb_title, _p)
                    else:
                        _yach_send_p2p(sender_staff_id, _p)
                if _i < len(_parts) - 1:
                    time.sleep(1.5)
        except Exception as e:
            _log_ops(f"✗ [webhook] 回复发送失败: {e}")
        finally:
            with _glm_act_lock:
                _glm_active -= 1

    threading.Thread(target=_send_reply, daemon=True).start()
    return jsonify({"msgtype": "empty"})


@app.route('/api/task/status/<task_id>', methods=['GET'])
def task_status(task_id):
    with _lock:
        info = _tasks.get(task_id)
    return jsonify(info) if info else (jsonify({"status": "not_found"}), 404)


@app.route('/api/tasks', methods=['GET'])
def list_tasks():
    with _lock:
        summary = {
            tid: {k: v for k, v in info.items() if k != "logs"}
            for tid, info in _tasks.items()
        }
    return jsonify(summary)


@app.route('/health', methods=['GET'])
def health():
    import time as _ht
    _urls = _get_access_urls()
    # 检测 worker 是否卡死：任一 worker 单请求超过阈值则报 503
    now = _ht.time()
    with _worker_lock:
        states = dict(_worker_states)
    stuck = {wid: round(now - t) for wid, t in states.items() if t and (now - t) > _WORKER_STUCK_SEC}
    if stuck:
        return jsonify({"status": "worker_stuck", "stuck_workers": stuck}), 503
    busy = sum(1 for t in states.values() if t)
    return jsonify({
        "status": "ok",
        "service": "ipo-skill-server",
        "queue_size": _glm_queue.qsize(),
        "workers": f"{busy}/{_GLM_WORKERS} busy",
        "internal_url": f"http://{_urls['local_ip']}:8765",
        "tunnel_url": _urls.get("tunnel_url", ""),
        "agent_endpoint": "POST /api/agent/chat  →  {\"query\": \"<用户消息>\"}",
        "supported_tasks": list({
            "board_generate", "cs_product", "cs_order",
            "cs_logistics", "cs_aftersale", "cs_suggestion"
        })
    })



# ─── 权限管理页面 ────────────────────────────────────────────────────────────

_ADMIN_PAGE_HTML = """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>权限管理</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif;
     background:#080b12;color:#cbd5e1;min-height:100vh;padding:40px 20px;
     max-width:700px;margin:0 auto}
.hdr{margin-bottom:32px}
.hdr h1{font-size:1.25rem;font-weight:700;color:#f1f5f9;letter-spacing:-.01em}
.hdr p{font-size:.8rem;color:#3f4e65;margin-top:5px}
.section{background:#0f1520;border:1px solid #1a2236;border-radius:14px;
         padding:22px 24px;margin-bottom:14px}
.sh{font-size:.9rem;font-weight:600;color:#e2e8f0;margin-bottom:3px}
.sd{font-size:.75rem;color:#3f4e65;margin-bottom:14px}
.tags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px;min-height:26px}
.tag{display:inline-flex;align-items:center;gap:4px;background:#141c2e;
     border:1px solid #1e2d47;border-radius:8px;padding:4px 10px}
.tag .no{font-size:.82rem;color:#94a3b8;font-weight:500}
.tag .nm{font-size:.74rem;color:#4a5a74}
.tag.super{border-color:#3730a3;background:#12163a}
.tag.super .no{color:#a5b4fc}
.tag.super .nm{color:#4f46e5;opacity:.9}
.tag.super .lk{font-size:.68rem;color:#3730a3;margin-left:1px}
.tag .rm{border:none;background:none;color:#2d3f58;cursor:pointer;
         font-size:.9rem;line-height:1;padding:0 0 0 3px;transition:color .15s}
.tag .rm:hover{color:#ef4444}
.add-row{display:flex;gap:8px}
.inp{background:#080b12;border:1px solid #1a2236;border-radius:8px;
     padding:7px 11px;color:#e2e8f0;font-size:.86rem;outline:none;
     transition:border-color .15s}
.inp:focus{border-color:#4f46e5}
.inp-no{flex:0 0 96px}
.inp-nm{flex:1}
.add-btn{background:#3730a3;color:#c7d2fe;border:none;border-radius:8px;
         padding:7px 15px;cursor:pointer;font-size:.86rem;white-space:nowrap;
         transition:background .15s}
.add-btn:hover{background:#4338ca}
.save-btn{width:100%;background:#0ea5e9;color:#fff;border:none;border-radius:10px;
          padding:12px;font-size:.92rem;font-weight:600;cursor:pointer;
          margin-bottom:20px;transition:background .15s}
.save-btn:hover{background:#0284c7}
.save-btn:disabled{background:#1e3a4a;color:#4a6070;cursor:default}
.act{background:#0f1520;border:1px solid #1a2236;border-radius:14px;
     padding:20px 24px;margin-bottom:28px}
.act-h{font-size:.85rem;font-weight:600;color:#64748b;
       display:flex;align-items:center;gap:7px;margin-bottom:14px}
.badge{font-size:.7rem;background:#141c2e;color:#4a5a74;
       border-radius:20px;padding:2px 7px}
.prow{display:flex;align-items:center;gap:10px;
      padding:9px 0;border-bottom:1px solid #141c2e}
.prow:last-child{border-bottom:none}
.pi{flex:1}
.pn{font-size:.86rem;color:#e2e8f0;font-weight:500}
.ph{font-size:.73rem;color:#3f4e65;margin-top:2px}
.rbtn{background:transparent;border:1px solid #1e2d47;color:#4a5a74;
      border-radius:6px;padding:4px 11px;cursor:pointer;font-size:.76rem;
      white-space:nowrap;transition:all .15s}
.rbtn:hover{border-color:#4f46e5;color:#a5b4fc}
.urow{display:grid;grid-template-columns:1fr 96px auto;gap:8px;
      align-items:center;padding:9px 0;border-bottom:1px solid #141c2e}
.urow:last-child{border-bottom:none}
.um{font-size:.82rem;color:#94a3b8}
.ut{font-size:.71rem;color:#2d3f58;margin-top:2px}
.binp{background:#080b12;border:1px solid #1a2236;border-radius:6px;
      padding:5px 8px;color:#e2e8f0;font-size:.8rem;outline:none;
      transition:border-color .15s;width:100%}
.binp:focus{border-color:#f59e0b}
.bbtn{background:#d97706;color:#000;border:none;border-radius:6px;
      padding:5px 12px;cursor:pointer;font-size:.76rem;font-weight:600;white-space:nowrap}
.bbtn:hover{background:#b45309}
.sep{border:none;border-top:1px solid #141c2e;margin:14px 0}
.empty{color:#2d3f58;font-size:.8rem;padding:4px 0}
.footer{text-align:center;padding-bottom:16px;font-size:.76rem}
.footer a{color:#2d3f58;text-decoration:none;cursor:pointer;margin:0 8px;
          transition:color .15s}
.footer a:hover{color:#64748b}
.toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);
       background:#16a34a;color:#fff;padding:9px 20px;border-radius:20px;
       font-size:.84rem;opacity:0;transition:.25s;pointer-events:none;
       white-space:nowrap;box-shadow:0 4px 20px rgba(0,0,0,.5)}
.toast.err{background:#dc2626}
.toast.show{opacity:1}
</style>
</head>
<body>
<div class="hdr">
  <h1>🔐 智能客服 · 权限管理</h1>
  <p>添加工号后，员工下次发消息时系统自动识别工号，权限即时生效，无需任何绑定操作。</p>
</div>

<div class="section">
  <div class="sh">📊 数据查询权限</div>
  <div class="sd">销售额 · 订单量 · 商品排行 · WMS库存</div>
  <div class="tags" id="data-tags"></div>
  <div class="add-row">
    <input class="inp inp-no" id="data-input" type="text" placeholder="工号" maxlength="12">
    <input class="inp inp-nm" id="data-name-input" type="text" placeholder="姓名（选填）" maxlength="10">
    <button class="add-btn" onclick="addUser('data')">+ 添加</button>
  </div>
</div>

<div class="section">
  <div class="sh">🤖 委派确认权限</div>
  <div class="sd">补货 · 上新 · 上架 · 选品 · WMS审核</div>
  <div class="tags" id="delegate-tags"></div>
  <div class="add-row">
    <input class="inp inp-no" id="delegate-input" type="text" placeholder="工号" maxlength="12">
    <input class="inp inp-nm" id="delegate-name-input" type="text" placeholder="姓名（选填）" maxlength="10">
    <button class="add-btn" onclick="addUser('delegate')">+ 添加</button>
  </div>
</div>

<div class="section">
  <div class="sh">📦 订单查询权限</div>
  <div class="sd">可查询任意工号的订单（普通用户只能查本人）</div>
  <div class="tags" id="order-tags"></div>
  <div class="add-row">
    <input class="inp inp-no" id="order-input" type="text" placeholder="工号" maxlength="12">
    <input class="inp inp-nm" id="order-name-input" type="text" placeholder="姓名（选填）" maxlength="10">
    <button class="add-btn" onclick="addUser('order')">+ 添加</button>
  </div>
</div>

<button class="save-btn" id="save-btn" onclick="save()">保存设置</button>

<div id="unres-wrap" style="display:none">
  <hr class="sep">
  <div class="act-h" style="margin-bottom:12px">⚠️ 需手动绑定 <span class="badge" id="unres-cnt">0</span></div>
  <div id="unresolved-list"></div>
</div>

<div class="toast" id="toast"></div>

<div class="footer">
  <a href="https://yach-teable.zhiyinlou.com/base/bseFFoyVD6WgFbKmzDN/tblvmF035LLP9Ra2LvG" target="_blank">Teable 权限表</a>
  ·
  <a onclick="syncFromTeable()">从 Teable 同步</a>
</div>

<script>
const SUPER = "215734";
const state = { data: [], delegate: [], order: [], names: {} };

function render(group) {
  const ul = document.getElementById(group + "-tags");
  ul.innerHTML = "";
  state[group].forEach(uid => {
    const name = state.names[uid] || "";
    const t = document.createElement("span");
    t.className = "tag" + (uid === SUPER ? " super" : "");
    if (uid === SUPER) {
      t.innerHTML = `<span class="no">${uid}</span>${name?`<span class="nm">${name}</span>`:""}<span class="lk">🔒</span>`;
    } else {
      t.innerHTML = `<span class="no">${uid}</span>${name?`<span class="nm">${name}</span>`:""}
        <button class="rm" onclick="removeUser('${group}','${uid}')" title="移除">×</button>`;
    }
    ul.appendChild(t);
  });
}

function addUser(group) {
  const inp = document.getElementById(group + "-input");
  const ni  = document.getElementById(group + "-name-input");
  const uid = inp.value.trim().replace(/\\D/g,"");
  if (!/^[A-Za-z0-9]{4,12}$/.test(uid)) { showToast("工号须为4~12位字母数字", true); return; }
  if (state[group].includes(uid)) { showToast("已存在", true); return; }
  state[group].push(uid);
  const name = (ni ? ni.value.trim() : "").substring(0,20);
  if (name) state.names[uid] = name;
  render(group);
  inp.value = ""; inp.focus();
  if (ni) ni.value = "";
}

function removeUser(group, uid) {
  if (uid === SUPER) return;
  const label = uid + (state.names[uid] ? " · " + state.names[uid] : "");
  if (!confirm("移除 " + label + " 的权限？")) return;
  state[group] = state[group].filter(u => u !== uid);
  render(group);
}

function save() {
  const btn = document.getElementById("save-btn");
  btn.disabled = true; btn.textContent = "保存中…";
  fetch("/admin/permissions/save", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({data_allowed:state.data, delegate_allowed:state.delegate, order_allowed:state.order, staff_names:state.names})
  }).then(r=>r.json()).then(d => {
    btn.disabled = false; btn.textContent = "保存设置";
    if (d.status !== "ok") { showToast("保存失败: "+(d.msg||""), true); return; }
    const added = d.added || [];
    showToast(added.length > 0
      ? "✓ 已保存，新增工号：" + added.join("、") + "（员工下次发消息自动激活）"
      : "✓ 已保存，权限立即生效");
    loadStatus();
  }).catch(() => { btn.disabled=false; btn.textContent="保存设置"; showToast("网络错误",true); });
}

function syncFromTeable() {
  showToast("同步中…");
  fetch("/admin/permissions/sync_from_teable",{method:"POST"})
    .then(r=>r.json()).then(d => {
      if (d.status==="ok") {
        state.data=d.data_allowed||[SUPER]; state.delegate=d.delegate_allowed||[SUPER]; state.order=d.order_allowed||[SUPER];
        state.names=d.staff_names||{};
        render("data"); render("delegate"); render("order");
        showToast("✓ 从 Teable 同步完成");
      } else showToast("同步失败",true);
    }).catch(()=>showToast("网络错误",true));
}

function renderStatus(ud, ad) {
  const unres    = ud.unresolved || {};
  const unreKeys = Object.keys(unres).sort((a,b)=>(unres[b].last_seen||"").localeCompare(unres[a].last_seen||""));

  const uw = document.getElementById("unres-wrap");
  uw.style.display = unreKeys.length > 0 ? "" : "none";
  document.getElementById("unres-cnt").textContent = unreKeys.length;
  const ul = document.getElementById("unresolved-list");
  ul.innerHTML = "";
  unreKeys.forEach(uuid => {
    const info = unres[uuid];
    const row = document.createElement("div");
    row.className = "urow"; row.id = "urow-"+uuid;
    const nameHint = info.user_name ? `<span class="unm"> · ${info.user_name}</span>` : "";
    row.innerHTML = `<div><div class="um">最近消息：${info.last_query||"—"}${nameHint}</div>
      <div class="ut">${info.last_seen||""}</div></div>
      <input class="binp" type="text" placeholder="工号" maxlength="12" id="inp-${uuid}">
      <button class="bbtn" onclick="bindUuid('${uuid}')">绑定</button>`;
    ul.appendChild(row);
  });
}

function bindUuid(uuid) {
  const inp = document.getElementById("inp-"+uuid);
  const sno = inp ? inp.value.trim().replace(/\\D/g,"") : "";
  if (!/^[A-Za-z0-9]{4,12}$/.test(sno)) { showToast("工号须为4~12位字母数字",true); return; }
  fetch("/admin/uuid_map/save",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({bindings:{[uuid]:sno}})})
    .then(r=>r.json()).then(d=>{
      if (d.status==="ok"){showToast("✓ 绑定成功："+sno); loadStatus();}
      else showToast("绑定失败",true);
    });
}

function loadStatus() {
  fetch("/admin/uuid_map/data").then(r=>r.json())
    .then(ud=>renderStatus(ud,{pending:[]})).catch(()=>{});
}

function showToast(msg, err) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = "toast"+(err?" err":"")+" show";
  setTimeout(()=>t.className="toast"+(err?" err":""), 3000);
}

fetch("/admin/permissions/data").then(r=>r.json()).then(d=>{
  state.data=d.data_allowed||[SUPER]; state.delegate=d.delegate_allowed||[SUPER]; state.order=d.order_allowed||[SUPER];
  state.names=d.staff_names||{};
  render("data"); render("delegate"); render("order");
});
loadStatus();
setInterval(loadStatus, 15000);
</script>
</body>
</html>"""


@app.route('/admin/permissions', methods=['GET'])
def admin_permissions_page():
    from flask import Response
    return Response(_ADMIN_PAGE_HTML, mimetype='text/html')


@app.route('/admin/permissions/data', methods=['GET'])
def admin_permissions_data():
    return jsonify({
        "data_allowed":     sorted(_SALES_ALLOWED),
        "delegate_allowed": sorted(_DELEGATE_ALLOWED),
        "order_allowed":    sorted(_ORDER_QUERY_ALLOWED),
        "staff_names":      _STAFF_NAMES,
    })


@app.route('/admin/permissions/save', methods=['POST'])
def admin_permissions_save():
    global _SALES_ALLOWED, _DELEGATE_ALLOWED, _ORDER_QUERY_ALLOWED, _STAFF_NAMES
    data = request.get_json(silent=True) or {}
    try:
        new_data  = set(str(u).strip() for u in data.get("data_allowed",     []) if re.match(r'^[A-Za-z0-9]{4,12}$', str(u).strip()))
        new_dele  = set(str(u).strip() for u in data.get("delegate_allowed", []) if re.match(r'^[A-Za-z0-9]{4,12}$', str(u).strip()))
        new_order = set(str(u).strip() for u in data.get("order_allowed",    []) if re.match(r'^[A-Za-z0-9]{4,12}$', str(u).strip()))
    except Exception as e:
        return jsonify({"status": "error", "msg": str(e)}), 400
    new_data.add(_SUPERADMIN)
    new_dele.add(_SUPERADMIN)
    new_order.add(_SUPERADMIN)

    # 更新姓名备注
    names_raw = data.get("staff_names", {})
    for sno, name in names_raw.items():
        sno = str(sno).strip()
        if re.match(r'^[A-Za-z0-9]{4,12}$', sno):
            _STAFF_NAMES[sno] = str(name).strip()[:20]
    # 清理已移除工号的姓名（保留超管）
    current_all = new_data | new_dele | new_order
    for sno in list(_STAFF_NAMES.keys()):
        if sno not in current_all:
            del _STAFF_NAMES[sno]

    # 找出新增的工号（之前不在任何权限组）
    old_all = _SALES_ALLOWED | _DELEGATE_ALLOWED | _ORDER_QUERY_ALLOWED
    new_all = new_data | new_dele | new_order
    added = new_all - old_all - {_SUPERADMIN}

    _SALES_ALLOWED       = new_data
    _DELEGATE_ALLOWED    = new_dele
    _ORDER_QUERY_ALLOWED = new_order
    _save_admin_perms()
    _log_ops(f"🔐 权限更新 data={sorted(_SALES_ALLOWED)} delegate={sorted(_DELEGATE_ALLOWED)} order={sorted(_ORDER_QUERY_ALLOWED)}")

    threading.Thread(target=_sync_perms_to_teable, args=(True,), daemon=True).start()
    return jsonify({"status": "ok", "added": sorted(added)})


@app.route('/admin/uuid_map/data', methods=['GET'])
def admin_uuid_map_data():
    """返回 UUID→工号绑定列表"""
    return jsonify({"bindings": _uuid_staff_map})


@app.route('/admin/uuid_map/save', methods=['POST'])
def admin_uuid_map_save():
    """保存/解绑 UUID → 工号"""
    data = request.get_json(silent=True) or {}
    bindings = data.get("bindings", {})
    removes  = data.get("remove", [])
    changed = 0
    for uid, sno in bindings.items():
        sno = str(sno).strip()
        if re.match(r'^[A-Za-z0-9]{4,12}$', sno):
            _uuid_staff_map[uid] = sno
            changed += 1
    for uid in removes:
        _uuid_staff_map.pop(str(uid), None)
        changed += 1
    _save_uuid_map()
    if changed:
        _log_ops(f"🔗 UUID绑定更新: 新增{len(bindings)} 解绑{len(removes)}")
        threading.Thread(target=_sync_perms_to_teable, daemon=True).start()
    return jsonify({"status": "ok"})



@app.route('/admin/permissions/sync_from_teable', methods=['POST'])
def admin_sync_from_teable():
    """从 Teable 拉取权限数据，覆盖本地"""
    ok = _load_perms_from_teable()
    if ok:
        return jsonify({"status": "ok",
                        "data_allowed":     sorted(_SALES_ALLOWED),
                        "delegate_allowed": sorted(_DELEGATE_ALLOWED),
                        "order_allowed":    sorted(_ORDER_QUERY_ALLOWED)})
    return jsonify({"status": "error", "msg": "Teable 同步失败，请查看日志"}), 500


@app.route('/api/agent/rewrite', methods=['POST'])
def agent_rewrite():
    """轻量级 query 改写：结合对话历史把短句扩写成带产品名的检索短语，供 Dify 知识检索前置节点调用。
    不走主对话队列，使用快速模型直接响应；任何异常均降级返回原始 query。"""
    data    = request.get_json(silent=True) or {}
    query   = data.get("query", "").strip()
    raw_uid = str(data.get("user_id", "") or "").strip()
    _CT     = {"Content-Type": "text/plain; charset=utf-8"}

    if not query:
        return query, 200, _CT

    # 已含产品关键词 → 直接返回，无需改写
    _PRODUCT_KW = [
        "哈佛外教", "迪士尼英语", "摩比", "RAZ", "ABCtime", "Reading A-Z", "Reading", "大师英文",
        "小猴点读笔", "10分钟七大能力", "阅读理解方法课", "KET",
        "小学知识大典", "点读笔",
    ]
    if any(kw in query for kw in _PRODUCT_KW):
        return query, 200, _CT

    # UUID → 工号，取最近对话历史
    uid  = _uuid_staff_map.get(raw_uid, raw_uid)
    hist = _get_history(uid) if uid else []
    recent = []
    for m in hist[-6:]:
        role    = m.get("role", "")
        content = m.get("content", "")
        if isinstance(content, str) and content.strip():
            recent.append(f"{role}: {content.strip()[:120]}")
    history_text = "\n".join(recent) if recent else "（无历史）"

    messages = [
        {"role": "system", "content": (
            "你是检索改写助手。把用户当前的简短问题结合最近对话历史改写成包含具体产品名的检索短语。\n"
            "规则：1.从历史中找出最近被讨论的产品名，前缀到问题前（如「小猴点读笔 怎么激活」）；"
            "2.历史中没有明确产品名则原样返回；3.只输出改写后的字符串，不加任何解释，长度不超过50字。"
        )},
        {"role": "user", "content": f"最近对话历史：\n{history_text}\n\n用户当前问题：{query}"},
    ]
    # 按后端列表顺序轮转，跳过优先模型（留给主对话），403/429/5xx 自动换下一个
    hdrs = {"Authorization": _GLM_AUTH, "Content-Type": "application/json"}
    for backend in _CHAT_BACKENDS:
        if backend["model"] == _PRIORITY_MODEL:
            continue
        try:
            payload = {"model": backend["model"], "messages": messages,
                       "temperature": 0, "max_tokens": 80}
            resp = _http.post(_GLM_URL, headers=hdrs, json=payload, timeout=15)
            if resp.status_code in (403, 429, 502, 503, 504):
                continue
            resp.raise_for_status()
            result = resp.json()["choices"][0]["message"]["content"].strip()
            if result:
                return result, 200, _CT
        except Exception:
            continue
    return query, 200, _CT


@app.route('/api/agent/intent', methods=['POST'])
def agent_intent():
    """意图分类：识别 query 是「文档/使用说明类」还是「其他（商品/订单/价格）类」。
    返回纯文本 "doc" 或 "other"，供 Dify if-else 节点路由。
    规则快判 → 模型兜底，任何异常均返回 "other"（兜底走原有逻辑）。"""
    data  = request.get_json(silent=True) or {}
    query = data.get("query", "").strip()
    _CT   = {"Content-Type": "text/plain; charset=utf-8"}

    if not query:
        return "other", 200, _CT

    # ── 规则快判：文档/使用说明类关键词 ──────────────────────────────
    _DOC_KW = [
        "使用说明", "使用文档", "操作说明", "说明书", "怎么用", "如何用",
        "怎么使用", "如何使用", "使用方法", "使用教程", "教程", "激活",
        "激活码", "怎么激活", "如何激活", "连接", "配对", "绑定", "解绑",
        "安装", "下载", "app", "APP", "开机", "关机", "重置", "复位",
        "故障", "坏了", "不响应", "没反应", "充电", "续航",
        "适用年级", "适合几年级", "几岁", "年龄段", "配套", "点读笔用法",
    ]
    # 直接归类为「其他」的关键词（避免误判）
    _OTHER_KW = [
        "多少钱", "价格", "售价", "优惠", "折扣", "优惠券",
        "订单", "发货", "物流", "快递", "几天到", "退款", "退货",
        "售后", "投诉", "付款", "支付", "库存", "有没有货",
    ]

    q_lower = query.lower()
    if any(kw in query or kw in q_lower for kw in _OTHER_KW):
        return "other", 200, _CT
    if any(kw in query or kw in q_lower for kw in _DOC_KW):
        return "doc", 200, _CT

    # ── 模型兜底（后端轮转，跳过优先模型留给主对话） ─────────────────
    messages = [
        {"role": "system", "content": (
            "你是意图分类助手。判断用户问题属于哪类，只输出一个词：\n"
            "- doc：询问产品使用说明、教程、操作方法、激活、连接、适用年级等文档类信息\n"
            "- other：询问价格、库存、订单、物流、售后、或其他非文档问题\n"
            "只输出 doc 或 other，不加任何其他内容。"
        )},
        {"role": "user", "content": query},
    ]
    hdrs = {"Authorization": _GLM_AUTH, "Content-Type": "application/json"}
    for backend in _CHAT_BACKENDS:
        if backend["model"] == _PRIORITY_MODEL:
            continue
        try:
            payload = {"model": backend["model"], "messages": messages,
                       "temperature": 0, "max_tokens": 10}
            resp = _http.post(_GLM_URL, headers=hdrs, json=payload, timeout=10)
            if resp.status_code in (403, 429, 502, 503, 504):
                continue
            resp.raise_for_status()
            result = resp.json()["choices"][0]["message"]["content"].strip().lower()
            if "doc" in result:
                return "doc", 200, _CT
            return "other", 200, _CT
        except Exception:
            continue
    return "other", 200, _CT


@app.route('/download/dify_v6', methods=['GET'])
def download_dify_v6():
    """下载最新 Dify 工作流文件 dify_v6.yml（含 ngrok 跳过头，外网可直接下载）"""
    from flask import send_file as _send_file
    _f = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "dify_v6.yml")
    resp = _send_file(_f, as_attachment=True, download_name="dify_v6.yml",
                      mimetype="application/x-yaml")
    resp.headers["ngrok-skip-browser-warning"] = "true"
    return resp


def _get_access_urls() -> dict:
    """动态获取当前 IP 和隧道 URL"""
    import socket as _sock
    try:
        s = _sock.socket(_sock.AF_INET, _sock.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        local_ip = "127.0.0.1"

    tunnel_url = ""
    tunnel_file = r"D:\windows powershells\ips_cache\tunnel_url.txt"
    try:
        with open(tunnel_file, encoding="utf-8") as f:
            tunnel_url = f.read().strip()
    except Exception:
        pass

    return {"local_ip": local_ip, "tunnel_url": tunnel_url}


def _file_reload_watchdog():
    """检测 server.py 文件被修改后自动 execv 重启，新代码立即生效，无需手动干预。"""
    import time
    script = os.path.abspath(__file__)
    try:
        birth_mtime = os.path.getmtime(script)
    except Exception:
        return
    while True:
        time.sleep(30)
        try:
            if os.path.getmtime(script) != birth_mtime:
                print("[watchdog] server.py 已更新，自动重启中...", flush=True)
                time.sleep(1)
                os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception:
            pass


if __name__ == '__main__':
    _ensure_log_table()
    # 启动 Teable 轮询线程
    threading.Thread(target=_teable_poll_loop, daemon=True).start()
    # 文件变更自动重启 watchdog 已禁用（由 network_watchdog.py 统一管理）
    # threading.Thread(target=_file_reload_watchdog, daemon=True).start()
    # 恢复上次重启前未完成的异步生图/生视频任务
    _recover_async_jobs()
    # 启动后同步当前权限到 Teable
    threading.Thread(target=_sync_perms_to_teable, daemon=True).start()
    # 预热产品文档知识库（异步加载，首次请求前完成）
    threading.Thread(target=_load_doc_kb, daemon=True).start()

    urls = _get_access_urls()
    local_url   = f"http://{urls['local_ip']}:8765"
    tunnel_url  = urls['tunnel_url'] or "（SSH 隧道未启动）"

    print("=" * 60)
    print("内购 Skill HTTP 服务已启动")
    print(f"内网地址 : {local_url}  （随 IP 变化）")
    print(f"公网隧道 : {tunnel_url}  ★ 配置到 Dify 的固定 URL")
    print("Teable轮询: 内购客服任务触发表（每10秒）")
    print("接口:")
    print("  POST /api/agent/chat       ★ Agent智能对话")
    print("  POST /api/task/submit      下单触发任务")
    print("  GET  /api/task/status/<id> 查询进度")
    print("  GET  /health               健康检查")
    print(f"  GET  /admin/permissions    ★ 权限管理页面")
    print("=" * 60)
    # 启动 GLM worker 线程池（工具执行期间可真正并行，GLM 速率锁保证调用间隔）
    for _wid in range(_GLM_WORKERS):
        threading.Thread(target=_glm_worker, args=(_wid,), daemon=True,
                         name=f'glm-worker-{_wid}').start()
    print(f"GLM worker 线程已启动：{_GLM_WORKERS} 个")
    app.run(host='0.0.0.0', port=8765, debug=False, threaded=True)
