"""
内购售后工单记录
写入 Teable 售后工单表，自动创建表（若不存在）
用法: python record_aftersale.py --user_id xx --issue_type xx --product xx --order_id xx --description xx
"""
import sys, os, json, argparse, urllib.request
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

BASE_URL   = "https://yach-teable.zhiyinlou.com"
BASE_ID    = "bseFFoyVD6WgFbKmzDN"
TOKEN      = "teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw="
TABLE_NAME = "内购售后工单"

HEADERS = {
    "Authorization": f"Bearer {TOKEN}",
    "Content-Type": "application/json"
}


def _req(method, path, data=None):
    url = f"{BASE_URL}/api{path}"
    body = json.dumps(data, ensure_ascii=True).encode('utf-8') if data else None
    req = urllib.request.Request(url, data=body, headers=HEADERS, method=method)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode('utf-8'))


def get_or_create_table() -> str:
    tables = _req("GET", f"/base/{BASE_ID}/table?take=100")
    for t in (tables if isinstance(tables, list) else tables.get("tables", [])):
        if t.get("name") == TABLE_NAME:
            return t["id"]

    resp = _req("POST", f"/base/{BASE_ID}/table", {
        "name": TABLE_NAME,
        "fields": [
            {"name": "提交时间", "type": "date"},
            {"name": "用户工号", "type": "singleLineText"},
            {"name": "问题类型", "type": "singleLineText"},
            {"name": "商品名称", "type": "singleLineText"},
            {"name": "订单号",   "type": "singleLineText"},
            {"name": "问题描述", "type": "longText"},
            {"name": "处理状态", "type": "singleLineText"}
        ]
    })
    return resp["id"]


def generate_ticket_id() -> str:
    return f"IPO-AS-{datetime.now().strftime('%Y%m%d%H%M%S')}"


def record(user_id, issue_type, product, order_id, description) -> str:
    table_id = get_or_create_table()
    now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000Z")
    ticket_id = generate_ticket_id()

    _req("POST", f"/table/{table_id}/record?fieldKeyType=name", {
        "records": [{
            "fields": {
                "提交时间": now,
                "用户工号": str(user_id),
                "问题类型": str(issue_type),
                "商品名称": str(product or ""),
                "订单号":   str(order_id or ""),
                "问题描述": str(description),
                "处理状态": "待处理"
            }
        }]
    })
    print(f"售后工单已记录: {ticket_id}")
    return ticket_id


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--user_id",     default="unknown")
    p.add_argument("--issue_type",  default="其他")
    p.add_argument("--product",     default="")
    p.add_argument("--order_id",    default="")
    p.add_argument("--description", default="")
    args = p.parse_args()
    ticket = record(args.user_id, args.issue_type, args.product, args.order_id, args.description)
    print(ticket)
