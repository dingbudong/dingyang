"""
九凤内购商城订单查询
用法: python query_order.py --user_id 工号 [--order_id 订单号]
"""
import sys, os, json, argparse, urllib.request, urllib.parse
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(SCRIPT_DIR)), "cs-product", "scripts"))

from jiufeng_login import get_cookies, refresh_cookies, COOKIE_FILE

JIUFENG_BASE = "https://udc.100tal.com"
ORDER_API    = f"{JIUFENG_BASE}/jiufeng/api/order/list"


def _do_query(cookies: dict, user_id: str, order_id: str) -> dict:
    cookie_str = "; ".join(f"{k}={v}" for k, v in cookies.items())
    hdrs = {
        "Cookie": cookie_str,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json",
        "Referer": f"{JIUFENG_BASE}/jiufeng/order/list",
    }
    params = {"page": 1, "page_size": 50}
    if order_id:
        params["order_no"] = order_id
    elif user_id:
        params["empl_id"] = user_id
    url = f"{ORDER_API}?{urllib.parse.urlencode(params)}"
    r = urllib.request.urlopen(urllib.request.Request(url, headers=hdrs), timeout=15)
    return json.loads(r.read().decode("utf-8"))


def query_orders(user_id: str, order_id: str = "") -> list:
    cookies = get_cookies()
    data = _do_query(cookies, user_id, order_id)
    if data.get("errcode") != 0:
        try:
            os.remove(COOKIE_FILE)
        except Exception:
            pass
        cookies = refresh_cookies()
        data = _do_query(cookies, user_id, order_id)

    results = []
    for item in data.get("data", {}).get("list", []):
        results.append({
            "order_id":    item.get("order_no", ""),
            "order_time":  item.get("create_time_format", ""),
            "product":     item.get("sku_name", ""),
            "amount":      f"¥{int(item.get('pay_price', 0)) / 100:.0f}" if item.get("pay_price") else "—",
            "pay_status":  item.get("order_status_name", ""),
            "ship_status": _ship_status(item),
            "express_no":  item.get("third_track_no", ""),
        })
    return results


def _ship_status(item: dict) -> str:
    status = item.get("order_status_name", "")
    track_no = item.get("third_track_no", "")
    if track_no:
        corp = item.get("express_corp_name", "")
        return f"已发货 [{corp} {track_no}]" if corp else f"已发货 [{track_no}]"
    return status


def format_reply(user_id: str, orders: list) -> str:
    if not orders:
        return (
            "未查询到您名下的内购订单记录。\n"
            "如有疑问，请联系内购管理员（工号：215734）协助处理。"
        )

    lines = [f"【内购订单查询结果】工号：{user_id}\n"]
    for o in orders:
        ship = o.get("ship_status", "处理中")
        ship_icon = "✅" if "签收" in ship else "🚚" if "发货" in ship else "⏳"
        lines.append(
            f"订单号：{o.get('order_id', '—')}\n"
            f"下单时间：{o.get('order_time', '—')}\n"
            f"商品：{o.get('product', '—')}\n"
            f"实付金额：{o.get('amount', '—')}\n"
            f"订单状态：{o.get('pay_status', '—')}\n"
            f"物流状态：{ship} {ship_icon}\n"
            f"{'—'*30}"
        )
    return "\n".join(lines)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--user_id", default="")
    p.add_argument("--order_id", default="")
    p.add_argument("--json_output", action="store_true")
    args = p.parse_args()

    orders = query_orders(args.user_id, args.order_id)
    if args.json_output:
        print(json.dumps(orders, ensure_ascii=False))
    else:
        print(format_reply(args.user_id, orders))
