"""
九凤内购商城 Cookie 获取（ipo-assistant 专用）
优先复用缓存 Cookie → HTTP SSO 刷新 → 弹出浏览器让用户手动登录。
Cookie 保存到 jiufeng_cookies_pw.json（与 cs-product 的 jiufeng_cookies.json 统一来源）。
"""
import os, sys, json

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

WORK_DIR    = r"D:\windows powershells"
CACHE_DIR   = os.path.join(WORK_DIR, "ips_cache")
COOKIE_FILE = os.path.join(CACHE_DIR, "jiufeng_cookies_pw.json")

if WORK_DIR not in sys.path:
    sys.path.insert(0, WORK_DIR)


def get_cookies() -> dict:
    """获取九凤 Cookie：优先复用缓存，失效则自动刷新（HTTP 或交互式浏览器）。"""
    from cookie_manager import get_jiufeng, JIUFENG_COOKIE_FILE

    cookies = get_jiufeng()

    # 同步保存一份到 jiufeng_cookies_pw.json 供本脚本历史路径使用
    os.makedirs(CACHE_DIR, exist_ok=True)
    with open(COOKIE_FILE, "w", encoding="utf-8") as f:
        json.dump(cookies, f, ensure_ascii=False)

    return cookies


if __name__ == "__main__":
    cookies = get_cookies()
    print("登录成功:", list(cookies.keys()))
