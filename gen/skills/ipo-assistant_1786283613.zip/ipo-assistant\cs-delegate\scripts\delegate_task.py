"""
委派任务脚本 — P2P 发关键词（聊天框可见）+ 写 Teable 触发守护进程执行
流程：
  1. 用数字伙伴自己的 appkey/appsecret 向丁洋（215734）发 P2P（聊天框可见，关键词+确认语）
  2. P2P 成功后写入对应守护进程的 Teable 触发表
  3. 守护进程检测到新记录后自行执行任务
  wms_audit 例外：通过 agent/chat 发消息（无 Teable 机制）

用法: python delegate_task.py --bot <标识> [--from_user <工号>] [--note <备注>]
返回: JSON to stdout
  {"ok": true,  "bot": "replenishment", "keyword": "内购补货", "msg": "..."}
  {"ok": false, "bot": "xxx",           "error": "未知 bot 标识"}
"""
import sys, json, argparse, urllib.request, urllib.parse
import time as _time

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

_YACH_HOST    = "https://yach-oapi.zhiyinlou.com"
_TEABLE_BASE  = "https://yach-teable.zhiyinlou.com"

BOT_REGISTRY = {
    "selection": {
        "appkey":        "04cd9316ea799b5e",
        "appsecret":     "33465270c4e2088a8e1626650600ce8a",
        "p2p_msg":       "内购选品",
        "teable_table":  "tblr9vOXaPBs180xBr9",
        "teable_token":  "teable_acc0p3f5Wzz0NRf7OqM_3F9pu44PSpF8IEd7tk++koloKeWq6NC2S0ItJYUOvM8=",
        "teable_field":  "内购选品",
        "teable_value":  "内购选品",
        "bot_name":      "内购选品助手",
        "eta":           "10~20 分钟",
    },
    "replenishment": {
        "appkey":        "a964fec003f72b0e",
        "appsecret":     "3967215521d4ad3eecfb9384e28f1b6f",
        "p2p_msg":       "内购补货",
        "teable_table":  "tbl7IncMAl7url7wKKh",
        "teable_token":  "teable_accJDDZk23KWl5v2bKJ_02VskdGD1vMu/RzPjieeRgIEF6D7xttSLIVmAmr3Npk=",
        "teable_field":  "内购补货",
        "teable_value":  "智能客服触发",
        "bot_name":      "内购补货小助理",
        "eta":           "5~15 分钟",
    },
    "new_product": {
        "appkey":        "ef57ae908900f9fd",
        "appsecret":     "83dd122d77575ab7be2ff80a447400a0",
        "p2p_msg":       "内购上新",
        "teable_table":  "tbl11sCqQanpy6V0c7z",
        "teable_token":  "teable_accyMsfXF7HDTO7F50T_he00Z50Epx8W051QlYPAqhGZ44YCY9ldmLm+mGa+YF0=",
        "teable_field":  "商品上架",
        "teable_value":  "内购上新",
        "bot_name":      "内购上新助手",
        "eta":           "2~5 分钟",
    },
    "upload": {
        "appkey":        "ef57ae908900f9fd",
        "appsecret":     "83dd122d77575ab7be2ff80a447400a0",
        "p2p_msg":       "商品上架",
        "teable_table":  "tbl11sCqQanpy6V0c7z",
        "teable_token":  "teable_accyMsfXF7HDTO7F50T_he00Z50Epx8W051QlYPAqhGZ44YCY9ldmLm+mGa+YF0=",
        "teable_field":  "商品上架",
        "teable_value":  "商品上架",
        "bot_name":      "九凤上架助手",
        "eta":           "5~10 分钟",
    },
    "wms_audit": {
        "appkey":        "958b3e6c4efb148b",
        "appsecret":     "ed9ef8a3408105d1848d2bb160dad4e6",
        "bot_name":      "WMS出入库审核助手",
        "eta":           "5~15 分钟",
    },
}

_WMS_WAREHOUSE_MAP = {
    "黄陂": "武汉黄陂仓", "武汉": "武汉黄陂仓",
    "内购": "内购仓",
    "武清": "武清仓",
}


def _get_token(appkey: str, appsecret: str) -> str:
    resp = urllib.request.urlopen(
        f'{_YACH_HOST}/gettoken?appkey={appkey}&appsecret={appsecret}',
        timeout=15
    ).read().decode('utf-8')
    return json.loads(resp)['obj']['access_token']


def _p2p(token: str, msg: str) -> bool:
    """用数字伙伴身份向 215734 发 P2P，消息在聊天框可见。"""
    body = urllib.parse.urlencode({
        'access_token': token,
        'to_work_code': '215734',
        'message': json.dumps({'msgtype': 'text', 'text': {'content': msg}}, ensure_ascii=False),
    }).encode('utf-8')
    raw = urllib.request.urlopen(urllib.request.Request(
        f'{_YACH_HOST}/v1/single/message/send',
        data=body,
        headers={'Content-Type': 'application/x-www-form-urlencoded'},
        method='POST',
    ), timeout=15).read()
    code = json.loads(raw.decode('utf-8')).get('errcode', -1)
    return code in (0, 200)


def _teable_write(table_id: str, token: str, field: str, value: str) -> bool:
    """写入 Teable 触发记录，守护进程检测后执行任务。"""
    payload = json.dumps({
        'fieldKeyType': 'name',
        'records': [{'fields': {field: value}}],
    }, ensure_ascii=False).encode('utf-8')
    raw = urllib.request.urlopen(urllib.request.Request(
        f'{_TEABLE_BASE}/api/table/{table_id}/record',
        data=payload,
        headers={
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
        },
        method='POST',
    ), timeout=15).read()
    resp = json.loads(raw.decode('utf-8'))
    return bool(resp.get('records') or resp.get('id'))


def _agent_chat(token: str, query: str) -> None:
    payload = json.dumps({
        'access_token': token,
        'query':        query,
        'biz_id':       f"ipo-{int(_time.time())}",
        'msg_type':     'text',
    }, ensure_ascii=False).encode('utf-8')
    urllib.request.urlopen(urllib.request.Request(
        f'{_YACH_HOST}/openapi/v2/agent/chat',
        data=payload,
        headers={'Content-Type': 'application/json; charset=utf-8'},
        method='POST',
    ), timeout=15).read()


def delegate(bot: str, from_user: str = "", note: str = "",
             qc_no: str = "", qr_no: str = "", warehouse: str = "",
             sheet_url: str = "") -> dict:
    conf = BOT_REGISTRY.get(bot)
    if not conf:
        return {"ok": False, "bot": bot, "error": f"未知 bot 标识: {bot}，可选: {list(BOT_REGISTRY)}"}

    try:
        token = _get_token(conf["appkey"], conf["appsecret"])

        # ── wms_audit：agent/chat（无 Teable 机制）
        if bot == "wms_audit":
            if not qc_no or not qr_no:
                return {"ok": False, "bot": bot, "error": "wms_audit 需要提供 qc_no 和 qr_no"}
            wh_name = next((v for k, v in _WMS_WAREHOUSE_MAP.items() if k in warehouse), "武清仓")
            query = f"审核wms {qc_no} {wh_name} {qr_no} {wh_name}"
            _agent_chat(token, query)
            keyword = f"QC:{qc_no} QR:{qr_no} 仓库:{wh_name}"
            msg = f"已通知{conf['bot_name']}！\n出库单：{qc_no}（{wh_name}）\n入库单：{qr_no}（{wh_name}）\n结果会通过知音楼推送给丁洋老师。"
            return {"ok": True, "bot": bot, "keyword": keyword, "msg": msg}

        # ── selection_upload：动态关键词
        if bot == "selection_upload" or (bot == "selection" and sheet_url):
            if not sheet_url:
                return {"ok": False, "bot": bot, "error": "selection_upload 需要提供 sheet_url"}
            keyword = f"image_upload:::{sheet_url}"
            eta = conf.get('eta', '几分钟')
            full_msg = f"选品明细导入\n收到！选品明细导入任务已启动，正在处理中，预计 {eta}，完成后会通知丁洋老师。"
            if not _p2p(token, full_msg):
                return {"ok": False, "bot": bot, "error": "P2P 发送失败"}
            _teable_write(conf['teable_table'], conf['teable_token'], conf['teable_field'], keyword)
            return {"ok": True, "bot": bot, "keyword": keyword,
                    "msg": f"已通知{conf['bot_name']}！\n表格：{sheet_url}\n结果会通过知音楼推送给丁洋老师。"}

        # ── 其他 bot：P2P 发关键词（可见）→ Teable 写入触发
        eta = conf.get('eta', '几分钟')
        full_msg = f"{conf['p2p_msg']}\n收到！任务已启动，正在执行中，预计 {eta}，完成后会通知丁洋老师。"
        if not _p2p(token, full_msg):
            return {"ok": False, "bot": bot, "error": "P2P 发送失败，请稍后重试"}
        _teable_write(conf['teable_table'], conf['teable_token'], conf['teable_field'], conf['teable_value'])
        keyword = conf['p2p_msg']

    except Exception as e:
        return {"ok": False, "bot": bot, "error": f"委派失败: {e}"}

    return {
        "ok":      True,
        "bot":     bot,
        "keyword": keyword,
        "msg":     f"已通知{conf['bot_name']}！\n结果会通过知音楼推送给丁洋老师。",
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="委派任务到目标数字伙伴（P2P可见+Teable触发）")
    p.add_argument("--bot",       required=True, help="bot 标识: selection/replenishment/new_product/upload/wms_audit")
    p.add_argument("--from_user", default="",    help="触发来源工号")
    p.add_argument("--note",      default="",    help="附加备注")
    p.add_argument("--qc_no",     default="",    help="WMS出库单号（QC开头，wms_audit专用）")
    p.add_argument("--qr_no",     default="",    help="WMS入库单号（QR开头，wms_audit专用）")
    p.add_argument("--warehouse", default="",    help="仓库关键词（wms_audit专用，默认武清仓）")
    p.add_argument("--sheet_url", default="",    help="表格URL（selection_upload专用）")
    args = p.parse_args()

    result = delegate(args.bot, args.from_user, args.note,
                      args.qc_no, args.qr_no, args.warehouse, args.sheet_url)
    print(json.dumps(result, ensure_ascii=False))
