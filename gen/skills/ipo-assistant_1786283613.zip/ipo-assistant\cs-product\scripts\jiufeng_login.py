"""
九凤内购商城后台登录（ipo-assistant 专用）
通过 SSO(zhiyinlou) → UDC 链路获取九凤 Cookie
Cookie 保存至 ips_cache/jiufeng_cookies.json
"""
import sys, os, json, re, base64, logging, time
import urllib.request, urllib.parse, urllib.error, http.cookiejar

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

CACHE_DIR   = r"D:\windows powershells\ips_cache"
COOKIE_FILE = os.path.join(CACHE_DIR, "jiufeng_cookies.json")
LOCK_FILE   = os.path.join(CACHE_DIR, "jiufeng_login.lock")
ACCOUNT     = "215734"
PASSWORD    = "Ding-1590152"
JIUFENG_URL = "https://udc.100tal.com/jiufeng/goodsForSale/list"

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s',
                    handlers=[logging.StreamHandler(sys.stderr)])
log = logging.getLogger(__name__)


def load_cookies():
    """只读文件，不做任何网络验证。调用方负责在 API 返回 auth 错误时重新登录。"""
    if not os.path.exists(COOKIE_FILE):
        return None
    try:
        with open(COOKIE_FILE, encoding='utf-8') as f:
            raw = json.load(f)
        cd = raw if isinstance(raw, dict) else {c['name']: c['value'] for c in raw if c.get('name')}
        return cd or None
    except Exception:
        return None


def _des_encrypt(plaintext, key_str):
    try:
        from Crypto.Cipher import DES
        from Crypto.Util.Padding import pad
        key_bytes = key_str.encode('utf-8')[:8].ljust(8, b'\x00')
        cipher = DES.new(key_bytes, DES.MODE_ECB)
        return base64.b64encode(cipher.encrypt(pad(plaintext.encode('utf-8'), 8))).decode('ascii')
    except ImportError:
        return base64.b64encode(plaintext.encode('utf-8')).decode('ascii')


def login():
    jar = http.cookiejar.CookieJar()

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def http_error_302(self, req, fp, code, msg, headers):
            raise urllib.error.HTTPError(req.full_url, code, msg, headers, fp)
        http_error_301 = http_error_302
        http_error_303 = http_error_302

    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar), NoRedirect())
    opener.addheaders = [
        ('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36'),
        ('Accept', 'application/json, text/plain, */*'),
    ]

    # Step 1: UDC authorize → SSO redirect
    redirect_b64 = base64.b64encode(JIUFENG_URL.encode()).decode()
    authorize_url = f"https://udc.100tal.com/kunpeng/api/sso/authorize?login_type=code&appid=100118&redirect_url={redirect_b64}"
    log.info("Step1: UDC authorize")
    url = authorize_url
    for _ in range(6):
        if not url:
            break
        try:
            r = opener.open(url, timeout=15)
            url = r.url
        except urllib.error.HTTPError as e:
            loc = e.headers.get('Location', '').strip()
            if loc:
                url = urllib.parse.urljoin(url, loc)
        if 'sso.zhiyinlou.com' in url:
            break
    sso_url = url
    log.info(f"Step1 done: SSO URL={sso_url[:80]}")

    # Step 2: GET SSO page, extract __SSO_APITOKEN__ + __SSO_QUERYBASE64__
    try:
        r2 = opener.open(sso_url, timeout=15)
        html = r2.read().decode('utf-8', errors='replace')
    except urllib.error.HTTPError as e:
        html = e.fp.read().decode('utf-8', errors='replace')

    m_token = re.search(r"__SSO_APITOKEN__\s*=\s*'([^']+)'", html)
    m_query = re.search(r"__SSO_QUERYBASE64__\s*=\s*'([^']*)'", html)
    m_appid = re.search(r'/portal/login/(\d+)', sso_url)
    if not m_token:
        raise RuntimeError("无法从SSO页面提取 __SSO_APITOKEN__")
    apitoken = m_token.group(1)
    query_b64 = m_query.group(1) if m_query else ''
    sso_appid = m_appid.group(1) if m_appid else ''
    log.info(f"Step2 done: appid={sso_appid}")

    hdrs = {
        'apiToken': apitoken, 't-csrf-token': '',
        'Referer': sso_url, 'Accept': 'application/json, text/plain, */*',
        'Origin': 'https://sso.zhiyinlou.com',
    }

    # Step 3: GET captcha ticket
    cap = json.loads(opener.open(
        urllib.request.Request('https://sso.zhiyinlou.com/portal/api/v1/captcha', headers=hdrs),
        timeout=10).read().decode())
    ticket = cap['data']['ticket']
    log.info(f"Step3 done: ticket={ticket[:20]}...")

    # Step 4: GET password encrypt key
    enc = json.loads(opener.open(
        urllib.request.Request(
            f'https://sso.zhiyinlou.com/portal/api/v1/password/encrypt?account={ACCOUNT}',
            headers=hdrs),
        timeout=10).read().decode())
    encrypt_key = enc['data']['encrypt']
    log.info(f"Step4 done: encrypt_key={encrypt_key[:20]}...")

    # Step 5: POST SSO login
    enc_pwd = _des_encrypt(PASSWORD, encrypt_key)
    login_data = urllib.parse.urlencode({
        'account': ACCOUNT, 'password': enc_pwd, 'appid': sso_appid,
        'plat': 'Web', 'query': query_b64, 'ticket': ticket,
        'captchaCode': '', 'encrypt': encrypt_key,
    }).encode()
    login_r = json.loads(opener.open(urllib.request.Request(
        'https://sso.zhiyinlou.com/portal/api/v1/login', data=login_data,
        headers={**hdrs, 'Content-Type': 'application/x-www-form-urlencoded'}),
        timeout=15).read().decode())
    if login_r.get('errcode') != 0:
        raise RuntimeError(f"SSO login failed: {login_r}")
    udc_redirect = login_r['data'].get('redirect_url') or login_r['data'].get('redirectUrl', '')
    log.info(f"Step5 done: SSO login OK, redirect={udc_redirect[:80]!r}")

    # Step 5b: two-factor password verify (new SSO flow since 2026-05)
    # When redirect_url is empty, level3_key + uuid returned → verify password again
    if not udc_redirect:
        level3_key = login_r['data'].get('level3_key', '')
        if not level3_key:
            log.error(f"SSO returned empty redirect_url and no level3_key. Full response: {json.dumps(login_r, ensure_ascii=False)}")
            raise RuntimeError(f"SSO login failed - no redirect_url or level3_key: {login_r}")
        log.info("Step5b: two-factor pwd verify (level3)...")
        l3_data = urllib.parse.urlencode({
            'password': enc_pwd, 'appid': sso_appid,
            'query': query_b64, 'level3_key': level3_key,
            'encrypt': encrypt_key,
        }).encode()
        l3_r = json.loads(opener.open(urllib.request.Request(
            f'https://sso.zhiyinlou.com/portal/two_factor/pwd/verify', data=l3_data,
            headers={**hdrs, 'Content-Type': 'application/x-www-form-urlencoded'}),
            timeout=15).read().decode())
        udc_redirect = l3_r.get('redirect_url') or l3_r.get('data', {}).get('redirect_url', '')
        log.info(f"Step5b done: level3 verify, redirect={udc_redirect[:80]!r}")
        if not udc_redirect:
            raise RuntimeError(f"two_factor/pwd/verify returned no redirect_url: {l3_r}")

    # Step 6: Follow UDC callback chain → jiufeng cookies
    url = udc_redirect
    for _ in range(8):
        if not url:
            break
        try:
            r = opener.open(url, timeout=15)
            break
        except urllib.error.HTTPError as e:
            loc = e.headers.get('Location', '').strip()
            if not loc:
                break
            url = urllib.parse.urljoin(url, loc)
            if 'jiufeng' in url:
                try:
                    opener.open(url, timeout=15)
                except Exception:
                    pass
                break
    log.info("Step6 done: UDC callback chain complete")

    cd = {c.name: c.value for c in jar}
    os.makedirs(CACHE_DIR, exist_ok=True)
    with open(COOKIE_FILE, 'w', encoding='utf-8') as f:
        json.dump(cd, f, ensure_ascii=False)
    log.info(f"九凤 IPO Cookie 已保存: {COOKIE_FILE}")
    return cd


def get_cookies():
    """读文件返回 cookies；文件不存在时才触发登录。"""
    cookies = load_cookies()
    if cookies:
        return cookies
    return refresh_cookies()


def refresh_cookies():
    """重新 SSO 登录，文件锁保证多个并发进程只跑一次，其余等待后复用结果。"""
    log.info("Cookie 文件不存在，尝试获取登录锁...")
    lock_fd = None
    try:
        for _attempt in range(30):
            try:
                lock_fd = os.open(LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                break
            except FileExistsError:
                time.sleep(1)
                cookies = load_cookies()
                if cookies:
                    log.info("等锁期间另一进程已完成登录，复用结果")
                    return cookies
        if lock_fd is None:
            log.warning("等待登录锁超时，强制清锁重试")
            try:
                os.remove(LOCK_FILE)
            except Exception:
                pass
            lock_fd = os.open(LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        log.info("已获取登录锁，开始 SSO 登录...")
        return login()
    finally:
        if lock_fd is not None:
            try:
                os.close(lock_fd)
            except Exception:
                pass
            try:
                os.remove(LOCK_FILE)
            except Exception:
                pass


if __name__ == "__main__":
    cookies = get_cookies()
    print("登录成功:", list(cookies.keys()))
