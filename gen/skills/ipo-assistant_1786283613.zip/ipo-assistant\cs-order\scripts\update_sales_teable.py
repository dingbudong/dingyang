"""
内购订单明细增量同步到 Teable「内购订单明细」表
每6小时由 Teable 自动化触发，或手动运行

流程：先刷新九凤 Cookie → 分页拉全量订单（仅智能内容+未来学校）→ 与现有记录对比 → 新增不存在的订单 / 更新状态变化的记录
历史数据永不删除；仅退款状态和订单状态字段会被更新
"""
import sys, os, json, urllib.request, urllib.parse, subprocess, time
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
COOKIE_FILE = r"D:\windows powershells\ips_cache\jiufeng_cookies_pw.json"
LOG_FILE    = r"D:\windows powershells\ips_cache\auto_tasks.log"

_log_fh = None

def _get_log_fh():
    global _log_fh
    if _log_fh is None:
        _log_fh = open(LOG_FILE, 'a', encoding='utf-8', buffering=1)
    return _log_fh

def log(msg):
    line = f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n"
    try:
        sys.stdout.write(line); sys.stdout.flush()
    except Exception:
        pass
    try:
        fh = _get_log_fh()
        fh.write(line)
        fh.flush()
    except Exception:
        pass

JIUFENG_BASE = "https://udc.100tal.com"
ORDER_API    = f"{JIUFENG_BASE}/jiufeng/api/order/list"
PAGE_SIZE    = 400

TEABLE_BASE  = "https://yach-teable.zhiyinlou.com"
TEABLE_TOKEN = "teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw="
TEABLE_TABLE = "tblWh60leD6kYVW7Crl"  # 内购订单明细
TEABLE_HDRS  = {
    "Authorization": f"Bearer {TEABLE_TOKEN}",
    "Content-Type": "application/json",
}


def _teable_req(method, path, body=None):
    url = f"{TEABLE_BASE}{path}"
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=TEABLE_HDRS, method=method)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())


def _row_key(fields_or_row: dict) -> str:
    """子订单号+SKU编码 作为唯一复合键（同一子订单下不同SKU是不同行）"""
    child = str(fields_or_row.get("子订单号", "") or "").strip()
    sku   = str(fields_or_row.get("SKU编码", "") or "").strip()
    if child and sku:
        return f"{child}|{sku}"
    if child:
        return child
    return f"___{fields_or_row.get('父订单号','')}_{fields_or_row.get('工号','')}_{fields_or_row.get('商品名称','')}"

def _parent_sku_key(fields_or_row: dict) -> str:
    """父订单号+SKU编码 备用键：防止子订单号格式变换（内部号↔三方号）导致重复写入"""
    parent = str(fields_or_row.get("父订单号", "") or "").strip()
    sku    = str(fields_or_row.get("SKU编码", "") or "").strip()
    return f"p|{parent}|{sku}" if (parent and sku) else ""


def fetch_existing_records() -> dict:
    """从 Teable 读取所有已有记录
    返回两个索引：
      existing      {子订单号|SKU编码: {id,...}}
      existing_psku {父订单号|SKU编码: {id,...}}  ← 备用，防子订单号格式变换
    """
    existing = {}
    existing_psku = {}
    skip = 0
    take = 1000
    while True:
        for attempt in range(3):
            try:
                resp = _teable_req("GET", f"/api/table/{TEABLE_TABLE}/record?take={take}&skip={skip}&fieldKeyType=name")
                break
            except Exception as e:
                if attempt == 2:
                    raise
                log(f"  读取第{skip//take+1}页失败，重试{attempt+1}/3: {e}")
                time.sleep(3)
        records = resp.get("records", [])
        for r in records:
            fields = r.get("fields", {})
            val = {
                "id": r["id"],
                "订单状态": str(fields.get("订单状态", "") or ""),
                "退款状态": str(fields.get("退款状态", "") or ""),
                "快递单号": str(fields.get("快递单号", "") or ""),
                "快递公司": str(fields.get("快递公司", "") or ""),
            }
            existing[_row_key(fields)] = val
            pk = _parent_sku_key(fields)
            if pk:
                existing_psku[pk] = val
        if len(records) < take:
            break
        skip += take
        log(f"  已读取现有记录 {skip} 条…")
    return existing, existing_psku


def update_batch(updates: list):
    """批量更新订单状态/退款状态，每次最多 50 条，失败自动重试 3 次"""
    total = len(updates)
    for i in range(0, total, 50):
        batch = updates[i:i+50]
        records_body = [{"id": rid, "fields": fields} for rid, fields in batch]
        for attempt in range(3):
            try:
                _teable_req("PATCH", f"/api/table/{TEABLE_TABLE}/record?fieldKeyType=name",
                            {"records": records_body})
                break
            except Exception as e:
                if attempt == 2:
                    log(f"  更新失败（第{i//50+1}批，已重试3次）: {e}")
                    raise
                log(f"  更新重试 {attempt+1}/3（第{i//50+1}批）: {e}")
                time.sleep(5)
        updated = min(i + 50, total)
        if updated % 500 == 0 or updated == total:
            log(f"  已更新 {updated}/{total} 条")


def write_batch(rows: list):
    """批量写入，每次最多 50 条，失败自动重试 3 次"""
    total = len(rows)
    for i in range(0, total, 50):
        batch = rows[i:i+50]
        for attempt in range(3):
            try:
                _teable_req("POST", f"/api/table/{TEABLE_TABLE}/record?fieldKeyType=name",
                            {"records": [{"fields": r} for r in batch]})
                break
            except Exception as e:
                if attempt == 2:
                    log(f"  写入失败（第{i//50+1}批，已重试3次）: {e}")
                    raise
                log(f"  写入重试 {attempt+1}/3（第{i//50+1}批）: {e}")
                time.sleep(5)
        written = min(i + 50, total)
        if written % 500 == 0 or written == total:
            log(f"  已写入 {written}/{total} 条")


def fetch_all_orders() -> list:
    """分页拉取全量订单，返回格式化行列表"""
    with open(COOKIE_FILE, encoding="utf-8") as f:
        cookies = json.load(f)
    cstr = "; ".join(f"{k}={v}" for k, v in cookies.items())
    hdrs = {
        "Cookie": cstr,
        "User-Agent": "Mozilla/5.0",
        "Accept": "application/json",
        "Referer": f"{JIUFENG_BASE}/jiufeng/order/list",
    }

    rows = []
    page = 1
    while True:
        params = {"page": page, "page_size": PAGE_SIZE}
        url = f"{ORDER_API}?{urllib.parse.urlencode(params)}"
        try:
            req = urllib.request.Request(url, headers=hdrs)
            with urllib.request.urlopen(req, timeout=20) as r:
                data = json.loads(r.read().decode())
        except Exception as e:
            log(f"  第{page}页请求失败: {e}")
            break

        items = data.get("data", {}).get("list", [])
        if not items:
            break

        for item in items:
            if item.get("supplier_name", "") not in ("智能内容", "未来学校"):
                continue
            attr = item.get("sku_attr") or []
            spec = "、".join(a.get("value", "") for a in attr if a.get("value")) if attr else ""
            pay_price  = int(item.get("pay_price", 0) or 0)
            sku_num    = int(item.get("sku_num", 1) or 1)
            price_yuan = round(pay_price / 100, 2)
            create_fmt = item.get("create_time_format", "")
            date_only  = create_fmt[:10] if create_fmt else ""

            recipient = item.get("recipient") or {}
            is_gift   = "是" if item.get("gift_ext") else "否"

            rows.append({
                "父订单号":   item.get("third_order_no", ""),
                "三方订单号": item.get("order_no", "") or item.get("out_order_no", ""),
                "子订单号":   item.get("third_child_order_no", "") or item.get("child_order_no", ""),
                "工号":       item.get("empl_id", ""),
                "SKU编码":    item.get("sku_id", ""),
                "商品名称":   item.get("sku_name", ""),
                "商品规格":   spec,
                "是否赠品":   is_gift,
                "所属商城":   item.get("client_group_name", ""),
                "数量":       sku_num,
                "兑换价格元": price_yuan,
                "来源":       item.get("supplier_name", ""),
                "订单状态":   item.get("order_status_name", ""),
                "退款状态":   item.get("refund_price_status_name", ""),
                "下单时间":   create_fmt,
                "下单日期":   date_only,
                "快递单号":   item.get("third_track_no", "") or item.get("track_no", ""),
                "快递公司":   item.get("express_corp_name", ""),
                "收货人":     recipient.get("name", ""),
                "手机号":     recipient.get("phone", ""),
                "收货地址":   recipient.get("address", ""),
            })

        total = int(data.get("data", {}).get("total", 0) or 0)
        log(f"  第{page}页: {len(items)}条, 累计{len(rows)}/{total}")
        if page * PAGE_SIZE >= total:
            break
        page += 1

    return rows


def main():
    t0 = time.time()
    log("========== 开始同步内购订单到 Teable ==========")

    log("正在登录九凤后台（Playwright）…")
    result = subprocess.run(
        [sys.executable, os.path.join(SCRIPT_DIR, "jiufeng_login_pw.py")],
        capture_output=True, text=True, encoding='utf-8', errors='replace',
        timeout=90,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
    )
    for line in (result.stdout + result.stderr).splitlines():
        if line.strip():
            log(f"  {line}")
    if result.returncode == 0:
        log("九凤后台登录成功 ✓")
    else:
        log("九凤后台登录失败，继续尝试用现有 Cookie…")

    log("开始从九凤后台分页抓取订单数据（仅智能内容+未来学校）…")
    rows = fetch_all_orders()
    log(f"抓取完成，共 {len(rows)} 条（已过滤，仅智能内容+未来学校）")

    log("读取 Teable 现有记录…")
    existing, existing_psku = fetch_existing_records()
    log(f"现有记录 {len(existing)} 条")

    to_insert = []
    to_update = []
    for row in rows:
        key  = _row_key(row)
        pkey = _parent_sku_key(row)
        if key in existing:
            old = existing[key]
            changed = {}
            if str(row.get("订单状态", "") or "") != old["订单状态"]:
                changed["订单状态"] = row.get("订单状态", "")
            if str(row.get("退款状态", "") or "") != old["退款状态"]:
                changed["退款状态"] = row.get("退款状态", "")
            if str(row.get("快递单号", "") or "") != old["快递单号"]:
                changed["快递单号"] = row.get("快递单号", "")
            if str(row.get("快递公司", "") or "") != old["快递公司"]:
                changed["快递公司"] = row.get("快递公司", "")
            if changed:
                to_update.append((old["id"], changed))
        elif pkey and pkey in existing_psku:
            # 子订单号格式变换（内部号↔三方号），父订单+SKU匹配 → 只更新字段，不新增
            old = existing_psku[pkey]
            changed = {}
            if str(row.get("订单状态", "") or "") != old["订单状态"]:
                changed["订单状态"] = row.get("订单状态", "")
            if str(row.get("退款状态", "") or "") != old["退款状态"]:
                changed["退款状态"] = row.get("退款状态", "")
            if str(row.get("快递单号", "") or "") != old["快递单号"]:
                changed["快递单号"] = row.get("快递单号", "")
            if str(row.get("快递公司", "") or "") != old["快递公司"]:
                changed["快递公司"] = row.get("快递公司", "")
            if changed:
                to_update.append((old["id"], changed))
        else:
            to_insert.append(row)

    # 对 to_insert 用复合键去重（防止九凤API自身返回重复行）
    seen_keys  = set(existing.keys())
    seen_pkeys = set(existing_psku.keys())
    deduped = []
    dup_count = 0
    for row in to_insert:
        k  = _row_key(row)
        pk = _parent_sku_key(row)
        if k in seen_keys or (pk and pk in seen_pkeys):
            dup_count += 1
            continue
        seen_keys.add(k)
        if pk:
            seen_pkeys.add(pk)
        deduped.append(row)
    if dup_count:
        log(f"  去重过滤：跳过 {dup_count} 条完全重复行")
    to_insert = deduped

    unchanged = len(rows) - len(to_insert) - len(to_update)
    log(f"增量对比：新增 {len(to_insert)} 条，状态变化 {len(to_update)} 条，无变化 {unchanged} 条")

    if to_insert:
        log("写入新增数据…")
        try:
            write_batch(to_insert)
        except Exception as e:
            log(f"========== 新增写入中断: {e} ==========")
            raise

    if to_update:
        log("更新状态变化数据…")
        try:
            update_batch(to_update)
        except Exception as e:
            log(f"========== 状态更新中断: {e} ==========")
            raise

    elapsed = time.time() - t0
    log(f"========== 同步完成，新增 {len(to_insert)} 条，更新 {len(to_update)} 条，耗时 {elapsed:.0f}s ==========")
    return len(rows)


if __name__ == "__main__":
    main()
