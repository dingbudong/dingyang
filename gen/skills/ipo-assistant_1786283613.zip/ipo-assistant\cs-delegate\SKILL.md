# cs-delegate — 智能客服任务委派模块

智能客服的任务委派模块。当用户请求属于其他专属数字伙伴的自动化任务时，
**智能客服不直接执行**，而是先请求丁洋老师（215734）确认，
确认后通过 **P2P + Teable 双步机制** 触发目标数字伙伴守护进程自主接手。

---

## 架构原则（含确认机制）

```
用户说「内购补货」/「跑选品」/「内购上新」/「确认上架」
           ↓
  GLM 识别委派意图，调用工具 request_delegate_confirm
           ↓
  1️⃣  生成确认令牌，P2P 通知丁洋老师（215734）
  向用户回复：「已向丁洋老师申请确认，批准后自动通知对应助手」
           ↓
  ─────────── 等待丁洋老师确认 ───────────
           ↓
  丁洋老师（215734）回复「确认执行」/「确认」/「执行」
           ↓
  【快速拦截】server 在进入 GLM 之前命中：直接执行，不走 GLM
  2️⃣  调用 _delegate_teable_write：
      a. 用数字伙伴自己的 token 向丁洋（215734）发 P2P
         消息格式：「{关键词}\n收到！任务已启动，正在执行中，预计 {eta}，完成后会通知丁洋老师。」
         → 消息在数字伙伴与丁洋老师的聊天框内可见
      b. 写入目标守护进程的 Teable 触发表
           ↓
  目标守护进程（ips_daemon / ipo_daemon / ipo_new_daemon / jiufeng_upload_daemon）
    ← 30~60s 内自动轮询，检测到新记录后启动完整工作流 →
           ↓
  丁洋老师回复「取消」/「不执行」/「算了」
  → 快速拦截直接清除待确认状态，不执行任何操作
```

**安全约束：**
- 只有 user_id = `215734` **且在私聊窗口**才能触发快速拦截（确认/取消）
- 群聊中的确认/取消一律不命中拦截，会进入 GLM 走正常对话流程
- 待确认令牌 30 分钟后自动失效
- 快速拦截在 GLM 之前执行，零延迟，不消耗 token
- 委派成功回复后**禁止引导用户回复任何消息**（不得提示「请回复确认执行」等）

**⚠️ 守护进程必须运行：** 委派写入 Teable 后，若对应守护进程未运行，任务不会执行。
发现任务未执行时，先检查对应 daemon 进程是否存在（见各 daemon/SKILL.md）。

---

## 数字伙伴注册表

| bot 标识 | 数字伙伴 | P2P 关键词 | Teable 触发值 | Teable 触发表 ID |
|---------|---------|-----------|-------------|----------------|
| `selection` | 内购选品助手 | `内购选品` | `内购选品` | `tblr9vOXaPBs180xBr9` |
| `selection_upload` | 内购选品助手（导入待上架明细） | `image_upload:::<URL>` | `image_upload:::<URL>` | `tblr9vOXaPBs180xBr9` |
| `replenishment` | 内购补货小助理 | `内购补货` | `智能客服触发` | `tbl7IncMAl7url7wKKh` |
| `new_product` | 内购上新助手 | `内购上新` | `内购上新` | `tbl11sCqQanpy6V0c7z` |
| `upload` | 九凤上架助手 | `商品上架` | `商品上架` | `tbl11sCqQanpy6V0c7z` |
| `wms_audit` | WMS出入库审核助手 | 通过 `/openapi/v2/agent/chat` 直发（无 Teable 机制） | — | — |

> **P2P 消息实际发送内容**（纯中文，让智能客服可感知任务状态）：
>
> 普通 bot（如内购上新）：
> ```
> 内购上新
> 收到！任务已启动，正在执行中，预计 2~5 分钟，完成后会通知丁洋老师。
> ```
> selection_upload（选品明细导入，Teable 触发值为 `image_upload:::URL`，P2P 不暴露技术前缀）：
> ```
> 选品明细导入
> 收到！选品明细导入任务已启动，正在处理中，预计 3~5 分钟，完成后会通知丁洋老师。
> ```

---

## 调用方式

> **注意：** `server.py` 内部直接调用 `_delegate_teable_write()` 处理委派，
> `delegate_task.py` 脚本用于手动测试或外部调用场景。

```bash
# 普通 bot 委派
python "C:\Users\dingyang3\.claude\skills\ipo-assistant\cs-delegate\scripts\delegate_task.py" \
  --bot <bot标识> \
  [--from_user <工号>] \
  [--note <备注>]

# 选品明细导入（需表格 URL）
python "C:\Users\dingyang3\.claude\skills\ipo-assistant\cs-delegate\scripts\delegate_task.py" \
  --bot selection \
  --sheet_url https://yach-doc-shimo.zhiyinlou.com/sheets/xxxxx

# WMS 审核委派（需携带单号）
python "C:\Users\dingyang3\.claude\skills\ipo-assistant\cs-delegate\scripts\delegate_task.py" \
  --bot wms_audit \
  --qc_no QC202405010001 \
  --qr_no QR202405010001 \
  [--warehouse 武清] \
  [--from_user <工号>]
```

### 返回（stdout JSON）

```json
{"ok": true, "bot": "replenishment", "keyword": "内购补货", "msg": "已通知内购补货小助理！..."}
{"ok": false, "bot": "xxx", "error": "未知 bot 标识"}
```

---

## 各数字伙伴执行时效参考

| 数字伙伴 | 守护进程 | 轮询间隔 | 全流程耗时 | 结果推送 |
|---------|---------|---------|----------|---------|
| 内购选品助手 | `ips_daemon.py` | ~15s | 10~20 分钟 | 知音楼推送选品表格链接 |
| 内购补货小助理 | `ipo_daemon.py` | ~30s | 5~15 分钟 | 知音楼推送补货文档链接 |
| 内购上新助手 | `ipo_new_daemon.py` | ~30s | 2~5 分钟 | 知音楼推送表格给丁洋+尹荣荣 |
| 九凤上架助手 | `jiufeng_upload_daemon.py` | ~30s | 5~10 分钟 | 知音楼通知批量上架完成 |

---

## 意图关键词（供 classify_intent.py 参考）

| bot | 触发关键词示例 |
|-----|-------------|
| `selection` | 内购选品、跑选品、每周选品、选品任务、帮我选品 |
| `selection_upload` | 发送含「待上架明细」的知音楼在线表格链接（sheet_url 必填） |
| `replenishment` | 内购补货、跑补货、补货查询、缺货补货、帮我跑补货 |
| `new_product` | 内购上新、商品上新、帮我上新 |
| `upload` | 确认上架、商品上架、九凤上架、批量上架 |
