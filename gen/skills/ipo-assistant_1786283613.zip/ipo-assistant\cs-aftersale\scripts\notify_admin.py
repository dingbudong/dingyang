"""
知音楼 P2P 通知内购管理员
将售后工单信息推送给工号 215734
用法: python notify_admin.py --user_id xx --issue_type xx --description xx --ticket_id xx
"""
import sys, json, argparse, urllib.request
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import urllib.parse as _urllib_parse

APPKEY    = "120443374ae46e39"
APPSECRET = "9d5660aa73c2fa9e7ffd3c129d54e6c3"
APP_ID    = "838386470347636736"   # 内购商城智能客服机器人ID
YACH_HOST = "https://yach-oapi.zhiyinlou.com"
ADMIN_ID  = "215734"


def get_access_token() -> str:
    url = f"{YACH_HOST}/gettoken?appkey={APPKEY}&appsecret={APPSECRET}"
    with urllib.request.urlopen(url, timeout=10) as r:
        data = json.loads(r.read().decode('utf-8'))
    return data.get("obj", {}).get("access_token", "") or data.get("access_token", "")


def send_p2p(token: str, work_code: str, content: str):
    msg = json.dumps({"msgtype": "text", "text": {"content": content}}, ensure_ascii=False)
    form = _urllib_parse.urlencode({
        "access_token": token,
        "to_work_code": work_code,
        "app_id":       APP_ID,
        "message":      msg,
    }).encode("utf-8")
    req = urllib.request.Request(
        f"{YACH_HOST}/v1/single/message/send",
        data=form,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        resp = json.loads(r.read().decode('utf-8'))
    print(f"通知结果: {resp}")
    return resp


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--user_id",    default="unknown")
    p.add_argument("--issue_type", default="其他")
    p.add_argument("--description", default="")
    p.add_argument("--ticket_id",  default="")
    p.add_argument("--product",    default="")
    p.add_argument("--order_id",   default="")
    args = p.parse_args()

    token  = get_access_token()

    content = (
        f"【内购售后工单】\n"
        f"提交人：工号 {args.user_id}\n"
        f"工单编号：{args.ticket_id or '—'}\n"
        f"问题类型：{args.issue_type}\n"
        f"商品：{args.product or '—'}\n"
        f"订单号：{args.order_id or '—'}\n"
        f"描述：{args.description}\n"
        f"提交时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        f"请及时处理，感谢！"
    )
    send_p2p(token, ADMIN_ID, content)
