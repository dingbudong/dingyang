"""
九凤内购商城商品查询
用法: python query_product.py --keyword "商品关键词"
返回: JSON 商品信息列表

注意：API 正确参数名为 page_size（下划线），pageSize 无效。设 page_size=400 一次取全部。
"""
import sys, os, json, argparse, urllib.request, urllib.parse
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(SKILL_DIR, "scripts"))

from jiufeng_login import get_cookies, refresh_cookies, COOKIE_FILE

JIUFENG_BASE   = "https://udc.100tal.com"
JIUFENG_MOBILE = "https://pointmall.100tal.com"
GOODS_API      = f"{JIUFENG_BASE}/jiufeng/api/goods/list"


def _do_query(cookies: dict, keyword: str) -> dict:
    cookie_str = "; ".join(f"{k}={v}" for k, v in cookies.items())
    hdrs = {
        "Cookie": cookie_str,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json",
        "Referer": f"{JIUFENG_BASE}/jiufeng/goodsForSale/list",
    }
    # page_size=400 一次返回全部结果（API 支持最大 400 条）
    params = urllib.parse.urlencode({"name": keyword, "page": 1, "page_size": 400})
    url = f"{GOODS_API}?{params}"
    r = urllib.request.urlopen(urllib.request.Request(url, headers=hdrs), timeout=20)
    return json.loads(r.read().decode("utf-8"))


def query_products_by_keyword(keyword: str) -> list:
    cookies = get_cookies()
    data = _do_query(cookies, keyword)

    if data.get("errcode") != 0:
        try:
            os.remove(COOKIE_FILE)
        except Exception:
            pass
        cookies = refresh_cookies()
        data = _do_query(cookies, keyword)

    results = []
    for item in data.get("data", {}).get("list", []):
        sku_prices  = item.get("sku_prices", [])
        sp          = sku_prices[0] if sku_prices else {}
        raw_price   = int(sp.get("single_price", 0) or 0)
        raw_market  = int(sp.get("line_cash",    0) or 0)
        img_url = (item.get("main_pic") or item.get("icon") or
                   item.get("image_url") or item.get("img_url") or
                   item.get("pic") or item.get("cover_img") or
                   item.get("thumb") or "")
        stock_num      = item.get("stock_num", "")
        stock_sale_num = item.get("stock_sale_num", "")   # 实际可售量，优先于仓库总量
        status_name = item.get("status_name", "")
        if status_name and status_name not in ("在售", "上架", "已上架"):
            stock_status = status_name   # e.g. "已下架"
        else:
            try:
                # stock_sale_num = 仓库总量 * 可售比例，才是前台"当前无货"的判断依据
                avail = float(stock_sale_num) if stock_sale_num != "" else float(stock_num)
                stock_status = "有货" if avail > 0 else "暂无货"
            except (TypeError, ValueError):
                stock_status = ""
        sku_id = item.get("id", "")
        product_url = (f"{JIUFENG_MOBILE}/goodsDetail?clientGroup=91&id={sku_id}"
                       f"&promotion_id=0&order_source=104") if sku_id else ""
        results.append({
            "product_id":   item.get("id", ""),
            "product_name": item.get("name", ""),
            "price":        round(raw_price  / 100, 2),
            "market_price": round(raw_market / 100, 2),
            "stock":        stock_num,
            "stock_status": stock_status,
            "status":       item.get("status_name", "在售"),
            "image_url":    img_url,
            "product_url":  product_url,
        })
    return results


MALL_LINK = "https://t.tal.com/e3KJoD"
MALL_PATH = "（手机端知音楼→工作台→教师应用→好未来内购商城）"


def format_reply(keyword: str, products: list) -> str:
    import random as _r
    if not products:
        _no_result = _r.choice([
            f'「{keyword}」在内购商城暂时没找到，可能还没上架这款～\n如果你想要的话，提个补货申请就好，告诉我一声 😊',
            f'目前商城里没有「{keyword}」相关的商品，还没有上架。\n想要的话可以留个补货建议，我帮你记上 😊',
            f'「{keyword}」这个暂时没有，内购商城还没收录。\n有需要可以提补货申请，我来帮你跟进～',
        ])
        return f'{_no_result}\n🏪 内购商城入口：{MALL_LINK}\n![内购商城二维码](https://yach-static.zhiyinlou.com/online/person/1779503218959/79343BF9AFA2A679883BA3482474BE93/86852FE6-309F-429E-B758-3C7FCC0D2CC3.PNG)'

    _MAX_SHOW = 25  # 单次展示上限：每款含图片URL约240字，25款≈6000字，贴近Dify通道上限
    total = len(products)
    _truncated = total > _MAX_SHOW
    if _truncated:
        products = products[:_MAX_SHOW]
    _show = len(products)
    # 首行为服务端检测标记，展示前会被剥离，不显示给用户
    _marker = f'【内购商品查询结果】搜索：{keyword}，共 {total} 款'
    _suffix = f'（仅展示前 {_MAX_SHOW} 款，共 {total} 款）' if _truncated else ''
    _intros = [
        f'「{keyword}」相关的在商城找到 {_show} 款{_suffix}，给你看看～',
        f'找到了！「{keyword}」相关共 {_show} 款{_suffix}，都在这里：',
        f'内购商城里「{keyword}」共 {_show} 款{_suffix}，列一下：',
        f'「{keyword}」的话有 {_show} 款{_suffix}，给你整理了：',
    ]
    _qr_img = '![内购商城二维码](https://yach-static.zhiyinlou.com/online/person/1779503218959/79343BF9AFA2A679883BA3482474BE93/86852FE6-309F-429E-B758-3C7FCC0D2CC3.PNG)'
    lines = [_marker, '', _r.choice(_intros), f'🏪 内购商城入口：{MALL_LINK}', _qr_img, '']

    for i, p in enumerate(products, 1):
        market_str = f"  市场价：¥{p['market_price']:.2f}" if p['market_price'] else ""
        stock_str  = f"  {'✅' if p.get('stock_status') == '有货' else '⚠️'} {p['stock_status']}" if p.get("stock_status") else ""
        url_str    = f"\n🔗 [商品直达]({p['product_url']})" if p.get("product_url") else ""
        img_str    = f"\n![商品图片]({p['image_url']})" if p.get("image_url") else ""
        lines.append(
            f"{i}. {p['product_name']}\n"
            f"内购价：¥{p['price']:.2f}{market_str}{stock_str}{url_str}{img_str}\n"
        )

    return "\n".join(lines)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--keyword", required=True)
    p.add_argument("--json_output", action="store_true")
    args = p.parse_args()

    products = query_products_by_keyword(args.keyword)

    if args.json_output:
        print(json.dumps(products, ensure_ascii=False))
    else:
        print(format_reply(args.keyword, products))
