"""
内购物流轨迹查询
优先查 LS 系统（真实签收状态），备用快递100
用法: python query_logistics.py --express_no 快递单号 [--order_id 订单号]
"""
import sys, os, json, argparse, re, urllib.request, urllib.parse
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
cs_product_scripts = os.path.join(os.path.dirname(os.path.dirname(SCRIPT_DIR)), "cs-product", "scripts")
cs_order_scripts   = os.path.join(os.path.dirname(os.path.dirname(SCRIPT_DIR)), "cs-order", "scripts")
sys.path.insert(0, cs_product_scripts)
sys.path.insert(0, cs_order_scripts)

CACHE_DIR   = r"D:\windows powershells\ips_cache"
COOKIE_FILE = os.path.join(CACHE_DIR, "ls_cookies.json")
LS_BASE     = "https://app.xesv5.com"


def load_ls_cookies():
    if not os.path.exists(COOKIE_FILE):
        return {}
    with open(COOKIE_FILE, encoding='utf-8') as f:
        raw = json.load(f)
    return raw if isinstance(raw, dict) else {c['name']: c['value'] for c in raw if c.get('name')}


def _ls_post(cookies, extra_params, include_pending=False):
    """向 LS /order/query/list 发起一次请求，返回 list 或 None。
    include_pending=True 时额外包含待打单(status=1)，用于按订单号查未发货订单。"""
    cstr = "; ".join(f"{k}={v}" for k, v in cookies.items())
    base = {
        "curpage": 1, "size": 5,
        "login_tenant_id": 20,
        "goods_owner[0]": 105,
        "order_status[0]": 2,
        "order_status[1]": 3,
        "order_status[2]": 4,
    }
    if include_pending:
        base["order_status[3]"] = 1
    base.update(extra_params)
    data = urllib.parse.urlencode(base).encode()
    req = urllib.request.Request(
        f"{LS_BASE}/ls-api/order/query/list",
        data=data,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Cookie": cstr,
            "Referer": f"{LS_BASE}/ls-web/",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read().decode('utf-8'))
    except Exception:
        return None
    if resp.get("stat") != 1:
        return None
    return resp.get("data", {}).get("list") or None


def query_via_ls(express_no="", order_id=""):
    """
    查 LS 物流状态。
    返回 dict {express_num, tracks_info, status_name}，找不到返回 None。
    LS 以九凤订单号存为 source_codes，格式是原号码前面加 "1"。
    """
    cookies = load_ls_cookies()
    if not cookies:
        return None

    items = None
    if express_no:
        items = _ls_post(cookies, {"express_nums": express_no})
    if not items and order_id:
        # include_pending=True：同时搜索待打单（尚未发货）的订单
        items = _ls_post(cookies, {"source_codes": f"1{order_id}"}, include_pending=True)
    if not items:
        return None

    item = items[0]
    return {
        "express_num": item.get("express_num", express_no),
        "tracks_info": item.get("tracks_info", ""),
        "status_name": item.get("delivery_status_name", ""),
    }


def format_ls_reply(express_no, ls_data):
    tracks      = ls_data.get("tracks_info", "")
    en          = ls_data.get("express_num", "") or express_no
    status_name = ls_data.get("status_name", "")

    # 待打单/待发货：LS 有记录但快递单号为空（尚未生成运单）
    if not ls_data.get("express_num") and not tracks:
        status_str = f"（{status_name}）" if status_name else ""
        return (
            f"您的订单已确认，目前正在备货中，尚未发货 📦\n"
            f"物流状态：{status_name or '待打单'}\n"
            f"快递发出后您可以凭快递单号查询物流进度，请耐心等待。"
        )

    # 已签收：delivery_status_name 明确说已签收，或轨迹文本含"已签收/签收成功/已妥投"
    # 排除"准备签收"、"请签收"等派送中提示误判
    is_signed = (
        "已签收" in status_name
        or bool(re.search(r'已签收|签收成功|已妥投', tracks))
    ) and "准备签收" not in tracks
    if is_signed:
        m = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})', tracks)
        time_str = f"于 {m.group(1)} " if m else ""
        return (
            f"您的快递已{time_str}签收 ✅\n"
            f"快递单号：{en}\n"
            f"物流详情：{tracks}"
        )

    # 在途中 / 其他有轨迹状态
    status_str = f"（{status_name}）" if status_name else ""
    tracks_str = f"\n最新动态：{tracks}" if tracks else ""
    return (
        f"您的快递正在配送中{status_str} 🚚\n"
        f"快递单号：{en}"
        f"{tracks_str}"
    )


def query_via_kuaidi100(express_no, company_code=""):
    try:
        if not company_code:
            url = f"https://www.kuaidi100.com/autonumber/autoComNum?text={express_no}"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as r:
                auto = json.loads(r.read().decode('utf-8')).get("auto", [{}])
                company_code = auto[0].get("comCode", "auto") if auto else "auto"

        url = f"https://www.kuaidi100.com/query?type={company_code}&postid={express_no}&id=1&valicode=&temp=0.1"
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0",
            "Referer": "https://www.kuaidi100.com/"
        })
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode('utf-8'))
    except Exception as e:
        return {"status": "error", "message": str(e)}


def format_kuaidi100_reply(express_no, data):
    if not data or data.get("status") in ["error", "failed"]:
        return (
            f"暂未查到快递轨迹信息，可能刚刚揽收。\n"
            f"快递单号：{express_no}\n"
            "您可稍后再查，或联系商家确认发货状态。"
        )

    traces = data.get("data", [])
    state  = data.get("state", "0")
    company = data.get("com", "").upper()

    state_map = {
        "0": "运输中", "1": "揽收", "2": "疑难", "3": "已签收",
        "4": "已退签", "5": "派件中", "6": "退回", "7": "转寄",
    }
    if "3" in str(state):
        sign_time = traces[0].get("time", "") if traces else ""
        return f"您的快递已于 {sign_time} 签收 ✅\n[{company} {express_no} | 已完成]"

    latest = traces[0] if traces else {}
    latest_time    = latest.get("time", "")
    latest_context = latest.get("context", "")
    location = ""
    if "【" in latest_context:
        m = re.search(r'【([^】]+)】', latest_context)
        location = f"，目前在【{m.group(1)}】" if m else ""

    return (
        f"您的快递正在{state_map.get(str(state), '运输中')}{location} 🚚\n"
        f"[{company} {express_no}]\n"
        f"最新动态：{latest_time} {latest_context}"
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--express_no", default="")
    p.add_argument("--order_id",   default="")
    p.add_argument("--json_output", action="store_true")
    args = p.parse_args()

    express_no = args.express_no
    order_id   = args.order_id
    order_info = None

    # 有订单号先从九凤拿快递单号和状态
    if order_id or (not express_no):
        try:
            from query_order import query_orders
            orders = query_orders("", order_id)
            if orders:
                order_info = orders[0]
                if not express_no:
                    express_no = order_info.get("express_no", "")
        except Exception:
            pass

    # 九凤已标记签收 → 快速返回
    if order_info:
        ship_status = order_info.get("ship_status", "")
        pay_status  = order_info.get("pay_status", "")
        if "签收" in ship_status or "签收" in pay_status or "已完成" in pay_status:
            print(
                f"您的快递已签收 ✅\n"
                f"快递单号：{express_no or '—'}\n"
                f"订单状态：{pay_status}\n"
                f"商品：{order_info.get('product', '—')}"
            )
            sys.exit(0)
        # 九凤订单存在但无快递单号 → 尚未发货
        if order_id and not express_no:
            print(
                f"您的订单已确认，目前正在备货中，尚未发货 📦\n"
                f"订单状态：{pay_status}\n"
                f"商品：{order_info.get('product', '—')}\n"
                f"快递发出后您可以凭快递单号查询物流进度，请耐心等待。"
            )
            sys.exit(0)

    if not express_no and not order_id:
        print("未找到快递单号，请提供快递单号或订单号后重试。")
        sys.exit(0)

    # 优先 LS 系统（真实签收状态）
    ls_data = query_via_ls(express_no, order_id)
    if ls_data:
        if args.json_output:
            print(json.dumps(ls_data, ensure_ascii=False))
        else:
            print(format_ls_reply(express_no, ls_data))
        sys.exit(0)

    # LS 无结果 → 快递100兜底
    if not express_no:
        print("未找到快递单号，请提供快递单号或订单号后重试。")
        sys.exit(0)

    data = query_via_kuaidi100(express_no)
    if args.json_output:
        print(json.dumps({"express_no": express_no, "data": data}, ensure_ascii=False))
    else:
        print(format_kuaidi100_reply(express_no, data))
