---
name: ipo-assistant
description: >
  内购智能助手——内购商城智能客服。
  当用户说"内购助手"、"内购客服"、"内购数据"时触发。
  客服模块：商品查询/订单查询/物流查询/售后处理/补货建议。
  所有子功能独立维护在本文件夹内，不影响其他任何已有 skills。
triggers:
  - 内购助手
  - 内购客服
  - 内购数据
  - ipo-assistant
user_invocable: true
---

# 内购智能助手 (ipo-assistant)

## 模块导航

| 模块 | 子 skill | 功能 | 触发场景 |
|------|----------|------|---------|
| **智能客服** | `board-server` | GLM tool_use Agent，一次 HTTP 调用全自动处理 | 用户在知音楼对话 |
| 商品查询 | `cs-product` | 查询九凤内购商品信息 | "有没有某某商品" "价格是多少" |
| 订单查询 | `cs-order` | 查询九凤订单状态 | "我的订单" "什么时候发货" |
| 物流查询 | `cs-logistics` | 抓取快递轨迹 | "我的快递到哪了" "物流信息" |
| 售后处理 | `cs-aftersale` | 记录投诉工单并通知 | "商品坏了" "礼品失效" "退换货" |
| 商品建议 | `cs-suggestion` | 补货申请/商品建议 | "希望购买" "能补货吗" |
| **任务委派** | `cs-delegate` | P2P+Teable 触发各数字伙伴守护进程 | 丁洋老师确认后触发补货/选品/上新/上架 |
| 视频生成 | `cs-video` | happyhorse 文生/图生视频 | "生成视频" "制作视频" "帮我做个视频" |

---

## 认证信息（本助手专属，勿混用其他 skills）

```
# 内购商城智能客服 数字伙伴（新）
机器人ID:   838386470347636736
appkey:     120443374ae46e39
appsecret:  9d5660aa73c2fa9e7ffd3c129d54e6c3
Host:       https://yach-oapi.zhiyinlou.com
Web URL:    https://yach-capi.zhiyinlou.com/682/nv/api/view/17776959109985

# 九凤后台（内购商城）
URL:        https://udc.100tal.com/jiufeng/
账号:       215734
密码:       Ding-1590152
Cookie:     D:\windows powershells\ips_cache\jiufeng_cookies.json

# LS供应链系统
URL:        https://app.xesv5.com/ls-web/
账号:       215734
密码:       Ding-1590152
Cookie:     D:\windows powershells\ips_cache\ls_cookies.json

# Teable 看板数据库
Base:       https://yach-teable.zhiyinlou.com/base/bseFFoyVD6WgFbKmzDN
Token:      teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw=

# LLM 多后端（6 个，自动故障切换）
APP_ID:     300000485
APP_KEY:    61b228c575d42cbd37a266636c5b7364
Endpoint:   http://ai-service.tal.com/openai-compatible/v1/chat/completions
后端顺序:   claude-sonnet-4.6 → kimi-k2.6 → glm-5.1 → deepseek-v4-pro → claude-opus-4.7 → qwen3.5-omni-flash
容灾:       任一后端 429/403/502/503/504 自动切换下一个，全部失败才降级关键词兜底

```

---

## 获取知音楼 access_token

```bash
TOKEN_RESP=$(curl -s "https://yach-oapi.zhiyinlou.com/gettoken?appkey=120443374ae46e39&appsecret=9d5660aa73c2fa9e7ffd3c129d54e6c3")
ACCESS_TOKEN=$(echo "$TOKEN_RESP" | python -c "import sys,json; print(json.load(sys.stdin)['obj']['access_token'])")
```

---

## 使用方式

### 客服模式
```
用户在知音楼数字伙伴发消息
→ Dify chatflow（dify_v6.yml）解析 sys 变量，POST /api/agent/chat
→ board-server GLM tool_use Agent 自主决策
→ 调用工具查询数据，直接返回自然语言回复
→ 无法回答 → 引导联系丁洋老师（215734）
```

> **Dify HTTP 节点固定 URL**：`https://wmd.tal.com/ipo-cs/api/agent/chat`
> 由 K8s 容器平台（cloud.tal.com）托管，APISIX wmd.tal.com 域名路由，生产稳定地址（2026-07-01 起，原 ngrok 地址废弃）。

### Dify 工作流 sys 变量（dify_v6.yml）

| 变量 | 用途 |
|------|------|
| `sys.group_id` | 真实知音楼群 ID，直接路由，无需扫群 |
| `sys.chat_type` | `"group"` / 其他，判断群聊或私聊 |
| `sys.group_name` | 群名称，注入 @丁洋 通知（"来自 XX 群"） |
| `sys.dialog_count` | 对话轮数，≥4 轮自动升级人工 |
| `sys.app_id` | 应用 ID，写入日志支持多实例追踪 |
| `sys.workflow_run_id` | 本次运行 ID，日志前8位，Dify 侧可对齐 |

> **最新 Dify 工作流文件**：`C:\Users\dingyang3\Desktop\内购商城智能客服-wmd.yml`

## 文件结构

```
ipo-assistant/
├── SKILL.md              ← 本文件（主入口）
├── board-server/         ← HTTP 服务核心（GLM Agent + 委派机制）
├── cs-delegate/          ← 任务委派（P2P+Teable 触发守护进程）★
├── cs-product/           ← 商品查询
├── cs-order/             ← 订单查询
├── cs-logistics/         ← 物流查询
├── cs-aftersale/         ← 售后处理
├── cs-suggestion/        ← 商品建议/补货
└── cs-video/             ← AI 视频生成（happyhorse-1.0-t2v / i2v）
```

> 所有更新均在本 ipo-assistant 文件夹内进行，绝不修改其他已有 skills。
