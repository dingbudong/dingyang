---
name: ipo-cs-product
description: >
  内购商品查询——根据用户提供的商品关键词，登录九凤后台商品管理系统，
  精准匹配商品并返回商品名称、内购价格、库存状态、手机端直达链接和商品图片。
  由 board-server 路由触发，也可独立调用。
---

# 内购商品查询 (cs-product)

## 职责

接收商品关键词，登录九凤后台，查询内购商城商品信息，返回给用户。

---

## ⚠️ 强制要求

**商品价格/库存/信息必须执行 `query_product.py` 脚本实时查询，绝对不能凭记忆、缓存或推测回答。**  
即使商品名称似乎已知，也必须先运行脚本确认当前上架状态和实时价格。

---

## 执行流程

### 查询商品信息

```python
python "C:\Users\dingyang3\.claude\skills\ipo-assistant\cs-product\scripts\query_product.py" \
  --keyword "商品品牌名/产品名主体"
```

**关键词提取规则（在 server.py `_execute_tool` 中自动处理）：**
- 只保留品牌名、产品名主体或年级描述词，自动剥离品类词
- `"摩比的书籍有哪些"` → keyword=`"摩比"`
- `"学而思的玩具"` → keyword=`"学而思"`
- `"5年级的书"` → keyword=`"五年级"`（阿拉伯数字自动转中文）
- `"摩比爱数学"` → keyword=`"摩比爱数学"`；`"摩比分级数学"` → keyword=`"摩比分级数学"`（两者是不同的品，不可互换）
- `"ABCtime"` → keyword=`"ABCtime"`（上册）；`"Reading A-Z"` → keyword=`"Reading"`（下册）；`"RAZ"` → keyword=`"RAZ"`（单词王点读大书）；三者独立，不可合并

`query_product.py` 内部自动处理登录：读取 `jiufeng_cookies.json`（无文件时触发 SSO 自动登录），  
若 API 返回认证失败则自动删除旧 Cookie 并重新登录，整个过程无需人工干预。

**查询参数：** `page_size=400`（注意下划线，`pageSize` 无效）；一次请求返回全量结果。

---

## 展示规则

工具返回数据后由 LLM 推理并生成最终回复，链接、图片、库存状态原样保留。

- 首行为服务端检测标记（`【内购商品查询结果】...`），展示前自动剥离，用户不可见
- 开头为随机自然语句（如"找到了！「xxx」相关共 N 款，都在这里："）

| 结果数量 | 展示格式 |
|----------|---------|
| ≤10 款 | 逐条展示：内购价、市场价、库存状态（✅/⚠️）、`🔗 商品直达：` 手机端直链、商品图片 |
| >10 款 | 紧凑文字列表（`序号. 商品名 — 内购价¥XX（市场价¥XX）  ✅/⚠️ 状态`），不嵌图片和链接，防止消息截断 |
| 无结果 | LLM 生成自然回复 + 引导补货建议 |

底部始终附：`🏪 内购商城入口：https://t.tal.com/e3KJoD`

---

## 字段说明

### 库存状态（stock_status）

`stock_num`（库存数量）+ `status_name`（上架状态）联合判断：

| 条件 | 显示 |
|------|------|
| `status_name` 不在 {"在售","上架","已上架"} | ⚠️ {status_name}（如 "已下架"、"待上架"） |
| `status_name` 正常 且 `stock_sale_num > 0` | ✅ 有货 |
| `status_name` 正常 且 `stock_sale_num == 0` | ⚠️ 暂无货 |

> ⚠️ **必须用 `stock_sale_num`（实际可售量），不能用 `stock_num`（仓库总量）**  
> 示例：ABCtime 一级上册 `stock_num=1` 但 `stock_sale_num=0`（80% 可售比例截断）→ 前台显示"当前无货"；若用 `stock_num` 会错误显示"有货"。

### 商品直达链接（product_url）

```
https://pointmall.100tal.com/goodsDetail?clientGroup=91&id={sku_id}&promotion_id=0&order_source=104
```

⚠️ **重要：`id` 必须用九凤 API 的 `id` 字段（SKU id），绝对不能用 `spu_id`**  
两套编号不重叠——`spu_id` 在 pointmall 里对应完全不同的商品（已踩坑验证）。

| API 字段 | 示例值 | 用途 |
|----------|--------|------|
| `id` / `sku_id` | 1004369 | ✅ pointmall 商品详情 URL 用这个 |
| `spu_id` | 1002812 | ❌ 不能用，与 pointmall id 不重叠 |

### 商城入口 vs 商品直达

| 地址 | 标签 | 说明 |
|------|------|------|
| `https://t.tal.com/e3KJoD` | `🏪 内购商城入口：` | 商城首页（底部固定附加） |
| `https://pointmall.100tal.com/goodsDetail?...` | `🔗 商品直达：` | 手机端单品详情页（≤10款每条附加） |

---

## 依赖说明

| 文件 | 说明 |
|------|------|
| `scripts/jiufeng_login.py` | 九凤 SSO 登录（SSO→UDC 纯 HTTP 链路），含文件锁防并发 |
| `scripts/query_product.py` | 纯 HTTP API 查询商品列表，内置 Cookie 懒加载 + 失败重登 |

## Cookie 文件

`D:\windows powershells\ips_cache\jiufeng_cookies.json`  
（与 jiufeng_upload 共用同一文件；只读加载，API 返回 errcode≠0 时才触发重新登录）
