# cs-video — AI 视频生成

智能客服视频生成模块，支持文生视频和图生视频两种模式。

## API 配置

```
Endpoint:    http://apx-api.tal.com/v1/async/chat
Auth:        api-key: 61b228c575d42cbd37a266636c5b7364
文生视频模型: happyhorse-1.0-t2v   X-APX-Model: happyhorse-1.0-t2v
图生视频模型: happyhorse-1.0-i2v   X-APX-Model: happyhorse-1.0-i2v

结果查询:    GET http://apx-api.tal.com/v1/async/results/{task_id}
             同样需要 api-key 和 X-APX-Model 请求头
```

## 两种生成模式

| 模式 | 触发词示例 | 模型 | 参数 |
|------|-----------|------|------|
| 文生视频 | 生成视频/制作视频/帮我做个视频 | happyhorse-1.0-t2v | prompt + resolution + ratio + duration |
| 图生视频 | 图片转视频/把这张图做成视频 | happyhorse-1.0-i2v | prompt + img_url（首帧），不支持 ratio |

## 参数说明

### 文生视频（happyhorse-1.0-t2v）

参数放在 `extra_body.parameters` 中：
- `resolution`：分辨率，如 `720P`（默认）、`1080P`
- `ratio`：宽高比，如 `16:9`（默认）、`9:16`
- `duration`：时长（秒），如 `5`（默认）

### 图生视频（happyhorse-1.0-i2v）

参数放在 `extra_body.input.media` 中：
- 图片以 `{"url": "...", "type": "first_frame"}` 形式传入
- **不支持 ratio 参数**，视频宽高比自动跟随输入图像

## 脚本调用

```bash
# 文生视频
python cs-video/scripts/video_api.py --mode text --prompt "下雨天" --resolution 720P --ratio 16:9 --duration 5

# 图生视频（首帧）
python cs-video/scripts/video_api.py --mode image --prompt "一个小猫正在喝水" --img_url "https://..."
```

输出格式（stdout）：
```
VIDEO_URL=https://...
TASK_ID=xxx
```

## 异步轮询

两个模型均为异步生成，提交后轮询结果接口（每 15 秒查询一次）。

| status 值 | 含义 |
|-----------|------|
| 1 | submitted（已提交） |
| 2 | processing（生成中） |
| 3 | success → `response.video_url` 为视频链接 |
| 4 | failed → `response.message` 为错误原因 |

## 视频推送路径

视频生成完成后下载到本地 `ips_cache/static/videos/video_{jid[:8]}.mp4`，知音楼消息用 ngrok `/static/videos/` URL。

> `/static/` 路由由 `router.py` 直接读文件返回，无 ngrok 浏览器拦截，知音楼可正常播放。

## 文件结构

```
cs-video/
├── SKILL.md
└── scripts/
    └── video_api.py
```
