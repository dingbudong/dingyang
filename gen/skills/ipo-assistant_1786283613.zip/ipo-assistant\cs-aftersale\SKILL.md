---
name: ipo-cs-aftersale
description: >
  内购售后处理——当用户反映商品损坏、丢失、质量问题、退换货等售后情况时，
  引导用户通过"流程中心"提交正式售后申请，并告知管理员联系方式。
  由 board-server 路由触发，也可独立调用。
---

# 内购售后处理 (cs-aftersale)

## 职责

识别售后相关诉求，立即引导用户前往官方售后入口提交申请。

> **售后申请官方入口：流程中心 → 搜索"内购商城售后申请"**

---

## 触发关键词

以下任一情况均路由到本模块：

| 类别 | 关键词示例 |
|------|-----------|
| 商品损坏 | 坏了、坏掉、破损、烂了、发霉、撕了、破了 |
| 商品丢失 | 丢了、丢失、没收到、包裹丢了 |
| 异物/污渍 | 有异物、有贴纸、污渍、脏了 |
| 质量问题 | 质量问题、质量不好、有问题 |
| 缺件 | 缺件、少件、漏发 |
| 退换货 | 退货、退款、换货、售后 |
| 投诉 | 投诉 |

---

## 回复内容（固定模板）

```
您好，针对您反映的情况，请按以下路径提交售后申请：

流程中心 → 搜索【内购商城售后申请】
👉 点击直达：https://oa.zhiyinlou.com/v20/formRender?wfId=1475

填写申请后，内购管理员会尽快跟进处理，请注意知音楼消息通知。

如填写遇到问题，可联系内购管理员（知音楼工号：215734）。
```

---

## 辅助脚本（可独立调用）

如需在 Claude 对话中手动记录工单或通知管理员，可使用以下脚本：

**记录工单到 Teable：**
```python
python "C:\Users\dingyang3\.claude\skills\ipo-assistant\cs-aftersale\scripts\record_aftersale.py" \
  --user_id "用户工号" \
  --issue_type "问题类型" \
  --product "商品名称" \
  --order_id "订单号" \
  --description "用户原始描述"
```

**通知内购管理员（知音楼P2P）：**
```python
python "C:\Users\dingyang3\.claude\skills\ipo-assistant\cs-aftersale\scripts\notify_admin.py" \
  --user_id "用户工号" \
  --issue_type "问题类型" \
  --description "用户描述" \
  --teable_record_id "工单ID"
```

---

## 依赖说明

| 文件 | 说明 |
|------|------|
| `scripts/record_aftersale.py` | 写入 Teable 工单（手动调用） |
| `scripts/notify_admin.py` | 知音楼 P2P 通知管理员（手动调用） |

---

## Teable 工单表配置

| 配置 | 值 |
|------|-----|
| Base URL | `https://yach-teable.zhiyinlou.com` |
| Base ID | `bseFFoyVD6WgFbKmzDN` |
| Token | `teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw=` |
| 表名 | `内购售后工单` (首次运行自动创建) |

---

## 知音楼通知配置

```
appkey:    120443374ae46e39
appsecret: 9d5660aa73c2fa9e7ffd3c129d54e6c3
app_id:    838386470347636736   # 内购商城智能客服机器人
管理员工号: 215734
```

> **注意**：此 appkey 必须用 `POST /v1/single/message/send`（form-data：access_token / to_work_code / app_id / message）。
> `/v1/message/send_to_user`（JSON）对此 appkey 返回 10011"不支持的路由"。

---

## 依赖说明

| 文件 | 说明 |
|------|------|
| `scripts/record_aftersale.py` | 写入 Teable 工单 |
| `scripts/notify_admin.py` | 知音楼 P2P 通知管理员 |
