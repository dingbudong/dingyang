---
name: ipo-cs-suggestion
description: >
  内购商品建议/补货申请——当用户表达断货、缺货、想要某商品时，
  立即引导填写【微瑕期望商品收集表】，告知统一征集渠道。
  由 board-server 路由触发，也可独立调用。
---

# 内购商品建议/补货申请 (cs-suggestion)

## 职责

识别补货/期望商品诉求，引导用户填写收集表，统一汇总后跟进。

---

## 触发关键词

以下任一情况均路由到本模块：

| 类别 | 关键词示例 |
|------|-----------|
| 补货/断货 | 补货、断货、缺货、没货了、没有货 |
| 期望商品 | 建议、期望商品、想要、希望有、希望上架 |
| 询问上架 | 什么时候有货、什么时候上架、何时有 |

---

## 回复内容（固定模板）

```
感谢您的反馈！如果您希望内购商城增加某款商品或某商品断货了，请填写补货/期望商品收集表：

【微瑕期望商品收集表】
https://yach-doc-shimo.zhiyinlou.com/sheets/8Nk6MWvrBdTVo4qL/MODOC/

填写后，内购管理员会汇总后统一跟进，感谢您的建议！
```

---

## 重要链接

| 资源 | 链接 |
|------|------|
| 期望商品收集表 | https://yach-doc-shimo.zhiyinlou.com/sheets/8Nk6MWvrBdTVo4qL/MODOC/ |
| 🏪 内购商城入口 | https://t.tal.com/e3KJoD |
| 商城路径 | 手机端知音楼→工作台→教师应用→好未来内购商城 |

---

## 辅助脚本（可独立调用）

如需在 Claude 对话中手动记录建议到 Teable：

```python
python "C:\Users\dingyang3\.claude\skills\ipo-assistant\cs-suggestion\scripts\record_suggestion.py" \
  --user_id "用户工号" \
  --product "商品名称" \
  --need_type "新品/补货" \
  --description "用户原始描述"
```

---

## 依赖说明

| 文件 | 说明 |
|------|------|
| `scripts/record_suggestion.py` | 写入 Teable 建议表（手动调用） |

---

## Teable 商品建议表配置

| 配置 | 值 |
|------|-----|
| Base ID | `bseFFoyVD6WgFbKmzDN` |
| Token | `teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw=` |
| 表名 | `内购商品建议` (首次运行自动创建) |

