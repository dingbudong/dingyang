"""
内购商城销售额查询（Teable 内购订单明细表）
查询指定日期范围内的订单，汇总销售额/单量
用法: python query_sales.py --period today|yesterday|week|month [--date_from xx --date_to xx]
"""
import sys, os, json, argparse, urllib.request, time
from datetime import datetime, timedelta

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

TEABLE_BASE  = "https://yach-teable.zhiyinlou.com"
TEABLE_TOKEN = "teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw="
TEABLE_TABLE = "tblWh60leD6kYVW7Crl"   # 内购订单明细
TAKE         = 500

CACHE_FILE = r"D:\windows powershells\ips_cache\sales_cache.json"
CACHE_TTL  = 1800   # 30 分钟


def _load_cache(key: str):
    try:
        with open(CACHE_FILE, encoding="utf-8") as f:
            cache = json.load(f)
        entry = cache.get(key)
        if entry and time.time() - entry.get("cached_at", 0) < CACHE_TTL:
            return entry["result"]
    except Exception:
        pass
    return None


def _save_cache(key: str, result: dict):
    try:
        cache = {}
        if os.path.exists(CACHE_FILE):
            with open(CACHE_FILE, encoding="utf-8") as f:
                cache = json.load(f)
        cache[key] = {"result": result, "cached_at": time.time()}
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False)
    except Exception:
        pass


def _date_range(period: str):
    today = datetime.now().date()
    if period == "today":
        return str(today), str(today)
    if period == "yesterday":
        y = today - timedelta(days=1)
        return str(y), str(y)
    if period == "week":
        start = today - timedelta(days=today.weekday())
        return str(start), str(today)
    if period == "month":
        start = today.replace(day=1)
        return str(start), str(today)
    return str(today), str(today)


def _query_teable(date_from: str, date_to: str):
    hdrs = {
        "Authorization": f"Bearer {TEABLE_TOKEN}",
        "Accept": "application/json",
    }
    total_amount = 0.0
    total_qty    = 0
    order_nos    = set()
    offset       = 0

    while True:
        url = (f"{TEABLE_BASE}/api/table/{TEABLE_TABLE}/record"
               f"?fieldKeyType=name&take={TAKE}&skip={offset}")
        try:
            req = urllib.request.Request(url, headers=hdrs)
            with urllib.request.urlopen(req, timeout=30) as r:
                data = json.loads(r.read().decode())
        except Exception as e:
            print(f"[query_sales] Teable 请求失败 offset={offset}: {e}", file=sys.stderr)
            break

        records = data.get("records", [])
        if not records:
            break

        for rec in records:
            fields   = rec.get("fields", {})
            rec_date = str(fields.get("下单日期", "") or "")[:10]
            if not rec_date or rec_date < date_from or rec_date > date_to:
                continue
            status = fields.get("订单状态", "") or ""
            refund = fields.get("退款状态", "") or ""
            if status not in {"配送中", "已确认", "已完成"}:
                continue
            if refund and refund != "未退款":
                continue
            total_amount += float(fields.get("兑换价格元", 0) or 0)
            total_qty    += int(fields.get("数量", 0) or 0)
            order_no = fields.get("三方订单号", "") or ""
            if order_no:
                order_nos.add(order_no)

        offset += len(records)
        total_records = int(data.get("total", 0) or 0)
        if offset >= total_records:
            break

    return round(total_amount, 2), len(order_nos), total_qty


def query_sales(period: str = "today", date_from: str = "", date_to: str = "",
                use_cache: bool = True) -> dict:
    if not date_from:
        date_from, date_to = _date_range(period)

    cache_key = f"{period}_{date_from}_{date_to}"
    if use_cache:
        cached = _load_cache(cache_key)
        if cached:
            return cached

    total_amount, total_orders, total_qty = _query_teable(date_from, date_to)

    result = {
        "period":       period,
        "date_from":    date_from,
        "date_to":      date_to,
        "total_orders": total_orders,
        "total_qty":    total_qty,
        "total_amount": total_amount,
    }
    _save_cache(cache_key, result)
    return result


def format_reply(result: dict) -> str:
    period_name = {
        "today":     "今日",
        "yesterday": "昨日",
        "week":      "本周",
        "month":     "本月",
    }.get(result["period"], "")
    date_str = (result["date_from"] if result["date_from"] == result["date_to"]
                else f"{result['date_from']} ~ {result['date_to']}")
    return (
        f"【{period_name}内购销售统计】{date_str}\n\n"
        f"销售订单量：{result['total_orders']} 单\n"
        f"销售数量：{result['total_qty']} 件\n"
        f"销售额：¥{result['total_amount']:.2f}\n\n"
        f"（数据来源：Teable 内购订单明细，仅智能内容+未来学校，已排除退款/取消/已退款）"
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--period",    default="today",
                   choices=["today", "yesterday", "week", "month"])
    p.add_argument("--date_from", default="")
    p.add_argument("--date_to",   default="")
    p.add_argument("--no_cache",  action="store_true")
    p.add_argument("--json_output", action="store_true")
    args = p.parse_args()

    result = query_sales(args.period, args.date_from, args.date_to,
                         use_cache=not args.no_cache)
    if args.json_output:
        print(json.dumps(result, ensure_ascii=False))
    else:
        print(format_reply(result))
