"""
批量把「产品文档知识库」表里每条记录对应的知音楼文档内容抓取下来，
写入「内容」字段（longText）。
运行前需已完成 yach-cli login。
"""
import sys, os, json, time, subprocess, requests, urllib3
urllib3.disable_warnings()
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

TEABLE_BASE  = "https://yach-teable.zhiyinlou.com"
TEABLE_TOKEN = "teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw="
TABLE_ID     = "tblBwsedV4x4Zs6tHw5"
H = {
    "Authorization": f"Bearer {TEABLE_TOKEN}",
    "Content-Type":  "application/json",
}

# ── 1. 确保「内容」字段存在 ─────────────────────────────────────────
def ensure_content_field():
    r = requests.get(f"{TEABLE_BASE}/api/table/{TABLE_ID}/field", headers=H, verify=False)
    fields = r.json()
    for f in fields:
        if f.get("name") == "内容":
            print(f"[字段] 「内容」字段已存在: {f['id']}")
            return f["id"]
    # 新建 longText 字段
    r2 = requests.post(
        f"{TEABLE_BASE}/api/table/{TABLE_ID}/field",
        headers=H, verify=False,
        json={"name": "内容", "type": "longText"}
    )
    data = r2.json()
    fid = data.get("id") or data.get("data", {}).get("id", "")
    print(f"[字段] 已创建「内容」字段: {fid} (status={r2.status_code})")
    return fid

# ── 2. 拉取全部记录 ──────────────────────────────────────────────────
def fetch_all_records():
    records, offset = [], 0
    while True:
        r = requests.get(
            f"{TEABLE_BASE}/api/table/{TABLE_ID}/record"
            f"?take=100&skip={offset}&fieldKeyType=name",
            headers=H, verify=False
        )
        data = r.json()
        batch = data.get("records", [])
        records.extend(batch)
        print(f"[拉取] 已获取 {len(records)} 条...")
        if len(batch) < 100:
            break
        offset += 100
    return records

# ── 3. 用 yach-cli 读文档正文 ────────────────────────────────────────
def fetch_doc_content(url: str) -> str:
    def _extract(raw: str) -> str:
        """从 yach-cli JSON 响应或纯文本中提取正文"""
        raw = raw.strip()
        if not raw:
            return ""
        # yach-cli 返回 JSON 结构：{"code":200,"obj":{"content":"..."}}
        try:
            data = json.loads(raw)
            # 兼容多种结构
            content = (data.get("obj") or {}).get("content") \
                   or (data.get("data") or {}).get("content") \
                   or data.get("content") \
                   or ""
            if content:
                return str(content)
        except Exception:
            pass
        # 不是 JSON 或解析失败，当作纯文本
        if not raw.startswith("{") and not raw.startswith("["):
            return raw
        return ""

    try:
        result = subprocess.run(
            ["yach-cli", "--for-user", "doc", "doc-content", "--file-url", url],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=60
        )
        content = _extract(result.stdout)
        if not content:
            # 尝试 doc-md
            result2 = subprocess.run(
                ["yach-cli", "--for-user", "doc", "doc-md", "--file-url", url],
                capture_output=True, text=True, encoding="utf-8",
                errors="replace", timeout=60
            )
            content = _extract(result2.stdout)
        return content[:8000] if content else ""
    except subprocess.TimeoutExpired:
        return ""
    except Exception:
        return ""

# ── 4. 更新记录的「内容」字段 ────────────────────────────────────────
def update_record(rec_id: str, content: str):
    r = requests.patch(
        f"{TEABLE_BASE}/api/table/{TABLE_ID}/record/{rec_id}?fieldKeyType=name",
        headers=H, verify=False,
        json={"record": {"fields": {"内容": content}}}
    )
    return r.status_code

# ── 主流程 ───────────────────────────────────────────────────────────
def main():
    print("=== 产品文档知识库 批量内容填充 ===\n")

    ensure_content_field()
    print()

    records = fetch_all_records()
    print(f"\n共 {len(records)} 条记录，开始逐条抓取文档内容...\n")

    ok, skip, fail = 0, 0, 0
    for i, rec in enumerate(records):
        fields  = rec.get("fields", {})
        name    = fields.get("产品名称", "")
        url     = fields.get("文档链接", "").strip()
        rec_id  = rec.get("id", "")
        existing = fields.get("内容", "")

        # 跳过已有有效纯文本内容（不是 JSON 响应包）
        existing_stripped = existing.strip().replace('\n', '').replace(' ', '')
        is_json_wrapper = existing_stripped.startswith('{"code"') or existing_stripped.startswith('{"msg"')
        if existing and len(existing) > 50 and not is_json_wrapper:
            print(f"[{i+1}/{len(records)}] 跳过（已有内容）: {name}")
            skip += 1
            continue

        if not url:
            print(f"[{i+1}/{len(records)}] 无链接，跳过: {name}")
            skip += 1
            continue

        print(f"[{i+1}/{len(records)}] 抓取: {name} ...", end=" ", flush=True)
        content = fetch_doc_content(url)

        if content:
            status = update_record(rec_id, content)
            print(f"✓ 写入 {len(content)} 字 (HTTP {status})")
            ok += 1
        else:
            print(f"✗ 内容为空，跳过")
            fail += 1

        time.sleep(0.5)   # 避免请求过快

    print(f"\n=== 完成 ===")
    print(f"成功写入: {ok}  跳过: {skip}  失败: {fail}")

if __name__ == "__main__":
    main()
