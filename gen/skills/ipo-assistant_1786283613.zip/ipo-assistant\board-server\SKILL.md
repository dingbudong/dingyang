# board-server — 内购智能客服 HTTP 服务

知音楼数字伙伴的后端核心。监听 `0.0.0.0:8765`，通过 GLM tool_use Agent 自主决策处理用户问题，同时异步调度看板生成全流水线。

## 架构

```
知音楼数字伙伴
  用户发消息
    → Dify 工作流（4节点：开始→代码执行→调用客服后端→回复用户）
        → POST /api/agent/chat  {query, user_id, user_name, work_code, image_url, group_id, is_group}
            → board-server 启动时预热 Teable 产品文档知识库（_search_doc_kb 内部检索）
            → board-server GLM tool_use Agent 循环（最多5轮）：
                · search_products(keyword)              → 九凤商品查询
                · query_sales(date_from, date_to)       → Teable 线上+线下销售统计
                · query_order(user_id, order_id)        → 九凤订单查询
                · query_logistics(express_no, order_id) → LS物流查询
        → 返回自然语言回复给 Dify → 回复用户

  用户说「生成看板」
    → Dify POST /api/task/submit
        → 异步调度：board-ls-fetch → board-data-clean → board-visualize → 知音楼通知

  知识库日志：📚 Teable KB 命中/未命中 日志可查检索状态
```

## Dify 工作流文件

**正式文件**：`scripts/static/dify_v6.yml`
- 节点：开始 → 代码执行 → 调用客服后端（HTTP）→ 回复用户（4节点）
- Code 节点从 `sys.user_workcode`（知音楼会话信息收集直传工号）和 `sys.user_id`（UUID）中提取 `work_code`，一并 POST 给后端
- 已在 Dify 应用设置中开启「会话信息收集」✅，工号由知音楼平台直传，无需任何绑定操作
- 产品文档知识库由 server.py 内部 Teable 预热检索（`_search_doc_kb`），不依赖 Dify 知识库节点

## 安装依赖

```bash
pip install flask
```

## Dify 配置

**★ 在 Dify 工作流 HTTP 节点中使用此固定 URL：**

```
https://wmd.tal.com/ipo-cs/api/agent/chat
```

- 由 K8s 容器平台（cloud.tal.com）托管，App ID=36512，集群 security-ack-online
- APISIX 域名 `wmd.tal.com`，server_b942e3e8，路径 `/ipo-cs` + `/ipo-cs/*`，proxy-rewrite 剥离前缀
- 健康检查：`https://wmd.tal.com/ipo-cs/health`
- 运行日志：`https://wmd.tal.com/ipo-cs/debug/log?n=100`
- GitLab 仓库：`https://git.100tal.com/warehouse_co_creation/ipo-assistant-cs.git`，分支 master

> ⚠️ **server.py 三路径说明（2026-07-01 更新）**：
> - **K8s 生产版**（主路径）：`D:\windows powershells\ipo-cs-deploy\ipo_assistant\board-server\scripts\server.py` → 修改后 `git push` → tck build → 发布
> - **本地守护进程版**：`C:\Users\dingyang3\.claude\skills\ipo-assistant\board-server\scripts\server.py`（6000+ 行）— 本机 8765 端口，由 network_watchdog.py 守护，ngrok 隧道已不再作为客服生产入口
> - 两套代码当前保持同步（K8s 版已用本地版 6000+ 行完整替换），后续修改 **K8s 版** 并同步回本地版

### ⚠️ 网络架构（重要）

**K8s 生产环境（当前）：**
```
知音楼用户发消息
  → Dify 工作流（4节点）
      → POST https://wmd.tal.com/ipo-cs/api/agent/chat
          → APISIX（server_b942e3e8）proxy-rewrite 剥离 /ipo-cs 前缀
              → K8s Service ipo-cs → pod :8765（gunicorn gthread，-w 1 --threads 8）
```

**本地守护进程（本机兜底，不对外提供客服服务）：**
```
本机 :8765（server.py，network_watchdog.py 守护）
  → ngrok 隧道 → router.py :9000
      ├── /api/*  → board-server :8765
      ├── /repair/*  → repair_server :5090
      └── /*  → log_viewer_web :8899
```

**注意**：智能客服已迁移至 K8s，本机 ngrok 隧道仍运行但仅作本地调试用，不再是生产入口。

## 委派任务机制（P2P + Teable 双步触发）

**待确认委派持久化**：`_pending_delegations` 写入 `scripts/pending_delegates.json`，server.py 重启后自动加载，30 分钟有效期内的委派不会因重启丢失。

丁洋老师（215734）确认委派后，`_delegate_teable_write(bot)` 执行：

```
步骤1: 用目标数字伙伴自己的 token → P2P 发消息给 215734（聊天框可见）
       内容: 「{关键词}\n收到！任务已启动，正在执行中，预计 {eta}，完成后会通知丁洋老师。」

步骤2: 写入目标守护进程的 Teable 触发表
       → 守护进程 30~60s 内轮询到新记录，自动执行完整任务流程
```

| bot | 数字伙伴 | P2P 关键词 | Teable 触发值 | 守护进程 |
|-----|---------|-----------|-------------|---------|
| selection | 内购选品助手 | `内购选品` | `内购选品` | ips_daemon |
| replenishment | 内购补货小助理 | `内购补货` | `智能客服触发` | ipo_daemon |
| new_product | 内购上新助手 | `内购上新` | `内购上新` | ipo_new_daemon |
| upload | 九凤上架助手 | `商品上架` | `商品上架` | jiufeng_upload_daemon |
| wms_audit | WMS审核助手 | agent/chat 直发 | — | wms_audit_daemon |

> ⚠️ **委派写入成功但任务不执行** = 守护进程已崩溃。查看对应 daemon 日志末尾时间，若截断早于委派时间，立即重启对应 daemon。

---

## 自动启动（无需手动操作）

`network_watchdog.py` 是统一的守护层，每 60 秒健康检查一次（HTTP GET `/health`），无响应则自动重启 server.py：
- **Windows 任务计划程序（NetworkWatchdog）**：
  - S4U 登录类型，无需用户登录即可运行
  - BootTrigger + PT2M 延迟：开机 2 分钟后自动启动（等待网络就绪）
  - LogonTrigger + PT1M 重复：登录后每 1 分钟检查是否在跑
  - server.py 宕掉后 ≤ 60 秒内由 watchdog 自动重启
- `ips_daemon.py` 内置保活轮询（每 80 次 × 15s ≈ 20min）作为额外兜底，同样通过任务计划（IPS_Daemon，S4U）开机自启

> ⚠️ **重启方式（重要，2026-06-22 更新）**：直接 kill pythonw 会导致 ips_daemon + watchdog 同时重拉多个实例争抢 8765 端口（Windows SO_REUSEADDR），Flask 接受 TCP 连接但不响应。正确做法是用 PowerShell 杀端口，让守护进程干净重启一个实例：
> ```powershell
> Get-NetTCPConnection -LocalPort 8765 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
> ```
> `_file_reload_watchdog`（文件变更自动 execv 热重载）已**永久禁用**，修改代码后用上面命令重启即可。
> `network_watchdog.py` 已改为 **TCP 端口检测**（去掉 `health_url`），避免 server 30s 启动期内 HTTP 未响应导致 watchdog 连续重启风暴。

日志：`D:\windows powershells\ips_cache\cs_chat.log`（守护进程日志监控「内购商城智能客服」标签页）

---

## LLM 多后端容灾机制

所有 LLM 请求走 TAL 内部网关 `http://ai-service.tal.com/openai-compatible/v1/chat/completions`，挂载 6 个后端：

| 优先级 | 模型 | 说明 |
|--------|------|------|
| 1（首选） | `claude-sonnet-4.6` | TAL 网关 → AWS Bedrock |
| 2 | `kimi-k2.6` | 月之暗面，不走 Bedrock |
| 3 | `glm-5.1` | 智谱，不走 Bedrock |
| 4 | `deepseek-v4-pro` | 深度求索，不走 Bedrock |
| 5 | `claude-opus-4.7` | TAL 网关 → AWS Bedrock |
| 6 | `qwen3.5-omni-flash` | 阿里，不走 Bedrock |

**故障切换规则**（`_glm_post_with_retry`）：

| HTTP 状态 | 处理方式 |
|-----------|---------|
| 429 | 立即切换下一个后端（速率限制） |
| 403 | 立即切换下一个后端（无权限） |
| 502 / 503 / 504 | 立即切换下一个后端（服务不可用） |
| 全部6个失败 | 降级关键词兜底（`_keyword_intent` + `_STATIC_REPLY`） |

---

## 补货/缺货查询 + @丁洋通知机制

**notify_admin 触发条件（仅限以下情况，其余自行回答不@）：**

| 触发 ✅ | 不触发 ❌ |
|--------|---------|
| 商品确认缺货/未上架，用户要买但买不了 | 商品有库存，能正常展示 |
| 售后需人工介入（退货/退款/换货/损坏等） | 普通查询、产品使用说明、价格咨询 |
| 用户明确说"找人工/让丁洋老师处理" | 补货/有货吗（由 LLM 自判，有货就展示） |

**补货/缺货查询流程：**
1. 先调 `search_products` 查商城库存
2. 有库存（含微瑕版）→ 展示商品，标注是否微瑕
3. 用户要正品但只有微瑕 / 完全无货 / 未上架 → 告知缺货 + 附补货建议表 + 调 `notify_admin`

**@丁洋 通知机制（群聊 vs 私聊）：**

| 场景 | 判定方式 | 行为 |
|------|---------|------|
| 用户在群里发消息触发客服 | 群消息 API 能找到该用户的这条消息 | Dify 回复后，在来源群发 `@丁洋 有用户咨询：{问题}\n麻烦看一下～` |
| 用户私聊 Dify 客服 | 群消息 API 找不到该用户的这条消息 | P2P 通知丁洋老师，附：咨询人姓名+工号+完整原始问题 |

> ⚠️ **关键架构约束**：Dify 无论用户来自群聊还是私聊，始终发送 `is_group=False`，且 `group_id` 始终是 Dify 会话 UUID（含 `-`，不是知音楼群 ID）。因此 **无法用 Dify 字段判断群/私聊**，只能通过扫描知音楼群消息 API 来判断。

**群 ID 解析机制（`_resolve_yach_group` + `_detect_source_group` + `_detect_source_group_by_content`）：**

1. 获取 bot 所在所有小群（non-type-201，`_BOT_GROUPS_TTL=0` 每次实时拉取，刚加入的群立即生效）
2. **已知工号用户（Dify 已绑定或 employee_id 已知）**：
   - 对每个小群调用 `/openapi/v2/im/messages`，按 `workCode==employee_id` 过滤，匹配 query 前10字
   - 状态对比：`time_ms > _user_group_last_match[(employee_id, group_tid)]` → 才算新事件
   - 有新事件 → 返回 time_ms 最大的群；**无新事件 → 直接判定私聊（P2P），不再做内容兜底**
3. **未知工号用户（Dify UUID 用户）**：
   - 对每个小群扫最近消息，找任意用户消息含 query 前10字
   - 同样做状态对比：`time_ms > _user_group_last_match[("c__{match_key}", group_tid)]`
   - 有新事件 → 返回来源群；无新事件 → P2P
   - 找到群后调 `_fetch_group_sender` 从群消息 API 取 `workCode` 和 `senderName`（群消息 API 对所有员工均返回 workCode，无需提前绑定）
4. 状态更新持久化到 `user_group_last_match.json`，防止同一群消息在同一对话中重复触发 @丁洋

**API 字段（`/openapi/v2/im/messages`）：**
- 必填：`group_id`, `start_time`（now-3600 秒）, `end_time`（now 秒）, `page_size`
- 消息字段：`senderName`, `workCode`, `uuid`, `content`, `time`（毫秒）, `userType`（1=用户, 2=机器人）

**通知时序（`_delayed_at` 线程）：**
- 等待 `req.event`（worker finally 设置，即 Flask 即将返回 Dify）→ 立即发 @丁洋
- 超时 15s 兜底直发（防止 event 遗漏）

**2层 LLM 兜底（server 端）：**
- 情况1：LLM 在回复文本中写了「通知/联系丁洋」但未调 `notify_admin` 工具 → server 自动触发
- 情况2：用户 query 含**售后类**关键词（退货/退款/换货/投诉/损坏/缺件/丢失/质量问题等），整轮未调 `notify_admin` → server 自动触发（补货/缺货/有货吗不在此列，由 LLM 自行判断）

**并发保护：**
- `_KnowallAPILimiter`：令牌桶 rate=10/s burst=30，所有知音楼 API 调用共享，最大等待 30s
- `/im/messages` 3s 进程内缓存（`_im_messages_cache`）：相同群在 3s 内只请求一次，消除并发冗余
- `_yach_group_send_with_retry`：发送 @丁洋 消息失败时自动重试 3 次，指数退避 1s/2s/4s
- `_BOT_GROUPS_TTL=0`：bot 群列表每次实时拉取（不缓存），刚加入的新群立即生效

**设计原则：**
- 使用智能客服自己的 appkey（`120443374ae46e39`）调用 `/group/robot/message/send`
- `at_work_codes: ["215734"]` + `at.atWorkCodes: ["215734"]` 触发蓝色 @（不用 `at_members`，否则平台会额外追加 `~@丁洋` 导致重复）
- 群 @ 消息格式：`有用户咨询：{问题前100字}\n麻烦看一下～`（不含用户姓名/工号，那些在 P2P 里）
- P2P 消息格式：`📌 内购商城问题反馈\n\n咨询人：{姓名}老师（工号：XXXXXX）\n原始问题：{完整问题}`
- Dify YAML code 节点始终传 `group_id = conversation_id`（即使私聊也传，由 server 端通过群消息 API 判断实际来源）
- 状态文件：`D:\windows powershells\ips_cache\user_group_last_match.json`（重启后持久化，防重复触发；key 格式：有工号用 `{employee_id}__{group_tid}`，无工号用 `c__{match_key}__{group_tid}`）

**工具调用流程：**  
所有工具（`search_products`、`query_product_ranking`、`query_product_analysis` 等）均走完整 ReAct 链路：LLM 识别意图 → 调工具 → LLM 拿到结果后思考 → 生成回复。无直接透传，LLM 全程参与推理。

**`query_product_analysis` 输出规范：**

| analysis_type | 输出风格 |
|---|---|
| `turnover` | 📦 周转分析，按周转天升序编号列表（`序号. 商品名  库存件 · 周转N天 · 日销X件`），末尾附需补货清单（周转<14天且库存≤5件） |
| `slow_moving` | ⚠️ 滞销分析，零销售款按库存值降序+状态emoji（🔴下架/✅在架/⬜未上架），低周转款按库存值降序，末尾智能提示（已下架款/在架零销售款/库存压得最重的款） |
| `cost` | 💰 成本毛利分析，毛利率降序，顶部展示综合毛利率（含无成本数据警告），末尾标注最高毛利款 |
| `inventory` | 📦 库存分析，库存值降序，顶部展示活跃款vs零销售款比例和滞压金额 |
| `sales` | 📊 销售分析，销售额降序，顶部展示日均销售额，末尾 Pareto 提示（前N款贡献80%销售额） |
| `comprehensive` | 📋 综合分析，合并以上关键指标，含日均销售额、滞销压货率、补货预警 |

**`top_n` 语义：** `0`（默认）= 全量展示；正整数 = 每节最多取 N 条。用户说「前十」传 `10`，说「全部」或未指定传 `0`，严禁后端默认截断。

**状态 emoji（slow_moving 零销售区）：**  
🔴 = 已下架，✅ = 在架上架，⬜ = 未上架/待上架

**快递相关问题（`courier_query`）：**  
`_KW_RULES` 中 `courier_query` 优先于 `logistics_query`，匹配「顺丰/圆通/快递方式/指定快递」等词，直接回复"系统随机分配，无法指定"。

---

## 接口说明

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/agent/chat` | ★ **主入口**：GLM Agent 全自动处理，传 `{"query":"<用户消息>","user_id":"<工号>","user_name":"<知音楼姓名>","group_id":"<Dify conv UUID>","image_url":"<可选图片URL>","image_base64":"<可选base64>","context":"<可选知识库检索结果>"}` |
| POST | `/api/sync/now` | ★ **定时同步专用**：直接触发全量订单同步，返回 `{"status":"accepted"}` 或 `{"status":"already_running"}` |
| POST | `/api/task/submit` | 看板任务下单，body: `{"task":"board_generate","days":90}` |
| GET  | `/api/task/status/<id>` | 查询异步任务状态 |
| GET  | `/health` | 健康检查，含 queue_size / workers / tunnel_url |
| GET  | `/debug/log?n=100` | 查看 pod 内运行日志（cs_chat.log 最新 n 行），排查生图/推送失败 |

## 订单数据定时同步

Teable 多维表自动化每 **4 小时**调用一次 `/api/sync/now`，触发 `update_sales_teable.py` 全量同步九凤订单到「内购订单明细」表。

**Teable 自动化脚本（每4小时，定时类型=小时，间隔=4）：**
```js
const res = await fetch('https://wmd.tal.com/ipo-cs/api/sync/now', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({})
});
output.set('status', res.ok ? 'accepted' : 'error');
output.set('http_status', res.status);
```

**同步日志：** K8s pod 内 `/app/ipo_assistant/ips_cache/auto_tasks.log`，可通过 `https://wmd.tal.com/ipo-cs/debug/log?n=200` 查看

**本地兜底：** `network_watchdog.py` 内置 fallback——每 **6 小时**自动调用一次本机 `/api/sync/now`（本地守护进程）作为备用；K8s 版依赖 Teable 自动化定时调用。

---

## `/api/agent/chat` — GLM Agent 智能对话（主接口）

Dify 的 HTTP 节点只需调用此接口，无需意图分类节点、LLM 节点、分支节点。

**请求：**
```json
{"query": "小猴点读笔价格", "user_id": "工号"}
```

> `user_id` 用于权限控制，权限组由管理员通过 `/admin/permissions` 页面动态配置：
> - **数据查询权限**（`_SALES_ALLOWED`）：可调用 `query_sales`、库存排行等工具；无权限用户直接返回拒绝提示
> - **委派确认权限**（`_DELEGATE_ALLOWED`）：可确认/取消自动化任务委派；无权限用户无法执行
> - 超级管理员工号 **215734** 始终在两个权限组中，不可移除
> - 未传 `user_id` 或 UUID 未绑定工号，视为无权限

**GLM Agent 工具定义：**

| 工具 | 参数 | 数据来源 |
|------|------|---------|
| `search_products` | `keyword` | 九凤后台 API |
| `query_sales` | `date_from`, `date_to`（YYYY-MM-DD） | Teable「内购订单明细」（线上）+ 「内购商城线下收款」（线下），合并输出含各渠道小计和总计 |
| `query_product_ranking` | `date_from`, `date_to`, `sort_by`（qty/amount）, `top_n`（0=全量，默认） | Teable「内购订单明细」，按商品汇总，支持销量/销售额两种排行 |
| `query_product_analysis` | `date_from`, `date_to`, `analysis_type`（turnover/slow_moving/cost/inventory/sales/comprehensive）, `keyword`, `top_n` | 「内购订单明细」（销售）+「九凤商品明细`tbl7g0OGoZKaYlRylTj`」（成本+库存），计算周转率/滞销/毛利/库存价值；权限同 query_sales |
| `query_order` | `user_id`（工号或姓名均可）, `order_id` | 九凤订单列表；**普通用户只能查本人**（server 强制覆盖），有权限用户可传姓名或工号，server 自动解析姓名→工号 |
| `query_logistics` | `express_no`, `order_id` | LS系统 → 快递100兜底 |

**系统提示核心规则：**
- **职责边界（最高约束）**：只做三件事——①识别意图 ②回答内购相关问题（含商品查询、产品使用说明/资料、订单物流、售后） ③执行委派指令。打招呼 → 一句话回应+引导；问功能 → Markdown 列表；与内购无关 → 礼貌拒绝，不延伸。
- **产品文档知识库**：server.py 启动时预热加载 Teable「产品文档知识库」表（178篇文档），用户问「XXX 怎么用/适合几岁/激活/课程内容」时自动检索并融合回答；商城实时数据（价格/库存/链接）仍需调 `search_products`。
- **搜索规则**：keyword 只用品牌名、产品名主体或年级描述词（如 ABCtime、点读笔、五年级），server 端自动剥离尾部品类词（书籍/玩具等）并将阿拉伯数字年级转中文（5年级→五年级）；无结果时 LLM 用更短关键词重试一次。
- **三品独立规则**：ABCtime（上册）、Reading A-Z（下册）、RAZ（单词王点读大书）是三个独立品，不可合并查询：
  - 用户问 ABCtime → keyword=`"ABCtime"`
  - 用户问 Reading A-Z → keyword=`"Reading"`
  - 用户问 RAZ → keyword=`"RAZ"`
- **小猴点读笔兼容搜索（共 10 次）**：用户问「点读笔支持/适用/配套哪些书/产品」时，必须逐一搜索全部 10 个 keyword：
  `"小猴点读笔"`、`"哈佛外教英语启蒙"`、`"ABCtime"`、`"Reading"`、`"RAZ"`、`"摩比分级数学"`、`"摩比汉语分级"`、`"摩比自然拼读"`、`"迪士尼英语"`、`"大师英文"`
- **工具结果处理（search_products / query_product_ranking / query_product_analysis）**：工具结果返回后交由 LLM 推理并生成最终回复，LLM 全程参与。商品直达链接、图片、库存状态均从工具结果原样保留，末尾固定附 `🏪 内购商城入口：https://t.tal.com/e3KJoD`。无结果时 LLM 用更短关键词重试。

**商品图片/库存/直链能力（query_product.py 已实装）：**
- 九凤 API 返回商品主图（`main_pic` 字段），`format_reply` 已包含 `![商品图片](url)` Markdown 格式
- 每款商品自动附 **库存状态**：✅ 有货 / ⚠️ 暂无货 / ⚠️ 已下架 / ⚠️ 待上架（来自 `stock_sale_num` + `status_name` 字段联合判断；`stock_sale_num` 为实际可售量，不能用 `stock_num` 仓库总量）
- 每款商品自动附 **商品直达（手机端）**：`🔗 商品直达：https://pointmall.100tal.com/goodsDetail?clientGroup=91&id={sku_id}&promotion_id=0&order_source=104`
  - `id` 使用九凤 API 的 **`id` 字段（SKU id）**，不是 `spu_id`——两套编号不重叠，用 `spu_id` 会打开错误商品
- 商城整体入口（底部固定）：`🏪 内购商城入口：https://t.tal.com/e3KJoD`，与商品直达链接标签不同，区分清楚
- Agent 查询结果自动包含图片、库存状态和直链，用户无需另外要求

**新增能力（server.py 已实装）：**
- **上下文记忆**：每用户最多保留 50 轮对话（TTL 30 分钟无消息自动清空），重启后清空
- **图片历史修复**：图片轮次保存历史时存识别摘要（`_hist_query`），确保下轮 LLM 知道识别了哪个商品，不再问「请重发图片」
- **图片识别**：传入 `image_url` 或 `image_base64` 时，由 `claude-sonnet-4.6`（首选）对**全图**进行综合识别（文字 + 视觉特征并重），识别结果作为上下文回答。
  - Dify 工作流使用 **4节点结构**：开始 → 代码执行（Code）→ 调用客服后端（HTTP）→ 回复用户
  - Code 节点输入 `files`（Array[File]，绑定 sys.files）、`user_name`（绑定 sys.user_name），提取 `image_url`、`group_id`、`user_name` 输出
  - HTTP body：`{"query":"{{#sys.query#}}","user_id":"{{#sys.user_id#}}","user_name":"[代码执行.user_name]","work_code":"[代码执行.work_code]","image_url":"[代码执行.image_url]","is_group":[代码执行.is_group],"group_id":"[代码执行.group_id]"}`
  - **图文双向问询逻辑（无时间限制）**：平台把文字和图片拆成两条消息时，缺任一方则主动问：
    - 只有图没有描述 → claude-sonnet 识别图片内容 → 结合历史上下文问"需要什么帮助"
    - 只有描述没有图（含图片/照片/识别等关键词，且不含销量/价格/库存等商品查询词）→ 立即回复"请您发一下图片"
    - ⚠️ **识图/生图不串流**：`_IMG_GEN_KW`（生成/帮我画/画一张/做个等）命中时跳过识图判断；`_IMG_EXCLUDE_KW`（销量/价格/库存/订单/物流等）命中时也跳过，防止「想看下这个商品的销量」被误拦截
- **上下文代词解析**：系统提示强制 LLM 在用户用「他/那个/这个/它」时，从对话历史找最近明确商品名，直接调工具，禁止重新询问「是哪个商品」
- **文生图（异步推送）**：用户说「帮我画」「生成图片」时，Agent 调用 `generate_image` 工具。工具立即返回"后台生成中"占位（附提示「问我图片生成好了吗可查进度」），后台线程通过 `_image_gen_sem`（Semaphore(1)）排队串行调用 **gpt-image-2**（RPM:5，生成耗时 60~180s），生成完成后**保存到 K8s pod 本地 `/app/ipo_assistant/ips_cache/static/images/`，图片公网 URL 为 `https://wmd.tal.com/ipo-cs/static/images/{filename}`**，推送给用户（P2P markdown）。无固定等待时间，纯排队模式。
  - ⚠️ 图片**不再使用文图图床**（kkm.de5.net 已下线）也不走 ngrok，直接走 wmd.tal.com/ipo-cs/static/images/ 路由（APISIX proxy-rewrite + Flask /static/ 端点）。K8s pod 重启后本地图片文件丢失，但已推送的消息不受影响。
- **视频生成（异步推送）**：用户说「生成视频」「帮我做个视频」时，Agent 调用 `generate_video` 工具（happyhorse-1.0-t2v/i2v）。同样立即返回占位，后台线程通过 `_video_gen_sem`（Semaphore(1)）排队串行执行（RPM:5），完成后 P2P 推送视频链接。无固定等待时间，纯排队模式。
- **生成进度查询**：用户说「图片/视频生成好了吗」「进度怎么样」时，直接读 `pending_async_jobs.json` 返回运行中任务列表，无需走 LLM。
- **持久化任务队列（防重启丢失）**：生图/生视频任务启动时写入 `scripts/pending_async_jobs.json`，完成后自动删除。server.py 重启时 `_recover_async_jobs()` 自动恢复所有未完成任务。

**底层模型（排队架构）：** TAL AI 服务代理，6 个 Worker 动态调度；每条对话请求入队 **1 个槽**，第一个空闲 Worker 接单处理，多用户并发互不阻塞（最多同时处理 6 条对话）。

**后端调度优先级**：每次取任务优先选 `claude-sonnet-4.6`（若未在速率限制期内）；若 sonnet 在 3.5s 间隔内，自动选最久未用的其他后端。**429 速率限制时立即抛出 `_LLMRateLimit`，worker 无等待切换下一 backend**（sonnet→kimi→glm→deepseek→opus→qwen），不在同一模型内重试等待。全部 6 个模型都 429 才报错。

| 模型 | 说明 |
|------|------|
| `claude-sonnet-4.6` | 对话 worker，识图链首选 |
| `kimi-k2.6` | 对话 worker |
| `glm-5.1` | 对话 worker |
| `deepseek-v4-pro` | 对话 worker |
| `claude-opus-4.7` | 对话 worker，识图链接力1 |
| `qwen3.5-omni-flash` | 对话 worker，识图链接力2 |
- HTTP 调用超时 120 秒（2026-07-01 修复，原为 None 导致 K8s pod 内 worker 线程永久卡死）

**图片识别流程：** `_describe_image()` 依次尝试以下模型，任一失败（5xx / 异常）立即换下一个，不重试同一模型：

| 优先级 | 模型 | 说明 |
|--------|------|------|
| 1 | `claude-sonnet-4.6` | 首选：原生 vision 模型，识图准确稳定 |
| 2 | `claude-opus-4.7` | 接力1 |
| 3 | `qwen3.5-omni-flash` | 接力2，omni 多模态 |

识别结果注入 agent 上下文后由排队 Worker 继续处理。全部失败则返回空，agent 按纯文字处理。

所有模型均不传 `thinking`/`reasoning_effort` 参数；回复经 `_strip_thinking_text()` 过滤，防止 Claude 推理过程泄露。

**称谓规范：** 对人一律称「老师」，严禁使用「同学」。售后负责人统一表述为「内购管理员丁洋老师（知音楼工号：215734）」。

**售后回复规范：** 遇到售后问题（坏了/损坏/退货/退款/换货/投诉/丢失/破损/质量/缺件等）时，回复中必须同时包含：① 引导路径「流程中心 → 搜索【内购商城售后申请】」；② 直达链接 `https://oa.zhiyinlou.com/v20/formRender?wfId=1475`，两项缺一不可。

**学习机购买规范：** 学习机不在内购商城，购买流程两步：① 先提交审批，路径：流程中心 → 内购商城学习机样机内购申请，链接：`https://oa.zhiyinlou.com/mob/approval?wfId=1490` ② 审批通过后联系丁洋老师（215734）线下自提。回复必须同时包含路径描述、审批链接和联系人两步说明。

**未知问题兜底：** 无法回答时回复「抱歉，这个问题我暂时无法解答，请联系内购管理员丁洋老师（知音楼工号：215734）获取帮助。」，绝不编造答案。

**返回：** `text/plain; charset=utf-8`，自然语言回复。

---

## 权限管理系统

管理入口：桌面快捷方式 `内购客服权限管理.url` → `http://localhost:8765/admin/permissions`

### 权限组

| 权限组 | 变量 | 作用 |
|--------|------|------|
| 数据查询权限 | `_SALES_ALLOWED` | 查销售额/订单量/库存/排行 |
| 委派确认权限 | `_DELEGATE_ALLOWED` | 确认/取消自动化任务委派 |
| 订单查询权限 | `_ORDER_QUERY_ALLOWED` | 可查任意工号订单（普通用户只能查本人） |

持久化：`ips_cache/admin_permissions.json`（含 `data_allowed`、`delegate_allowed`、`order_allowed`、`staff_names` 四字段）  
Teable 同步表：`tblvmF035LLP9Ra2LvG`（base `bseFFoyVD6WgFbKmzDN`），字段：工号、姓名备注、数据查询权限、委派确认权限、订单查询权限、UUID绑定、最后更新

### 员工识别机制

**v6 直传（✅ 主路径，已上线）：**
知音楼通过 `sys.user_workcode` 直接传入员工工号，server.py 收到 `work_code` 字段后直接使用，无需任何绑定操作。所有员工发消息即可被自动识别。

**兜底链（v6 直传未识别时的降级路径）：**
Dify 传来 `sys.user_id`（UUID），通过以下顺序解析工号：
1. `_uuid_staff_map`（本地持久化映射，`uuid_staff_map.json`）
2. 姓名自动绑定：用 `user_name` 反查 `_STAFF_NAMES`（管理员录入）+ `_yach_user_name_cache`（系统积累）
3. 用户自报工号（消息内容是纯工号时自动记录）
4. 仍无法识别 → 主动问用户工号，填一次后永久记住

映射文件：`ips_cache/uuid_staff_map.json`

### 管理接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET  | `/admin/permissions` | 权限管理页面 |
| GET  | `/admin/permissions/data` | 返回当前权限组 + 姓名 |
| POST | `/admin/permissions/save` | 保存权限，自动同步 Teable |
| POST | `/admin/permissions/sync_from_teable` | 从 Teable 拉取覆盖本地 |
| GET  | `/admin/uuid_map/data` | UUID 绑定列表 + 待绑定用户 |
| POST | `/admin/uuid_map/save` | 手动绑定/解绑 UUID |

---

## 看板任务接口

```bash
curl -X POST http://localhost:8765/api/task/submit \
  -H "Content-Type: application/json" \
  -d "{\"task\":\"board_generate\",\"days\":90}"
```

查询状态：
```bash
curl http://localhost:8765/api/task/status/<task_id>
```

返回示例（完成）：
```json
{
  "status": "done",
  "dashboard_url": "https://dingbudong.github.io/dingyang/ips/ipo_dashboard_20260429.html",
  "started_at": "2026-04-29T10:00:00",
  "finished_at": "2026-04-29T10:04:32"
}
```

## 状态值说明

| status | 含义 |
|--------|------|
| `pending` | 已接受，等待执行 |
| `running` | 执行中 |
| `done` | 全部完成 |
| `failed:fetch` / `failed:clean` / `failed:visualize` / `failed:upload` | 对应阶段失败 |

---

## 已知 Bug 修复记录

### 2026-06-23（线下销售数据说明）

**智能客服无法回答线下销售数据问题**
- 现象：用户问「线下无头件销售额」「线下学习机售卖情况」「线下收款明细」，客服回复"暂时没有这个专项筛选维度"，建议去后台导出，未能直接查询
- 根因：系统提示 `query_sales` 工具说明未提及线下收款，LLM 不知道工具结果已包含线下数据
- 修复：在系统提示 `query_sales` 工具说明中补充：
  - 工具返回结果自动包含「内购商城线下收款」Teable 表数据（`tbly5g9ni6Lofaig0T4`）
  - 活动事件类型：线下内购无头件、线下学习机内购、未来市集内购活动、废纸箱售卖
  - 用户问「线下销售/线下收款/无头件/学习机销售」等 → 直接调 `query_sales`，工具返回含对应明细
- 权限：线下数据与线上销售数据同属 `query_sales`，受同一权限组（`_SALES_ALLOWED`）控制，普通用户无法查询

### 2026-06-23（图片图床切换等）

**图片图床切换（文图→GitHub）**
- 文图图床 `kkm.de5.net` 域名已失效（DNS 无法解析），生成图片无法在电脑端打开
- 修复：C路径 server.py 第 516 行将 `_WENTIAN_*` 变量改为 GitHub 配置：
  ```python
  _GITHUB_TOKEN  = "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"
  _GITHUB_REPO   = "dingbudong/dingyang"
  _GITHUB_BRANCH = "main"
  _GITHUB_PATH   = "gen"
  ```
- `_wentian_upload_b64()` 改为调用 GitHub Contents API（PUT `/repos/{owner}/{repo}/contents/{path}`），返回 `download_url`（raw 链接，电脑端可直接打开）
- Token 无过期日期，到期重新在 https://github.com/settings/tokens 生成，账号 `295161040@qq.com` / `Da-1590152`

**视频 URL 修复**
- 原来视频生成后会调 `_save_video_locally()` 下载到本地再走 ngrok，导致链接不稳定
- 修复：去掉转存步骤，直接用 TAL 返回的原始视频 URL 发给用户（两处：异步生成 + 恢复任务）

**广告审批回复被智能客服误接**
- 用户回复「补货广告拒绝」被 LLM 当成「跑补货任务」处理
- 根因：`parse_reply_and_act` import 时找不到 `promo_approval` 模块（路径问题），被 except 吞掉后继续走 LLM
- 修复：C路径 server.py 第 4633 行在 import 前插入 `sys.path.insert(0, r'D:\windows powershells')`
- 另：`parse_reply_and_act` 无 ID 时只查「审批中」状态，而广告刚发时状态是「待审批」导致找不到记录；已在 `promo_approval.py` 第 273 行将过滤条件改为同时包含「审批中」和「待审批」

### 2026-07-01（K8s 迁移修复，wmd.tal.com）

**根本 Bug：gunicorn 不执行 `if __name__ == '__main__':` 块**
- 现象：所有 AI 对话永久"等待中"，`health` 接口显示 `queue_size: N, workers: 0/6 busy`
- 根因：GLM worker 线程、Teable 轮询、知识库预热等初始化代码全在 `__main__` 块，gunicorn 导入模块不执行该块
- 修复：提取 `_app_startup()` 在模块级别自动调用

**timeout=None 导致 K8s pod 内 worker 永久卡死**
- 现象：AI API 调用无超时，网络抖动时 worker 挂起无法恢复
- 修复：两处 `_http.post(..., timeout=None)` 改为 `timeout=120`；`req.event.wait()` 改为 `wait(timeout=260)`

**pod 重启后认不出用户 / 无法查销售数据**
- 现象：UUID→工号映射、权限组全部丢失（本地文件在 K8s 临时文件系统中）
- 修复：`_app_startup()` 里加 `_load_perms_from_teable()`，pod 启动时自动从 Teable 拉取

**K8s 版为精简版（3800 行），缺少知识库等大量功能**
- 现象：小猿点读笔/摩比爱数学等产品文档知识库问题无法回答
- 修复：用 C 路径完整版（6000+ 行）替换精简版，现两路径保持同步

**修改流程（2026-07-01 起）：**
```
改 D:\windows powershells\ipo-cs-deploy\ipo_assistant\board-server\scripts\server.py
→ git commit && git push → tck build run --app-id 36512 --branch master --wait
→ 去 cloud.tal.com 发布新版本
→ 同步修改 C:\Users\dingyang3\.claude\skills\ipo-assistant\board-server\scripts\server.py（本地守护进程）
```
