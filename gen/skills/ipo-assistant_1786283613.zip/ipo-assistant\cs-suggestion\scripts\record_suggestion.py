"""
内购商品建议/补货申请记录
写入 Teable 商品建议表
用法: python record_suggestion.py --user_id xx --product xx --need_type xx --description xx
"""
import sys, json, argparse, urllib.request
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

BASE_URL   = "https://yach-teable.zhiyinlou.com"
BASE_ID    = "bseFFoyVD6WgFbKmzDN"
TOKEN      = "teable_accjZ1F3p1bY3ame1BB_dA56VMpJYWa1WahMb93nPObvLT2VujnpPlAvNnXsLaw="
TABLE_NAME = "内购商品建议"
SUGGESTION_FORM_URL = "https://yach-doc-shimo.zhiyinlou.com/sheets/8Nk6MWvrBdTVo4qL/MODOC/"

HEADERS = {
    "Authorization": f"Bearer {TOKEN}",
    "Content-Type": "application/json"
}


def _req(method, path, data=None):
    url = f"{BASE_URL}/api{path}"
    body = json.dumps(data, ensure_ascii=True).encode('utf-8') if data else None
    req = urllib.request.Request(url, data=body, headers=HEADERS, method=method)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode('utf-8'))


def get_or_create_table() -> str:
    tables = _req("GET", f"/base/{BASE_ID}/table?take=100")
    for t in (tables if isinstance(tables, list) else tables.get("tables", [])):
        if t.get("name") == TABLE_NAME:
            return t["id"]

    resp = _req("POST", f"/base/{BASE_ID}/table", {
        "name": TABLE_NAME,
        "fields": [
            {"name": "提交时间", "type": "date"},
            {"name": "用户工号", "type": "singleLineText"},
            {"name": "商品名称", "type": "singleLineText"},
            {"name": "需求类型", "type": "singleLineText"},
            {"name": "描述",     "type": "longText"},
            {"name": "状态",     "type": "singleLineText"}
        ]
    })
    return resp["id"]


def record(user_id, product, need_type, description) -> dict:
    table_id = get_or_create_table()
    now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000Z")

    _req("POST", f"/table/{table_id}/record?fieldKeyType=name", {
        "records": [{
            "fields": {
                "提交时间": now,
                "用户工号": str(user_id),
                "商品名称": str(product),
                "需求类型": str(need_type),
                "描述":     str(description),
                "状态":     "待跟进"
            }
        }]
    })

    reply = (
        f'您好！您的需求已记录 ✅\n\n'
        f'商品：{product}\n'
        f'类型：{need_type}\n\n'
        f'我们会定期汇总员工需求，优先考虑采购。\n\n'
        f'同时，您也可以通过商品征集表直接提交，获得更快响应：\n'
        f'👉 内购商品征集表：{SUGGESTION_FORM_URL}\n\n'
        f'🏪 内购商城入口：https://t.tal.com/e3KJoD\n'
        f'【路径：手机端知音楼→工作台→教师应用→好未来内购商城】'
    )
    print(reply)
    return {"status": "ok", "reply": reply}


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--user_id",     default="unknown")
    p.add_argument("--product",     required=True)
    p.add_argument("--need_type",   default="新品征集")
    p.add_argument("--description", default="")
    args = p.parse_args()
    record(args.user_id, args.product, args.need_type, args.description)
